#ifndef _ISYSTEMSERVICE_HPP_
#define _ISYSTEMSERVICE_HPP_

#include <time.h>

enum
{
	PLATFORM_FUN_TIME = 0,
	PLATFORM_FUN_GETTIMEOFDAY,
};

class ISystemFunction
{
public:
	virtual bool IsSupported(int iServiceID) = 0;
	virtual time_t Time(time_t *pt) = 0;
	virtual int GetTimeOfDay(struct timeval *ptime, struct timezone *pzone) = 0;
};

#endif




