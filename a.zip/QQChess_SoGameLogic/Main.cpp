#include "StdAfx.h"
#include "XQServer.h"
#include "CreateCLSvr.h"

#ifdef WIN32
#undef USING_MY_NAMESPACE
#define USING_MY_NAMESPACE
#endif

extern "C" 
{
#ifdef WIN32
    __declspec(dllexport) 
#endif
	IGame* CreateGame(void* pBuffer, int iInitMode, const char *szCfgFile,ITable* pTable)
	{
		static int a = 0;
		USING_MY_NAMESPACE
		CXQServer*  pServer = new(pBuffer) CXQServer;
        int nSoGameSize = sizeof(CXQServer);
        nSoGameSize = (nSoGameSize + 31)>>5<<5;
		if (0 == a)
		{
			a = 1;
			printf("XQ so start! sizeof(CXQServer)=%d, nSoGameSize=%d\n", sizeof(CXQServer), nSoGameSize);
		}
        int nCLSize = 0;
        ISoCommLogic *pSoCL = CreateSoCommLogic(((char*)pBuffer) + nSoGameSize, nCLSize);

		pServer->Create(pTable, iInitMode, szCfgFile, pSoCL);
		return pServer;
	}
}


// extern "C" 
// {
// #ifdef WIN32
//     __declspec(dllexport) 
// #endif
// 		IGame* CreateGame(void* pBuffer, int iInitMode, const char *szCfgFile, ITable* pTable)
//     {
//         if(!pBuffer || !szCfgFile || !pTable)
//         {
//             return NULL;
//         }
//         //40k, should define as a macro 40 * 1024 = 40960
//         if(sizeof(CXQServer) > 40960)
//         {
//             return NULL;
//         }	
// 		
// 		CXQServer* pServer = new(pBuffer) CXQServer;
//         
// 		pServer->Create(pTable, iInitMode, szCfgFile);
//         
// 		return pServer;
//     } 
// }


int main()
{
	return 1;
}