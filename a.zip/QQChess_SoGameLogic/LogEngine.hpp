/****************************************************************
 * @file		CommonBaseDefinition/LogEngine.hpp
 * @see			
 * @version		2006.05.10
 * @author		Loyo.Lu
 * @content		
 ****************************************************************/

#ifndef __LOGENGINE_HPP__
#define __LOGENGINE_HPP__

#include <string.h>
#include <stdarg.h>

#include "CommonMacro.hpp"

#include "SingletonTemplate.hpp"


//�������г�����ܹ�������־����(Ԥ��һ���ֽڣ� 0x0001-0x00000080
#define LOG_LEVEL_CALL				0x0001		//���ٺ�������
#define LOG_LEVEL_READ_CFG			0x0002		//��ȡ����ʱ�������־
#define LOG_LEVEL_VIEW_PERFORMANCE	0x0004		//���ܸ���
#define LOG_LEVEL_DETAIL			0x0008		//��ϸ��־
#define LOG_LEVEL_BILL              0x0010      //bill���

#define LOG_LEVEL_NONE		0x0000
#define LOG_LEVEL_ANY		-1



class CLogEngine
{
public:
	CLogEngine();
	virtual ~CLogEngine();

	int InitLog(
		char *pcFileName,
		int iMaxFileSize, int iMaxFileCount);

	int WriteLog(
		char *pcErrInfo,
		const char *pcContent, ...);

	int WriteLog(
		char *pcFileName,
		int iMaxFileSize, int iMaxFileCount,
		char *pcErrInfo,
		const char *pcContent, va_list ap);

	int WriteLog(
		char *pcFileName,
		char *pcErrInfo,
		const char *pcContent, va_list ap);

	//int WriteLog(int iLogLevel,
	//	char *pcFileName,
	//	int iMaxFileSize, int iMaxFileCount,
	//	char *pcErrInfo,
	//	const char *pcContent, va_list ap);

	//int WriteLog(int iLogLevel,
	//	char *pcFileName,
	//	char *pcErrInfo,
	//	const char *pcContent, va_list ap);

	int PrintBin(char *pcFileName,
		char *pcBuffer,
		int iLength,
		char *pcErrInfo);

	int PrintBin(char *pcFileName,
		int iMaxFileSize, int iMaxFileCount,
		char *pcBuffer,
		int iLength,
		char *pcErrInfo);

	int CheckLogLevel(int iLogLevel);

	int SetLogLevel(int iLogLevel);

	int ShiftFile(char *pcFileName,
		int iMaxFileSize, int iMaxFileCount,
		char *pcErrInfo);

private:

	int m_iLogLevel;

	char m_szFileName[MAX_FILENAME_LEN];
	int m_iMaxFileSize;
	int m_iMaxFileCount;

	int m_iSimpleTrace;
	
};



//typedef Singleton<CLogEngine> LogEngineSingleton;
//
//#define LOGENGINE LogEngineSingleton::instance()






/*
#define TRACE_FUNC_BEGIN\
	TRACE(LOGFILE_CHATCTRLSVRD, LOG_LEVEL_CALL, "In %s, ----------Begin To Handle----------\n", __FUNCTION__);
*/
/*
#define TRACE_FUNC_END\
	TRACE(LOGFILE_CHATCTRLSVRD, LOG_LEVEL_CALL, "In %s, ----------Handle OK----------\n", __FUNCTION__);
*/

#endif /* __LOGENGINE_HPP__ */

