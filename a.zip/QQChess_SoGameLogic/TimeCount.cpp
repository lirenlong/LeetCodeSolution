#include "StdAfx.h"
#include "TimeCount.h"

void CTimeCount::ReStart()
{
	m_tTimeMark = time(0);
	m_nTimePreCount = 0;
	m_nState = tCounting;
}

void CTimeCount::Clean()
{
	m_tTimeMark = 0;
	m_nTimePreCount = 0;
	m_nState = tPause; 
}

void CTimeCount::Pause()
{
	if(m_nState == tPause) return;
	m_nTimePreCount = time(0) - m_tTimeMark + m_nTimePreCount;
	m_nState = tPause;
}

void CTimeCount::Resume()
{
	if(m_nState == tCounting) return;
	m_tTimeMark = time(0);
	m_nState = tCounting;
}

long CTimeCount::GetTickCount()
{
	if(m_nState == tCounting)
		return time(0) - m_tTimeMark + m_nTimePreCount;
	else
		return m_nTimePreCount;
}

int CTimeCount::GetHour()
{
	long nTick;
	
	if(m_nState == tPause)
		nTick = m_nTimePreCount;
	else
		nTick = GetTickCount();

	return nTick/3600;
}

int CTimeCount::GetMinute()
{
	long nTick;
	
	if(m_nState == tPause)
		nTick = m_nTimePreCount;
	else
		nTick = GetTickCount();

	return (nTick % 3600) / 60;
}

int CTimeCount::GetSecond()
{
	long nTick;
	
	if(m_nState == tPause)
		nTick = m_nTimePreCount;
	else
		nTick = GetTickCount();

	return nTick % 60;
}

BOOL CTimeCount::SetEnable(BOOL bEnable)
{
	if(bEnable)
	{
		if(m_bEnable) return false;
		
		if(m_nDisableState == tCounting)
		{
			Resume();
		}
		
		m_bEnable = TRUE;
	}
	else
	{
		if(!m_bEnable) return false;
		
		m_nDisableState = m_nState;
		if(m_nState == tCounting)
		{
			Pause();
		}
		
		m_bEnable = FALSE;
	}
	return true;
}

BOOL CTimeCount::IsEnable()
{
	return m_bEnable;
}

int CTimeCount::GetState()
{
	return m_nState;
}

void CTimeCount::SetTickCount(long nTickCount)
{
	m_nTimePreCount = nTickCount;
}