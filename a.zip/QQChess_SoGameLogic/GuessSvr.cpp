// GuessSvr.cpp: implementation of the GuessSvr class.
//
//////////////////////////////////////////////////////////////////////
#include "StdAfx.h"
#include "GuessSvr.h"
#include "GameCmd.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

MY_NAMESPACE_BEGIN

GuessSvr::GuessSvr()
{
	m_bUnLockPlayerMoney = FALSE;
	
	m_nRankUseful = 1;

	m_nValidTime = 120;
	
	m_nCurLookOnNumber = 0;

	Initialize(NULL, NULL, NULL);

	m_sPlayerIDReqAddBaseMoney = -1;
	m_unBaseGuessMoney = 0;
	m_unSalouAdd = 0;
	
	m_bGameOver = TRUE;
	m_b100WValid = FALSE;

	m_nPlayerRefusedAddBaseMoneyCount = 0;
	m_nGameStep	= 0;

	int i = 0;
	for( i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
	{
		m_LookerOn[i].Clear();
	}
	for( i=eGMBegin; i<eGMOverflow; i++ )
	{
		m_nPersonCount[i]	= 0;	//Ͷע3�����������
		m_unGuessMoney[i]	= 0;	//Ͷע����Ǯ��
	}

	m_bHasSetBaseMoney = FALSE;

	SetFirstRunOrder(0, FALSE);
}

int		GuessSvr::SetFirstRunOrder(int nFirst, BOOL bNegtive)
{
	if( nFirst<0 || nFirst>=MAX_GAME_PLAYER_COUNT )
	{
		return -1;
	}
	if( nFirst==0 )
	{
		for( int i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
		{
			m_nValues[i]	= i;
		}
	}
	else
	{
		for( int i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
		{
			m_nValues[i]	= MAX_GAME_PLAYER_COUNT-1-i;
		}
	}
	return 0;
}

GuessSvr::~GuessSvr()
{

}

//�趨itableָ��
int		GuessSvr::Initialize(ITable * pServer, CLogFile* pLogFile, CConfigFile* pConfigFile)
{
	m_pServer = pServer;
	m_pLogFile	= pLogFile;
	m_pConfigFile = pConfigFile;

	return 0;
}

//��ҽ���
int		GuessSvr::PlayerEnter(TABLE_USER_INFO *pUser)
{
	//����ط����ܻ����һ������ 
	//����Թ۵�Ǯ��û�з��صĻ� ��ô�ͻᱻ���...
	for(int i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
	{
		if( pUser->m_nChair==m_LookerOn[i].sSeat )
		{
			m_LookerOn[i].Clear();
		}
	}
	m_Players[pUser->m_nChair].SetBase(pUser->m_nPlayerID,pUser->m_iUin,
		pUser->m_szUserName, (pUser->m_uiRightLevel & 0x80) ? 1 : 0 );
//	m_sPlayerID[pUser->m_nChair] = pUser->m_nPlayerID;
//	m_unPlayerUin[pUser->m_nChair] = pUser->m_iUin;
//	strncpy( m_chPlayerNickName[pUser->m_nChair], pUser->m_szUserName, MAX_PALYER_NICK_NAME_LEN);
	return  0;
}
//�Թ��߽���
int		GuessSvr::LookerEnter(TABLE_USER_INFO *pUser)
{
	int nMaxLookOnNumber = (m_nMaxLookOnNumber>MAX_GAME_LOOKON_COUNT) ?
				MAX_GAME_LOOKON_COUNT : m_nMaxLookOnNumber;
	if( m_nCurLookOnNumber>=nMaxLookOnNumber )
	{
		if( m_pLogFile )
		{
			m_pLogFile->Log("***** too much looker-on ... %d \n", m_nCurLookOnNumber );
		}
		printf( "too much looker-on ... %d ", m_nCurLookOnNumber );
		return 1; // too much looker-on
	}

	int i = 0;
	//�����Թ����Ƿ��Ѿ�����
	for( i=0; i<nMaxLookOnNumber; i++ )
	{
		if( pUser->m_nPlayerID==m_LookerOn[i].sPlayerID
			&& pUser->m_iUin==m_LookerOn[i].unUin )
		{
			//���� �����뿪״̬Ϊ0
			m_LookerOn[i].byExit = 0;
			printf("\nlooker enter find place (exist) is %d \n", i);
//			SendBaseGuessInfo(pUser->m_nPlayerID);
			return 0;
		}
	}
	
	for( i=0; i<nMaxLookOnNumber; i++ )
	{
		if( !m_LookerOn[i].IsValid() )
		{	
			m_LookerOn[i].Clear();
			m_LookerOn[i].SetBase(pUser->m_iUin, pUser->m_nPlayerID, pUser->m_nChair );
//			SendBaseGuessInfo(pUser->m_nPlayerID);
			m_nCurLookOnNumber ++;
			printf("\nlooker enter find place is %d, PlayerID: %d \n", m_nCurLookOnNumber-1, pUser->m_nPlayerID );
			return 0;
		}
	}

	return 0xf000;	//unknown error
}

//����뿪 
int		GuessSvr::PlayerExit(short nPlayerID)
{
	for( int i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
	{
		if( /*m_sPlayerID[i] == */nPlayerID == m_Players[i].sPlayerID )
		{
			m_Players[i].Clear();
//			m_sPlayerID[i] = -1;
//			m_unPlayerUin[i] = 0;
//			memset( m_chPlayerNickName[i], 0, sizeof(m_chPlayerNickName[i]) );
		}
	}
	LookerExit(nPlayerID);

	m_bHasSetBaseMoney = FALSE;
	SetBaseMoney(0);
	return 0;
}

//�Թ����뿪
int		GuessSvr::LookerExit(short nPlayerID)
{
	for( int i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
	{
		if( nPlayerID == m_LookerOn[i].sPlayerID )
		{
			//�����ע�� ���� //�Ѿ�������ע
			if( m_LookerOn[i].IsGuessMoneyValid() || 
				m_LookerOn[i].IsReqGuessMoneyValid() )
			{
				m_LookerOn[i].byExit	= 1;
			}
			else
			{
				//�򵥵�������
				m_LookerOn[i].Clear();
				m_nCurLookOnNumber--;	//������1
			}

			//����
			m_pServer->UnlockMoney(nPlayerID, NULL);
		}
	}
	// glacier 2009-11-20 add
	return 0;
}

int		GuessSvr::SendBaseGuessMoney()
{
	GAME_CMD_DATA data;
	//���ͷ���Ļ�����Ϣ
	GUESS_ROOM_INFO gri;
	gri.nChargeMode = m_eChargeMode;
	gri.unMaxBaseGuessMoney = m_unMaxBaseGuessMoney;
	gri.unMinBaseGuessMoney = m_unMinBaseGuessMoney;
	gri.unLookerGuessMinMoney = m_unLookerGuessMinMoney;
	gri.unLookerGuessMaxMoney = m_unLookerGuessMaxMoney;
	gri.unBaseGuessMoney = m_unBaseGuessMoney;
	gri.nGameStep = m_nGameStep;

	data.cCmdID = SID_GUESS_ROOM_INFO;
	data.cChair = -1;
	data.nDataLen = 1 + gri.Encode(data.data);
	m_pServer->SendGameData( (char*)&data, offsetof(GAME_CMD_DATA,data)+data.nDataLen, 0 );

	return 0;
}

void		GuessSvr::GetDataAfterPump(BOOL bLookOn, BOOL bVip, unsigned int& unData)
{
	if( eGCMPump==m_eChargeMode )
	{
		if( bLookOn )
		{
			unData = unData * ( bVip ? (100-m_nRateLookOnVip) :	(100-m_nRateLookOn) ) / 100;
		}
		else
		{
			unData = unData * ( bVip ? (100-m_nRatePlayerVip) :	(100-m_nRatePlayer) ) / 100;
		}
	}
	return;
}
void		GuessSvr::GetDataAfterPumpPeace(BOOL bLookOn, BOOL bVip, unsigned int& unData)
{
	if( eGCMPump==m_eChargeMode )
	{
//		if( bLookOn )
		{
			unData = unData * ( bVip ? (100-m_nRatePlayerPeaceVip) :	(100-m_nRatePlayerPeace) ) / 100;
		}
//		else
		{
//			unData = unData * ( bVip ? (100-m_nRatePlayerVip) :	(100-m_nRatePlayer) ) / 100;
		}
	}
	return;
}
int		GuessSvr::SendBaseGuessInfo(short nPlayerID)
{
	int nIntLen = 4; //sizeof(unsigned int)/sizeof(char);

	GAME_CMD_DATA data;
	//���ͷ���Ļ�����Ϣ
	{
		GUESS_ROOM_INFO gri;
		gri.nChargeMode = m_eChargeMode;
		gri.unMaxBaseGuessMoney = m_unMaxBaseGuessMoney;
		gri.unMinBaseGuessMoney = m_unMinBaseGuessMoney;
		gri.unLookerGuessMinMoney = m_unLookerGuessMinMoney;
		gri.unLookerGuessMaxMoney = m_unLookerGuessMaxMoney;
		gri.unBaseGuessMoney = m_unBaseGuessMoney;
		gri.nGameStep = m_nGameStep;

		data.cCmdID = SID_GUESS_ROOM_INFO;
		data.cChair = -1;
		data.nDataLen = 1 + gri.Encode(data.data);
		m_pServer->SendGameDataTo(nPlayerID, (char*)&data, offsetof(GAME_CMD_DATA,data)+data.nDataLen, 0 );
	}

	data.cCmdID = SID_GUESS_BASE_INFO;
	data.cChair = -1;
	GUESS_BASE_INFO gbi;
	//����, �ܵ�Ǯ��, ����, qq����  ѹע����
	for( int nType=eGMBegin; nType<eGMOverflow; nType++ )
	{
		unsigned int unTotleMoney = 0;
		unsigned int unTotleMoney2 = 0;
		unsigned int unPersonsCount = 0;
		int	nPoint = 0;
	
		gbi.nType = nType;
		//ע�� gbi��������Ҳ��80����!!!!!
		for( int i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
		{
			if( m_LookerOn[i].IsValid() && m_LookerOn[i].IsGuessMoneyValid() )
			{
				gbi.unUin[nPoint] = m_LookerOn[i].unUin;
				gbi.unMoney[nPoint] = m_LookerOn[i].unGuessMoney[nType];
				gbi.unMoney15Step[nPoint] = m_LookerOn[i].unGuessMoney15Step[nType];
				GetDataAfterPump(TRUE, m_LookerOn[i].byVip, gbi.unMoney[nPoint] );
				GetDataAfterPump(TRUE, m_LookerOn[i].byVip, gbi.unMoney15Step[nPoint] );
				
				unTotleMoney += m_LookerOn[i].unGuessMoney[nType];
				unTotleMoney2 += gbi.unMoney[nPoint];

				unPersonsCount ++;
				nPoint ++;
			}
		}
		gbi.unTotleMoney = unTotleMoney2;
		gbi.nPersons	= (int)unPersonsCount;

		data.nDataLen = 1 + gbi.Encode(data.data);
		m_pServer->SendGameDataTo(nPlayerID, (char*)&data, offsetof(GAME_CMD_DATA,data)+data.nDataLen, 0 );

		if( unTotleMoney!=m_unGuessMoney[nType] )
		{
			char buf[256] = {0};
			_snprintf( buf, sizeof(buf), "!!!!!!!!!!!!ERROR tpye %d totlemoney is not equal: old:%d, new:%d \n", nType, m_unGuessMoney[nType], unTotleMoney );
			printf(buf);
			if( m_pLogFile )
			{
				m_pLogFile->Log(buf);
			}
			//����Ϊ�����
			m_unGuessMoney[nType] = unTotleMoney;
		}
		if( unPersonsCount!=(unsigned int)(m_nPersonCount[nType]) )
		{
			char buf[256] = {0};
			_snprintf( buf, sizeof(buf), "!!!!!!!!!!!!ERROR type %d totle persons is not equal: old:%d, new:%d \n", nType, m_nPersonCount[nType], unPersonsCount );
			printf(buf);
			if( m_pLogFile )
			{
				m_pLogFile->Log(buf);
			}
			//����Ϊ���������
			m_nPersonCount[nType] = (int)unPersonsCount;
		}
	}

	return 0;
}

//��������趨��ʼ�׷�
int		GuessSvr::PlayerRequestSetBaseMoney(short nPlayerID, unsigned int nBaseMoney )
{
	if( m_unMaxBaseGuessMoney>0 && nBaseMoney>m_unMaxBaseGuessMoney )
	{
		char szMsg[256] = {0};
		_snprintf(szMsg, sizeof(szMsg), "�׷ֳ�������%u��������Ϸ�Զ�����Ϊ��С�����ĵ׷֡�", m_unMaxBaseGuessMoney);
		SendShowMessage2User(nPlayerID, szMsg);

		m_unBaseGuessMoney = m_unMinBaseGuessMoney;
		if( m_pLogFile )
		{
			m_pLogFile->Log("***** player set base money overflow, set is:%d, when max is:%d", nBaseMoney, m_unMaxBaseGuessMoney);
		}
		return 1;
	}
	if( m_unMinBaseGuessMoney>0 && nBaseMoney<m_unMinBaseGuessMoney )
	{
		char szMsg[256] = {0};
		_snprintf(szMsg, sizeof(szMsg), "�׷ֵ�������%u��������Ϸ�Զ�����Ϊ��С�����ĵ׷֡�", m_unMinBaseGuessMoney);
		SendShowMessage2User(nPlayerID, szMsg);

		m_unBaseGuessMoney = m_unMinBaseGuessMoney;

		if( m_pLogFile )
		{
			m_pLogFile->Log("***** player set base money downflow, set is:%d, when min is:%d", nBaseMoney, m_unMinBaseGuessMoney);
		}
		return 2;
	}
	
	{
		int nMoney = 0;
		m_pServer->GetMoney(nPlayerID, &nMoney);
		if( nMoney<0 || nMoney<nBaseMoney )
		{
			m_unBaseGuessMoney = m_unMinBaseGuessMoney;
			char szMsg[256] = {0};
			_snprintf(szMsg, sizeof(szMsg), "������Ϸ�Ҳ���׷֣�������Ϸ�Զ�����Ϊ��С�����ĵ׷֡�");
			SendShowMessage2User(nPlayerID, szMsg);
			if( m_pLogFile )
			{
				m_pLogFile->Log("*****�����Ϸ�Ҳ���۵׽�,�����������Ͽͻ��˵Ĺ�ϵ! ���õĵ׽���%u, ��ҵ���Ϸ����%d",
					nBaseMoney, nMoney);
			}
			return 4;
		}	
	}

	m_unBaseGuessMoney	= nBaseMoney;	//��С�׷���--------Ϊ0 �����
	m_unSalouAdd = m_unBaseGuessMoney;

	// glacier 2009-12-8 add
	// ȥ�����¹��ܣ�������������
	m_unBaseGuessMoney = 0;
	m_unSalouAdd = 0;
	// add end

	return 0;
}

//��һظ��趨��ʼ�׷� nResult 0:�ܾ� 1:ͬ��
//int		GuessSvr::PlayerAnswerSetBaseMoney(short nPlayerID, int nResult);
//{
//}
int		GuessSvr::SendShowMessage2User(short nPlayerID, char* szMessage)
{
	GAME_CMD_DATA data;
	data.cCmdID = SID_GUESS_SHOW_MSG;
	data.cChair = -1;
	_snprintf( data.data, sizeof(data.data), "%s", szMessage );
	data.nDataLen = strlen(data.data)+1;
	if( data.nDataLen>1200 )
	{
		data. nDataLen = 1200;
	}
	m_pServer->SendGameDataTo(nPlayerID, (char *)&data, offsetof(GAME_CMD_DATA, data)+data.nDataLen, 0);
	return 0;
}
int		GuessSvr::SendShowMessage2UserModalLess(short nPlayerID, char* szMessage)
{
	GAME_CMD_DATA data;
	data.cCmdID = SID_GUESS_SHOW_MSG_ML;
	data.cChair = -1;
	_snprintf( data.data, sizeof(data.data), "%s", szMessage );
	data.nDataLen = strlen(data.data)+1;
	if( data.nDataLen>1200 )
	{
		data. nDataLen = 1200;
	}
	m_pServer->SendGameDataTo(nPlayerID, (char*)&data, offsetof(GAME_CMD_DATA, data)+data.nDataLen, 0);
	return 0;
}
//����������ӵ׷�
int		GuessSvr::PlayerRequestAddBaseMoney( short nPlayerID, unsigned int nAddedMoney )
{
	if ( m_bGameOver ) 
	{
		SendShowMessage2User(nPlayerID, "��Ϸ��û�п�ʼ���������ӵ׷֣�");
		return 4;
	}

	if( !m_bHasSetBaseMoney )
	{
		SendShowMessage2User(nPlayerID, "��һ�û�����õ׷֣��������ӵ׷֣�");
		return 4;
	}

	if( m_nPlayerRefusedAddBaseMoneyCount>=MAX_CONTINUE_REFUSE_COUNT )
	{
		SendShowMessage2User(nPlayerID, "������Ϸ���������ӵ׷֣�");
		return 1;
	}

	if( 0==nAddedMoney || nAddedMoney>2000000000 )
	{
		SendShowMessage2User(nPlayerID, "��Ч�׷֣�");
		return 2;
	}
	if( m_unMaxBaseGuessMoney>0 && m_unBaseGuessMoney+nAddedMoney>m_unMaxBaseGuessMoney )
	{
		char szMsg[256] = { 0 };
		_snprintf(szMsg, sizeof(szMsg), "���ӵĵ׷ֳ�������%u��������Ϸ������������%u�ĵ׷�", 
			m_unMaxBaseGuessMoney, m_unMaxBaseGuessMoney-m_unBaseGuessMoney);
		SendShowMessage2User(nPlayerID, szMsg);
		return 2;
	}

	int nMoney = 0;
	m_pServer->GetMoney(nPlayerID, &nMoney);
	if( nMoney<(int)nAddedMoney )
	{
		SendShowMessage2User(nPlayerID, "������Ϸ�Ҳ������ӵ׷֣�");
		return 4;
	}
	
	if( m_unBaseGuessMoneyAdd > 0 )
	{
		if( m_sPlayerIDReqAddBaseMoney==nPlayerID )
		{
			SendShowMessage2User(nPlayerID, "�ȴ��Է�Ӧ���ϴ�����׷�ӵĵ׷�" );
		}
		else
		{
			SendShowMessage2User(nPlayerID, "����Ӧ��Է�����׷�ӵ׷ֵ�����" );
		}
		return 5;
	}

	m_sPlayerIDReqAddBaseMoney = nPlayerID;
	m_unBaseGuessMoneyAdd = nAddedMoney;
	printf("request add base money :%d\n", m_unBaseGuessMoneyAdd);

	short nOtherPlayerID = 0;
	unsigned int uin = 0;
	for( int i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
	{
		if( m_Players[i].sPlayerID == nPlayerID )
		{
			uin = m_Players[i].unUin;
		}
		else
		{
			nOtherPlayerID = m_Players[i].sPlayerID;
		}
	}
	
	GAME_CMD_DATA data;
	data.cCmdID = SID_REQUEST_ADD_BASE_GUESS_MONEY;
	data.cChair = -1;
	data.nDataLen = INT_LENGTH_DEFINE*2 + 1;
	char* pData = data.data;
	DataToSz(uin, pData);
	pData += INT_LENGTH_DEFINE;
	DataToSz(nAddedMoney, pData);
	//������Ϣ�������һ�����
	m_pServer->SendGameDataTo(nOtherPlayerID, (char *)&data, offsetof(GAME_CMD_DATA, data)+data.nDataLen);
	return 0;
}

//��һظ����ӵ׷� nResult 0:�ܾ� 1:ͬ��
int		GuessSvr::PlayerAnswerAddBaseMoney( short nPlayerID, int nResult )
{
	if ( m_bGameOver ) 
	{
		SendShowMessage2User(nPlayerID, "��Ϸ�Ѿ�������׷�ӵ׽�ʧ�ܣ�");
		return 0xff;
	}

	if( m_unBaseGuessMoneyAdd==0 )
	{
		return 0xff;
	}

	if( nResult!=0 )
	{
		int nMoney = 0;
		m_pServer->GetMoney(nPlayerID, &nMoney);
		if( nMoney<(int)m_unBaseGuessMoneyAdd )
		{
			nResult = 0;
			printf("\nplayer money is %d, add base id:%d\n", nMoney, m_unBaseGuessMoneyAdd);
			SendShowMessage2User(nPlayerID, "������Ϸ�Ҳ������ӵ׷֣�" );
		}
	}

	if( 0==nResult )
	{
		//��ͬ��
		m_nPlayerRefusedAddBaseMoneyCount ++;
	
		m_unBaseGuessMoneyAdd = 0;

		GAME_CMD_DATA data;
		data.cCmdID = SID_REQUEST_ADD_BASS_GUESS_MONEY_ANSWER;
		data.cChair = -1;
		char szMsg[128] = {0};
		if( m_Players[0].sPlayerID == nPlayerID )
		{
			_snprintf( szMsg, sizeof(szMsg), "���%s��ͬ�����ӵ׷֡�", m_Players[0].szNickName );
		}
		else
		{
			_snprintf( szMsg, sizeof(szMsg), "���%s��ͬ�����ӵ׷֡�", m_Players[1].szNickName );
		}
		data.nDataLen = strlen(szMsg) + INT_LENGTH_DEFINE + 1;
		_snprintf( &data.data[INT_LENGTH_DEFINE], sizeof(data.data)-INT_LENGTH_DEFINE, "%s", szMsg );
		DataToSz(m_unBaseGuessMoney, data.data);

		for( int i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
		{
			if( nPlayerID!=m_Players[i].sPlayerID )
			{
				m_pServer->SendGameDataTo(m_Players[i].sPlayerID, (char *)&data, 
					offsetof(GAME_CMD_DATA, data)+data.nDataLen);
			}
		}
	}
	else
	{
		//ͬ��
		m_nPlayerRefusedAddBaseMoneyCount = 0;
		int i = 0;
		for( i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
		{
			USER_SCORE score;
			memset(&score, 0, sizeof(score));
			score.lMoney = -((int)m_unBaseGuessMoneyAdd);
			m_pServer->SetGameScoreEx(m_Players[i].sPlayerID, m_Players[i].unUin,
				sizeof(score), (void*)&score);
		}
		if( m_pLogFile )
		{
			m_pLogFile->Log("\n*****���ͬ������%u�ĵ׽�,�۳��׽�", m_unBaseGuessMoneyAdd);
		}

		GAME_CMD_DATA data;
		data.cCmdID = SID_REQUEST_ADD_BASS_GUESS_MONEY_ANSWER;
		data.cChair = -1;
		char szMsg[128] = {0};
		m_unBaseGuessMoney += m_unBaseGuessMoneyAdd;
//		if( m_Players[0].sPlayerID == nPlayerID )
		{
			_snprintf( szMsg, sizeof(szMsg), "˫����Ҷ�ͬ������%u�׷֡�", /*m_Players[0].szNickName,*/ m_unBaseGuessMoneyAdd );
		}
//		else
		{
//			sprintf( szMsg, "���%sͬ������%u�׷֡�", m_Players[1].szNickName, m_unBaseGuessMoneyAdd );
		}
		data.nDataLen = strlen(szMsg) + INT_LENGTH_DEFINE + 1;
		_snprintf( &data.data[INT_LENGTH_DEFINE], sizeof(data.data)-INT_LENGTH_DEFINE, "%s", szMsg );
		DataToSz( m_unBaseGuessMoney, data.data );

		for( i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
		{
//			if( m_Players[i].sPlayerID != nPlayerID )
			{
				m_pServer->SendGameDataTo(m_Players[i].sPlayerID, (char *)&data, 
					offsetof(GAME_CMD_DATA, data)+data.nDataLen);
			}
		}
//		m_pServer->SendGameData((LPCSTR)&data, offsetof(GAME_CMD_DATA, data)+data.nDataLen);
	}
	
	//�������ӵĵ׷�����
	m_unBaseGuessMoneyAdd = 0;
	m_sPlayerIDReqAddBaseMoney = -1;

	return 0;
}

//�Թ�����ע/��ע
int		GuessSvr::LookerGuessMoney(short nPlayerID, int nCount, int* pnGuessID, unsigned int* punGuessMoney )
{
	printf("\n###########LookerGuessMoney\n");

	if( nCount<=0 || NULL==pnGuessID || NULL==punGuessMoney )
	{
		if( m_pLogFile )
		{
			m_pLogFile->Log("*****error request guess money when count %d < 0 or data is null", nCount);
		}
		printf("error request guess money when count %d < 0 or data is null", nCount);
		return 0x40;
	}

	if( m_bGameOver )
	{
		if( m_pLogFile )
		{
			m_pLogFile->Log("*****error request guess money when game is over\n");
		}
		printf("error request guess money when game is over");
		return 0x20;
	}

	if( m_unMinBaseGuessMoney>0 && 0==m_unBaseGuessMoney )
	{
		printf("base money is 0!");
		SendShowMessage2User(nPlayerID, "������Ϸ������ע");
		return 0x02;
	}

	BOOL bPlayer = FALSE;
	int	 nPlayerPos = 0;
	for( int k=0; k<MAX_GAME_PLAYER_COUNT; k++ )
	{
		if( m_Players[k].sPlayerID == nPlayerID )
		{
			bPlayer = TRUE;
			nPlayerPos = k;
			break;
		}
	}
	
	if( bPlayer )
	{
		if( m_nValues[1]==nPlayerPos ) //�ڷ����
		{
			for( int i=0; i<nCount; i++ )
			{
				int nID = (int)(pnGuessID[i]);
				if( nID==eGMRedWin && punGuessMoney[i]>0 )
				{
					SendShowMessage2User(nPlayerID,
						"�Բ�����������Է�ʤ��" );
					return 0xf4;
				}
			}
		}
		else if( m_nValues[0]==nPlayerPos )
		{
			for( int i=0; i<nCount; i++ )
			{
				int nID = (int)(pnGuessID[i]);
				if( nID==eGMBlackWin && punGuessMoney[i]>0 )
				{
					SendShowMessage2User(nPlayerID,
						"�Բ�����������Է�ʤ��" );
					return 0xf4;
				}
			}
		}
	}

	for( int j=0; j<MAX_GAME_LOOKON_COUNT; j++ )
	{
		if( nPlayerID==m_LookerOn[j].sPlayerID )
		{
			printf("\nfind player\n");
			LPPLAYERLOOKON pLookOn = &m_LookerOn[j];
			if( m_nGameStep<GAME_PARTITION && pLookOn->byGuessCount>=MAX_LOOKON_GUEES_COUNT_FIRST ) 
			{
				SendShowMessage2User(nPlayerID, "�Բ������Ѿ��������־�����ע����������" );
				return 0x08;
			}
			if( m_nGameStep>=GAME_PARTITION && pLookOn->byGuessCount>=MAX_LOOKON_GUEES_COUNT )
			{
				SendShowMessage2User(nPlayerID, "�Բ������Ѿ�����������ע����������" );
				return 0x08;
			}

			{
				unsigned int nTotleMoney = 0;
				for( int m=0; m<nCount; m++ )
				{
					nTotleMoney += (punGuessMoney[m]);
					printf("guess money %d \n", punGuessMoney[m] );
				}
				if( nTotleMoney<m_unLookerGuessMinMoney && m_unLookerGuessMinMoney!=0 )
				{
					char szMsg[256] = {0};
					_snprintf(szMsg, sizeof(szMsg), "�Բ���������ע�������ע����С�޶�%d��",m_unLookerGuessMinMoney);
					SendShowMessage2User(nPlayerID, szMsg);
					return 0x08;
				}
				if( nTotleMoney>m_unLookerGuessMaxMoney && m_unLookerGuessMaxMoney!=0 )
				{
					char szMsg[256] = {0};
					_snprintf(szMsg, sizeof(szMsg), "�Բ���������ע�����ע������޶�%d��",m_unLookerGuessMaxMoney);
					SendShowMessage2User(nPlayerID, szMsg);
					return 0x08;
				}
			}

			if( pLookOn->byFirstGuess )
			{
				pLookOn->byGuessCount = 0;
				pLookOn->byCurReqMoneyPoint = 0;
			}

/*			pLookOn->byGuessCount ++;

			if( pLookOn->byCurReqMoneyPoint>=LAST_STEPS_REQ_MONEY_KEEP )
			{
				pLookOn->byCurReqMoneyPoint = 0;
			}
//			else if( pLookOn->byCurReqMoneyPoint<0 )
//			{
//				pLookOn->byCurReqMoneyPoint = 0;
//			}

			//����ϴα����step�͸ôα������ͬ,�򱣴浽�ϴ�һ��
			BYTE	byCurReqMoneyPoint	= (LAST_STEPS_REQ_MONEY_KEEP-1+pLookOn->byCurReqMoneyPoint)%LAST_STEPS_REQ_MONEY_KEEP;
			if( pLookOn->byFirstGuess )
			{
				byCurReqMoneyPoint = pLookOn->byCurReqMoneyPoint;
				for( int i=0; i<eGMOverflow; i++ )
				{
					pLookOn->LastReqMoney[byCurReqMoneyPoint].unLastReqMoney[i] = 0;
				}
				pLookOn->LastReqMoney[byCurReqMoneyPoint].nStep = m_nGameStep;
			}
			else
			{
				//���step��ͬ, ��ô+1
				if( pLookOn->LastReqMoney[byCurReqMoneyPoint].nStep != m_nGameStep )
				{
					byCurReqMoneyPoint = pLookOn->byCurReqMoneyPoint;
					pLookOn->LastReqMoney[byCurReqMoneyPoint].nStep = m_nGameStep;
					//�Ȱѵ�ǰ������0
					for( int i=0; i<eGMOverflow; i++ )
					{
						pLookOn->LastReqMoney[byCurReqMoneyPoint].unLastReqMoney[i] = 0;
					}
				}
			}
*/
			for( int i=0; i<nCount; i++ )
			{
				int nID = (int)(pnGuessID[i]);
				if( nID>=eGMBegin && nID<eGMOverflow && punGuessMoney[i]>0 )
				{
					pLookOn->unReqGuessMoney[nID] += (punGuessMoney[i]);
				}
			}
		
//			pLookOn->byCurReqMoneyPoint = byCurReqMoneyPoint + 1; 

			//���������ע
			if( bPlayer && !m_bUnLockPlayerMoney )
			{
				ProcessLockMoneyOK(pLookOn, TRUE);
				return 0;
			}
			
			int nRes = m_pServer->LockMoney(nPlayerID, NULL);

			printf("\nlock money %d\n", nRes );

			if( nRes==0 )	// dengdai
			{
				return 0;
			}
			else if( nRes==1 )
			{
				ProcessLockMoneyOK(pLookOn,FALSE);
				return 0; //�����ɹ�
			}
			else if( nRes<0 )
			{
				pLookOn->RollBack();
				SendShowMessage2User(nPlayerID, "�Բ���������Ϸ��ʧ�ܣ���עʧ�ܡ�");
				return 1;
			}

			return 0;
		}
	}
	printf("�Ҳ������\n");
	SendShowMessage2User(nPlayerID, "�Բ���������ע�������࣬����ʱ������ע��");
	return 0x80;	//�Ҳ������
}

int		GuessSvr::PlayerRunAway( short nPlayerID, unsigned int unUin )
{
	//��Ч�Ծ�
	InvalidGuessMode(FALSE);

	m_bHasSetBaseMoney = FALSE;

	if( m_unBaseGuessMoney>0 )
	{
		for( int i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
		{
			USER_SCORE score;
			memset(&score, 0, sizeof(score) );
			if( /*m_sPlayerID[i] == */nPlayerID == m_Players[i].sPlayerID )
			{
				int nMoney = GetUserMoney(nPlayerID, unUin);
				//�۳�10���׷�
				int nCutMoney = (int)((10-1)*m_unBaseGuessMoney);
				if( nMoney>nCutMoney )
				{
					nMoney = nCutMoney;
				}
				score.lUserScore = score.lUserScore + 1;
				score.lMoney = -nMoney;
				score.lSharedMoney = nMoney + m_unBaseGuessMoney;
			    score.lBillType = 2002;
				score.dwEscapeCount = 1;
				m_pServer->SetGameScoreEx( nPlayerID, unUin, sizeof(score), (void*)&score);

				memset(&score, 0, sizeof(score) );
				score.lUserScore = -1;
				m_pServer->SetGameScoreEx( nPlayerID, unUin, sizeof(score), (void*)&score);
				
				if( m_pLogFile )
				{
					m_pLogFile->Log("\n*****���������,id:%d, uin:%u,��%d�ĵ׽�,(ԭ�׽𲻷���,���Կ�9���׽�)\n", 
						nPlayerID, unUin, nCutMoney);
				}
				printf("player run away cut 10 base guess money!\n");
			}
			else
			{
				score.lMoney = m_unBaseGuessMoney;
				m_pServer->SetGameScoreEx( m_Players[i].sPlayerID, m_Players[i].unUin, 
					sizeof(score), (void*)&score);
				printf("other player run away return his base guess money!\n");
				if( m_pLogFile )
				{
					m_pLogFile->Log("*****������������, return his base guess money!\n");
					m_pLogFile->Log("�����%u���ص׽�%d\n",m_Players[i].unUin,score.lMoney);
				}
			}
		}
	}
	SetBaseMoney(0);
	return 0;
}

//��Ϸ��ʼ
//����һЩ��ʼ������
int		GuessSvr::SetGameBegin()
{
//	if( m_unBaseGuessMoney<m_unMinBaseGuessMoney )
//	{
//		m_unBaseGuessMoney = m_unMinBaseGuessMoney;
//	}
	m_sPlayerIDReqAddBaseMoney = -1;
	m_unBaseGuessMoneyAdd = 0;

	m_nPlayerRefusedAddBaseMoneyCount = 0;
	m_nGameStep	= 0;
	m_bGameOver = FALSE;
	m_b100WValid = TRUE;

	m_unBaseGuessMoney = 0;

	m_bHasSetBaseMoney = FALSE;

	//��ѵĳ�ʼ������
	int i = 0;
	for( i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
	{
		if( m_LookerOn[i].byExit )
		{
			m_LookerOn[i].Clear();
			m_nCurLookOnNumber --;
		}
		else
		{
			m_LookerOn[i].byFirstGuess = TRUE;
			m_LookerOn[i].byCurReqMoneyPoint	= 0; //ָ��ǰ��Ҫ�����λ��
			m_LookerOn[i].byExit	= 0;	//�Ƿ��Ѿ��뿪�˸�������Ϸ
			m_LookerOn[i].byGuessCount	= 0;
			m_LookerOn[i].lWinMoney = 0;
			m_LookerOn[i].ClearGuessMoney();
			memset(&m_LookerOn[i].LastReqMoney, 0, sizeof(LASTREQUESTMONEY) );
		}
	}

	for( i=eGMBegin; i<eGMOverflow; i++ )
	{
		m_nPersonCount[i]	= 0;	//Ͷע3�����������
		m_unGuessMoney[i]	= 0;	//Ͷע����Ǯ��
	}

	for( i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
	{
		m_Players[i].lWinMoney = 0;
	}

	//�ж��Ƿ�˫������3����ʦ.... 
	char szMsg[256] = {0};
	char szBuf[16] = {0};
	int nRank = 100;
	nRank = GetPlayerRank(m_Players[0].sPlayerID, szBuf, sizeof(szBuf));
	if( m_nRankUseful<10000 && nRank<=m_nRankUseful )	//
	{
		char szBuf2[16] = {0};
		nRank = GetPlayerRank(m_Players[1].sPlayerID, szBuf2, sizeof(szBuf2));
		if( nRank<=3 )
		{
			_snprintf(szMsg, sizeof(szMsg), "%s %s[%u]��%s %s[%u]�������й�������Ϸ������%d���Ծ���", 
				szBuf, m_Players[0].szNickName, m_Players[0].unUin, 
				szBuf2, m_Players[1].szNickName, m_Players[1].unUin, 
				/*m_pServer->GetGameTableID()/100, */(m_pServer->GetGameTableID()%100)+1 );
			m_pServer->BroadcastSysMsg( szMsg, strlen(szMsg), 0, 0 );
		}
	}
	time(&m_tStartTime);
	return 0;
}

//��Ϸ��������
//eMode ��Ϸ�Ժ��ַ�ʽ����  -1 ��ʾ��Ч�Ծ�
int		GuessSvr::SetGameEnd(eGuessMode eMode)
{
	if( m_pLogFile )
	{
		m_pLogFile->Log("����GuessSvr::SetGameEnd\n");
	}

	m_bGameOver = TRUE;

	//����׷�С�ڵ���0 ����
	if( m_unBaseGuessMoney==0 )
	{
//		m_bHasSetBaseMoney = FALSE;
//		return 0;
	}

	//��Ч�Ծ�
	if( eGMInvalid==eMode )
	{
		InvalidGuessMode();
		m_bHasSetBaseMoney = FALSE;
		return 0;
	}
	
	time_t endTime;
	time(&endTime);
	if( (endTime-m_tStartTime)<=m_nValidTime ) //2�����ڽ���
	{
		InvalidGuessMode();
		m_bHasSetBaseMoney = FALSE;
		return 0;
	}
	
	printf("@@@ last player %d  %d  %d \n", m_LookerOn[0].LastReqMoney[0].unLastReqMoney[0], 
		m_LookerOn[0].LastReqMoney[0].unLastReqMoney[1],
		m_LookerOn[0].LastReqMoney[0].unLastReqMoney[2]);
	printf("@@@ last player %d  %d  %d \n", m_LookerOn[1].LastReqMoney[0].unLastReqMoney[0], 
		m_LookerOn[1].LastReqMoney[0].unLastReqMoney[1],
		m_LookerOn[1].LastReqMoney[0].unLastReqMoney[2]);

	int i = 0;
	for( i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
	{
		if( m_LookerOn[i].IsValid() && m_LookerOn[i].IsGuessMoneyValid() )
		{
			//�ȶԵ���10���ۼӵ�Ǯ ��������
			CutLastTenStepsMoney(&m_LookerOn[i],NULL);
		}
	}

	printf("\nGame End while Mode is %d\n", eMode);
	if (eGMBlackWin == eMode || eGMPeace == eMode || eGMRedWin == eMode )
	{
		int i;
		for( i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
		{
			if( m_LookerOn[i].IsValid() && m_LookerOn[i].IsGuessMoneyValid() )
			{
				int j = 0;
				USER_SCORE score;
				memset( &score, 0, sizeof(score) );
				for( int m=0; m<eGMOverflow; m++ )
				{
					j += m_LookerOn[i].unGuessMoney[m];
				}
				int nRate = m_LookerOn[i].byVip ? m_nRateLookOnVip : m_nRateLookOn;
				score.lSharedMoney  = ((float)j) * nRate / 100;
				score.lBillType = 2101;
				score.lUserScore = score.lUserScore + 1;
				m_pServer->SetGameScoreEx( m_LookerOn[i].sPlayerID, m_LookerOn[i].unUin,
					sizeof(score), (void*)&score);

				memset(&score, 0, sizeof(score) );
				score.lUserScore = -1;
				m_pServer->SetGameScoreEx( m_LookerOn[i].sPlayerID, m_LookerOn[i].unUin,
					sizeof(score), (void*)&score);
			}
		}
		for( i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
		{
			int	nRate = m_nRatePlayerPeace;
			if( m_Players[i].byVip )
			{
				nRate = m_nRatePlayerPeaceVip;
			}
			if (eGMPeace != eMode)
			{
				nRate = m_nRatePlayer;
				if( m_Players[i].byVip )
				{
					nRate = m_nRatePlayerVip;
				}
			}
			USER_SCORE score;
			memset(&score, 0, sizeof(score) );
			score.lSharedMoney = (long)( (m_unBaseGuessMoney - m_unSalouAdd) * nRate /100 );
			score.lBillType = 2101;
			score.lUserScore = score.lUserScore + 1;
			m_pServer->SetGameScoreEx(m_Players[i].sPlayerID, m_Players[i].unUin, 
				sizeof(score), (void*)&score);

			memset(&score, 0, sizeof(score) );
			score.lUserScore = -1;
			m_pServer->SetGameScoreEx(m_Players[i].sPlayerID, m_Players[i].unUin, 
				sizeof(score), (void*)&score);

			memset(&score, 0, sizeof(score) );
			score.lSharedMoney = (long)( m_unSalouAdd * nRate /100 );
			score.lBillType = 2001;
			score.lUserScore = score.lUserScore + 1;
			m_pServer->SetGameScoreEx(m_Players[i].sPlayerID, m_Players[i].unUin, 
				sizeof(score), (void*)&score);

			memset(&score, 0, sizeof(score) );
				score.lUserScore = -1;
				m_pServer->SetGameScoreEx(m_Players[i].sPlayerID, m_Players[i].unUin, 
				sizeof(score), (void*)&score);
		}	
	}

	switch( eMode )
	{
	case eGMBlackWin:
		BlackWinGuessMode();
		break;
	case eGMPeace:
		PeaceGuessMode();
		break;
	case eGMRedWin:
		RedWinGuessMode();
		break;
	default:
		InvalidGuessMode();
	}

	//����������
	for( i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
	{
		if( m_LookerOn[i].byExit )
		{
			m_LookerOn[i].Clear();
			m_nCurLookOnNumber --;
		}
	}

	m_bHasSetBaseMoney = FALSE;

	return 0;
}
unsigned int	GuessSvr::SetBaseMoney(unsigned int unMoney)
{
	unsigned int unBaseMoney = m_unBaseGuessMoney;
	m_unBaseGuessMoney = unMoney;
	return unBaseMoney;
}
unsigned int GuessSvr::GetBaseMoney()
{
	return m_unBaseGuessMoney;
}
void	GuessSvr::SetUnLockPlayerMoneyAfterGuess( BOOL bUnLock )
{
	m_bUnLockPlayerMoney	= bUnLock;
}
//������Ϸ�ҵĽ�� 
int		GuessSvr::OnLockUserMoney(short nPlayerID, int nResult)
{
	if( m_bGameOver )
	{
		printf("\nGuessSvr::OnLockUserMoney game is over\n");
		return 0;
	}
	
	BOOL bPlayer = FALSE;
	{
		for( int k=0; k<MAX_GAME_PLAYER_COUNT; k++ )
		{
			if( m_Players[k].sPlayerID == nPlayerID )
			{
				bPlayer = TRUE;
				break;
			}
		}
	}

	for ( int i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
	{
		if( nPlayerID==m_LookerOn[i].sPlayerID )
		{
			//������Ϸ��ʧ��
			if( 0!=nResult )
			{
				//������Ϣ���� �Թ��� !!!!!!!!!1
				printf("\nGuessSvr::OnLockUserMoney lockmoeny failed\n");
				GAME_CMD_DATA data;
				data.cCmdID = SID_GUESS_SHOW_MSG;
				data.cChair = -1;
				_snprintf(data.data, sizeof(data.data), "�Բ���������Ϸ��ʧ�ܣ���עʧ�ܡ�");
				printf(data.data);
				data.nDataLen = strlen(data.data)+1;
				m_pServer->SendGameDataTo( nPlayerID, (char *)&data, offsetof(GAME_CMD_DATA, data)+data.nDataLen);
				m_LookerOn[i].RollBack();
				return 1;
			}
			
			ProcessLockMoneyOK(&m_LookerOn[i], bPlayer);

			return 0;
		}
	}
	printf("\nGuessSvr::OnLockUserMoney can't find player\n");
	return 0x80;// �Ҳ�����Ӧ�����
}

//�õ����/�Թ��ߵ���Ϸ�� ���С��0 ������Ϊ0
int		GuessSvr::GetUserMoney(short nPlayerID, unsigned int unUin)
{
	int nMoney = 0;
	m_pServer->GetMoney(nPlayerID, &nMoney);
	if( nMoney<0 )
	{
		return 0;
	}
	return nMoney;
}

//��Ϸ����++;
int		GuessSvr::AddGameStep(int nStep)
{
	if( m_nGameStep<GAME_PARTITION && m_nGameStep+nStep>=GAME_PARTITION )
	{
		for( int i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
		{
			m_LookerOn[i].byGuessCount = MAX_LOOKON_GUEES_COUNT_FIRST;
		}
	}
	m_nGameStep += nStep;
	return 0;
}

//��ȡ�����ļ� 
int		GuessSvr::ReadCfgFile(const char* pszFileName)
{
	PSTR pszCfgItem;
	pszCfgItem = strrchr(pszFileName, '/');
	if(NULL == pszCfgItem) 
		pszCfgItem = (PSTR)pszFileName;
	else
		pszCfgItem++;
	
	
	int iRet = m_pConfigFile->OpenFile("../config/chnchess.cfg");  /*���ļ�*/
	if(0 != iRet)
	{
        printf("Read file %s failed!\n",pszFileName);
		return 1;
	}
	
	//�շ�ģʽ eGuessChargeMode����
	m_pConfigFile->GetItemValue(pszCfgItem, "GuessMode",       m_eChargeMode,    eGCMPump);
	
	int nTemp = 0;
	//���׷���--------Ϊ0 �����
	m_pConfigFile->GetItemValue(pszCfgItem, "MaxBaseGuessMoney",   nTemp,    0);
	m_unMaxBaseGuessMoney = (unsigned int)nTemp;
	//��С�׷���--------Ϊ0 �����
	m_pConfigFile->GetItemValue(pszCfgItem, "MinBaseGuessMoney",   nTemp,    0);
	m_unMinBaseGuessMoney = (unsigned int)nTemp;
	
	//�Թ��߾��µ���С���
	m_pConfigFile->GetItemValue(pszCfgItem, "LookerGuessMinMoney",    nTemp,    1000);
	m_unLookerGuessMinMoney = (unsigned int)nTemp;
	//�Թ��߾��µ������ (����)
	m_pConfigFile->GetItemValue(pszCfgItem, "LookerGuessMaxMoney",    nTemp,    0);
	m_unLookerGuessMaxMoney = (unsigned int)nTemp;

	//����Թ�����
	m_pConfigFile->GetItemValue(pszCfgItem, "MaxLookOnNumber",    m_nMaxLookOnNumber,    200);


	//��ͨ�Թ��ߵķ������
	m_pConfigFile->GetItemValue(pszCfgItem, "RateLookOn",    m_nRateLookOn,    10);
	//vip�Թ��ߵķ������
	m_pConfigFile->GetItemValue(pszCfgItem, "RateLookOnVip",    m_nRateLookOnVip,    10);
	
	//��ҵķ������
	m_pConfigFile->GetItemValue(pszCfgItem, "RatePlayer",    m_nRatePlayer,    10);
	//������ҵķ����v��
	m_pConfigFile->GetItemValue(pszCfgItem, "RatePlayerVip",    m_nRatePlayerVip,    10);
	
	//��Һ���ķ������
	m_pConfigFile->GetItemValue(pszCfgItem, "RatePlayerPeace",    m_nRatePlayerPeace,    5);
	//������Һ���ķ������
	m_pConfigFile->GetItemValue(pszCfgItem, "RatePlayerPeaceVip",    m_nRatePlayerPeaceVip,    5);
	
	//��Ҳʽ���ɱ���
	m_pConfigFile->GetItemValue(pszCfgItem, "RatePlayerPercent",    m_nRatePlayerPercent,    5);
	//���������ɱ���
	m_pConfigFile->GetItemValue(pszCfgItem, "RatePlayerPercentVip",    m_nRatePlayerPercentVip,    5);
	
	//��ҵķ����
	m_pConfigFile->GetItemValue(pszCfgItem, "ServicePlayer",    m_nServicePlayer,    0);
	//�Թ��ߵķ����	
	m_pConfigFile->GetItemValue(pszCfgItem, "ServiceLookOn",    m_nServiceLookOn,    0);

	//��Чʱ��	
	m_pConfigFile->GetItemValue(pszCfgItem, "ValidTime",    m_nValidTime,    120);

	//��Ч�㲥�ȼ�
	m_pConfigFile->GetItemValue(pszCfgItem, "RankUseful",    m_nRankUseful,    1);

	// glacier 2009-12-8 add
	// �޸Ķ����������ļ�
	m_unMaxBaseGuessMoney = 0;
	m_unMinBaseGuessMoney = 0;
	m_unLookerGuessMinMoney = 0;
	m_unLookerGuessMaxMoney = 0;
	m_nMaxLookOnNumber = 10;               // ����Թ�����ȷ��
	m_nRateLookOn = 0;
	m_nRateLookOnVip = 0;
	m_nRatePlayer = 0;
	m_nRatePlayerVip = 0;
	m_nRatePlayerPeace = 0;
	m_nRatePlayerPeaceVip = 0;
	m_nRatePlayerPercent = 0;
	m_nRatePlayerPercentVip = 0;
	m_nServicePlayer = 0;
	m_nServiceLookOn = 0;
	m_nValidTime = 0;

	m_pConfigFile->CloseFile();

	return 0;
}

void	GuessSvr::ProcessLockMoneyOK(PLAYERLOOKON* pUser, BOOL bPlayer)
{
#define  LOCK_ERROR_RETURN(x)  if( !(bPlayer && !m_bUnLockPlayerMoney) ) {	m_pServer->UnlockMoney(pUser->sPlayerID, NULL ); }  pUser->RollBack();	SendShowMessage2User(pUser->sPlayerID, x);	

	if( m_bGameOver )
	{
		LOCK_ERROR_RETURN("��Ϸ�Ѿ���������עʧ�ܣ�");
		return;
	}

	int nPlayerMoney = GetUserMoney( pUser->sPlayerID, pUser->unUin);
	printf("player %d money is:%d \n", pUser->unUin, nPlayerMoney);
	if( nPlayerMoney<0 )
	{
		LOCK_ERROR_RETURN("������Ϸ�Ҳ��㱾����ע�����ֵ��Ϸ�ҡ�");
		return;
	}

	{
		unsigned int unPlayerMoney = (unsigned int)nPlayerMoney;
		if( pUser->byFirstGuess )
		{
			if( eGCMSolid==m_eChargeMode && m_nServiceLookOn>0 )
			{
				if( unPlayerMoney <= m_nServiceLookOn )
				{
					LOCK_ERROR_RETURN("������Ϸ�Ҳ��㱾����ע�����ֵ��Ϸ�ҡ�");
					return;
				}
				unPlayerMoney -= m_nServiceLookOn;
			}
		}
		unsigned int unTotle = 0;
		for( int i=0; i<eGMOverflow; i++ )
		{
			if(  pUser->unReqGuessMoney[i] > 0  ) 
			{
				unTotle += pUser->unReqGuessMoney[i];
			}
		}
		if( unTotle<=0 )
		{
			return;
		}

		if( unPlayerMoney / 2 < unTotle )
		{
			LOCK_ERROR_RETURN( "������Ϸ�Ҳ��㱾����ע�����ֵ��Ϸ�ҡ�");
			return;
		}
	}
	//samygong �޸�
	//������Թ��� ��һ����ע �۷����
	if( eGCMSolid==m_eChargeMode && m_nServiceLookOn>0 )
	{
		if( pUser->byFirstGuess )//!pUser->IsGuessMoneyValid() && pUser->IsReqGuessMoneyValid() )
		{
			{
				// ��ȡ�����]
				printf("��ȡ����� %d", m_nServiceLookOn);
				USER_SCORE score;
				memset( &score, 0, sizeof(score) );
				score.lMoney = -(long)m_nServiceLookOn;
				m_pServer->SetGameScoreEx(pUser->sPlayerID, pUser->unUin, 
					sizeof(score), (void*)&score);
				if( m_pLogFile )
				{
					m_pLogFile->Log("\n*****�۸��Թ۾��µķ����%u,id:%d, uin:%u,\n", 
						pUser->sPlayerID, pUser->unUin, m_nServiceLookOn);
				}
			}
		}
	}

	if( pUser->byFirstGuess )
	{
		for( int i=0; i<eGMOverflow; i++ )
		{
			pUser->LastReqMoney[pUser->byCurReqMoneyPoint].unLastReqMoney[i] = pUser->unReqGuessMoney[i];
		}
		pUser->LastReqMoney[pUser->byCurReqMoneyPoint].nStep = m_nGameStep;
		pUser->byFirstGuess = FALSE;
	}
	else
	{
		pUser->byFirstGuess = FALSE;
		if( pUser->LastReqMoney[pUser->byCurReqMoneyPoint].nStep != m_nGameStep )
		{
			pUser->byCurReqMoneyPoint ++;
			if( pUser->byCurReqMoneyPoint>=LAST_STEPS_REQ_MONEY_KEEP )
			{
				pUser->byCurReqMoneyPoint = 0;
			}
			pUser->LastReqMoney[pUser->byCurReqMoneyPoint].nStep = m_nGameStep;
			for( int i=0; i<eGMOverflow; i++ )
			{
				pUser->LastReqMoney[pUser->byCurReqMoneyPoint].unLastReqMoney[i] = pUser->unReqGuessMoney[i];
			}
		}
		else
		{
			for( int i=0; i<eGMOverflow; i++ )
			{
				pUser->LastReqMoney[pUser->byCurReqMoneyPoint].unLastReqMoney[i] += pUser->unReqGuessMoney[i];
			}
		}
	}

	unsigned int nTotleCutMoney = 0;
	for( int j=0; j<eGMOverflow; j++ )
	{
		if( pUser->unReqGuessMoney[j] > 0 )
		{
			//��һ����ע  ����++;
			if( 0==pUser->unGuessMoney[j] )
			{
				m_nPersonCount[j] ++;
			}
			//���Ҫ�۵���Ϸ��֮��
			nTotleCutMoney += pUser->unReqGuessMoney[j];
			//�Ѿ���ע����Ϸ��
			pUser->unGuessMoney[j] += pUser->unReqGuessMoney[j];
			//�ж��ǲ���ǰ��15��
			if( m_nGameStep<GAME_PARTITION )
			{
				pUser->unGuessMoney15Step[j] += pUser->unReqGuessMoney[j];
			}
			//�ܵĲ²���Ϸ����
			m_unGuessMoney[j] += pUser->unReqGuessMoney[j];
			//��0
			pUser->unReqGuessMoney[j] = 0;
		}
		pUser->unReqGuessMoney[j] = 0;
	}

	if( nTotleCutMoney>0 )
	{
		USER_SCORE	UserScore;
		memset(&UserScore, 0, sizeof(UserScore) );
		UserScore.lMoney = -((long)(nTotleCutMoney));
		m_pServer->SetGameScoreEx(pUser->sPlayerID, pUser->unUin, 
			sizeof(USER_SCORE), (void*)&UserScore);
		
		char szTestMsg[256] = {0};
		_snprintf(szTestMsg, sizeof(szTestMsg), "\ncut player money:%d \n", UserScore.lMoney);
		printf(szTestMsg);
		if( m_pLogFile )
		{
			m_pLogFile->Log("\n*****�Թ�����ע id: %u, ��Ϸ��:%d \n", 
				pUser->unUin, UserScore.lMoney);
		}

		//����ĳĳ�����ע����Ϣ
		{
			unsigned int unMoney = nTotleCutMoney;
			GetDataAfterPump( TRUE, pUser->byVip, unMoney);
			char szMsg[256] = {0};
			_snprintf(szMsg, sizeof(szMsg), "���Ѿ���ע��%d��Ϸ�ң�", unMoney);
			SendShowMessage2UserModalLess(pUser->sPlayerID, szMsg);
		}

		//�������� ��ע������
		GAME_CMD_DATA data;
		data.cCmdID = SID_LOOKON_GUESS_MONEY;
		data.cChair = pUser->sSeat;
		LOOKON_GUESS_MONEY lqm;
		lqm.unUin = pUser->unUin;
		int i = 0;
		for( i=eGMBegin; i<eGMOverflow; i++ )
		{
			lqm.unGuessMoney[i] = pUser->unGuessMoney[i];
			lqm.unGuessMoney15Step[i] = pUser->unGuessMoney15Step[i];
			lqm.unTotleGuessMoney[i] = m_unGuessMoney[i];
			lqm.unTotlePersons[i] = m_nPersonCount[i];

			GetDataAfterPump( TRUE, pUser->byVip, lqm.unGuessMoney[i] );
			GetDataAfterPump( TRUE, pUser->byVip, lqm.unGuessMoney15Step[i] );
			GetDataAfterPump( TRUE, pUser->byVip, lqm.unTotleGuessMoney[i] );
		}
		data.nDataLen = 1 + lqm.Encode(data.data);
		m_pServer->SendGameData( (char *)&data, offsetof(GAME_CMD_DATA, data) + data.nDataLen );
//		m_pServer->SendGameDataToLookOnUsers(0, (LPCSTR)&data, offsetof(GAME_CMD_DATA, data)+data.nDataLen);
//		m_pServer->SendGameDataToLookOnUsers(1, (LPCSTR)&data, offsetof(GAME_CMD_DATA, data)+data.nDataLen);

		//��������100����Ϸ��,�����¼�֪ͨ
		if( m_b100WValid )
		{
			unsigned int nTotleMoney = 0;
			for( int i=0; i<eGMOverflow; i++ )
			{
				nTotleMoney += m_unGuessMoney[i];
			}
			if( nTotleMoney>1000000 )
			{
				m_b100WValid = FALSE;
				
				char szMsg[256] = {0};
				char szBuf[16] = {0};
				GetPlayerRank(m_Players[0].sPlayerID, szBuf, sizeof(szBuf));
				_snprintf(szMsg, sizeof(szMsg), "%s %s[%d]��", szBuf, m_Players[0].szNickName, m_Players[0].unUin);
				GetPlayerRank(m_Players[1].sPlayerID, szBuf, sizeof(szBuf));
				int nTableID = m_pServer->GetGameTableID();
				_snprintf(szMsg, sizeof(szMsg), "%s%s %s[%d]�����й����屾��Ϸ����%d���Ծ��У���Ҿ�����Ϸ����������100��", szMsg, szBuf, 
					m_Players[1].szNickName, m_Players[1].unUin, /*nTableID/100,*/ (nTableID%100)+1 );
				m_pServer->BroadcastSysMsg( szMsg, strlen(szMsg), 0, 0 );
			}
		}
	}
	else
	{
		printf("\bnot cut player %d money\n", pUser->unUin);
	}

	//��������
	if( !(bPlayer && !m_bUnLockPlayerMoney) )
	{
		m_pServer->UnlockMoney( pUser->sPlayerID, NULL );
	}
	
}

BOOL	GuessSvr::CutLastTenStepsMoney(LPPLAYERLOOKON pLookOn, unsigned int* punCutMoney)
{
	if( !pLookOn )
	{
		return FALSE;
	}
	//������
	unsigned int unTempMoney[eGMOverflow];
	memset( unTempMoney, 0, sizeof(unsigned int)*eGMOverflow );
	int nGameStep = m_nGameStep;
//	for( int k=0; k<eGMOverflow; k++ )
//	{
//		pLookOn->SetGiveBackMoney(k, 0);// unGiveBackGuessMoney[k]	= 0;
//	}
	BOOL bRes = FALSE;
	for( int i=0; i<LAST_STEPS_REQ_MONEY_KEEP; i++ )
	{
		if( nGameStep-pLookOn->LastReqMoney[i].nStep < LAST_STEPS_REQ_MONEY_KEEP )
		{
			for( int m=0; m<eGMOverflow; m++ )
			{
				//��ֵ
				unTempMoney[m] += pLookOn->LastReqMoney[i].unLastReqMoney[m];
//				pLookOn->AddGiveBackMoney(m, pLookOn->LastReqMoney[i].unLastReqMoney[m]);
				//�ܵ�Ǯ������ 
				m_unGuessMoney[m] -= pLookOn->LastReqMoney[i].unLastReqMoney[m];
				//�����ע��Ǯ����
				pLookOn->unGuessMoney[m] -= pLookOn->LastReqMoney[i].unLastReqMoney[m];
				
				if( pLookOn->LastReqMoney[i].nStep < GAME_PARTITION )
				{
					pLookOn->unGuessMoney15Step[m] -= pLookOn->LastReqMoney[i].unLastReqMoney[m];
				}

				pLookOn->LastReqMoney[i].unLastReqMoney[m] = 0;
			}
			bRes = TRUE;
		}
	}
	{
		unsigned int unGivebackMoney = 0;
		for( int i=eGMBegin; i<eGMOverflow; i++ )
		{
			unGivebackMoney	+= unTempMoney[i];//pLookOn->GetGiveBackMoney(i);
			printf("\n give back user %u pos %d %d useless money \n", pLookOn->unUin, i, unTempMoney[i] );//pLookOn->GetGiveBackMoney(i));
		}
		if( unGivebackMoney>0 )
		{
			USER_SCORE score;
			memset(&score, 0, sizeof(USER_SCORE) );
			score.lMoney = (long)unGivebackMoney;
			m_pServer->SetGameScoreEx(pLookOn->sPlayerID, pLookOn->unUin, sizeof(score),
				(void*)&score );
			printf("\n give back user %u %d useless money \n", pLookOn->unUin, score.lMoney);
			if( m_pLogFile )
			{
				m_pLogFile->Log("\n*****�Թ���id:%d, uin:%u ����20��������%d��Ϸ��,����\n",
					pLookOn->sPlayerID, pLookOn->unUin, score.lMoney);
			}
			char szMsg[256] = {0};
			memset(szMsg, 0, sizeof(szMsg) );
			_snprintf(szMsg, sizeof(szMsg), "���ڱ�����Ϸ����ǰ%d���о�����%u��Ϸ�ң�ϵͳ������Щ��Ϸ�Ҹ�������Щ��Ϸ�Ҳ������뾺�µķ�Χ��",
				LAST_STEPS_REQ_MONEY_KEEP, unGivebackMoney);
			SendShowMessage2UserModalLess(pLookOn->sPlayerID, szMsg);
		}
	}
	if( punCutMoney )
	{
		//memcpy( punCutMoney, pLookOn->unGiveBackGuessMoney, sizeof(pLookOn->unGiveBackGuessMoney) );
		for( int i=eGMBegin; i<eGMOverflow; i++ )
		{
			punCutMoney[i]	= unTempMoney[i];//pLookOn->GetGiveBackMoney(i);
		}
	}
	return bRes;
}

int		GuessSvr::GetTotleGuessPersonsCount()
{
	int nCount = 0;
	for( int i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
	{
		if( m_LookerOn[i].IsGuessMoneyValid() && m_LookerOn[i].IsValid() )
		{
			nCount ++;
		}
	}
	return nCount;
}

void	GuessSvr::GiveBackInvalidMoney( int nType )
{
	for( int i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
	{
		if( m_LookerOn[i].IsValid() && m_LookerOn[i].IsGuessMoneyValid() )
		{
			unsigned int unCurMoney = 0;
			for( int m=eGMBegin; m<eGMOverflow; m++ )
			{
				unsigned int unTemp = 0;
				switch( nType )
				{
				case 1:
					unTemp = m_LookerOn[i].unGuessMoney15Step[m];
					unCurMoney += unTemp;
					m_LookerOn[i].unGuessMoney15Step[m] = 0;
					break;
				case 2:
					if( m_LookerOn[i].unGuessMoney[m] < m_LookerOn[i].unGuessMoney15Step[m] )
					{
						unTemp = m_LookerOn[i].unGuessMoney[m];
					}
					else
					{
						unTemp = m_LookerOn[i].unGuessMoney[m] - m_LookerOn[i].unGuessMoney15Step[m];
					}
					unCurMoney += unTemp;//
					break; 
				default:
					unTemp = m_LookerOn[i].unGuessMoney[m];
					unCurMoney += unTemp;
				}
				m_LookerOn[i].unGuessMoney[m] -= unTemp;
			}
			if( unCurMoney>0 )
			{
				USER_SCORE score;
				memset(&score, 0, sizeof(score) );
				score.lMoney = (long)unCurMoney;
				if( m_eChargeMode==eGCMSolid )
				{
					if( m_bHasSetBaseMoney )
					{
						score.lMoney += m_nServiceLookOn;
					}
				}
				printf("\n GiveBackInvalidMoney uin %u, money :%d ", m_LookerOn[i].unUin,score.lMoney);
				m_pServer->SetGameScoreEx(m_LookerOn[i].sPlayerID, m_LookerOn[i].unUin,
					sizeof(score), (void*)&score);

				char szMsg[128] = {0};
				memset(szMsg, 0, 128*sizeof(char));
				switch( nType )
				{
				case 1:
					_snprintf(szMsg, sizeof(szMsg), "���־���Ϊ��Ч���£�ϵͳ���������־�����ע����Ϸ�ң�");
					break;
				case 2:
					_snprintf(szMsg, sizeof(szMsg), "�о־���Ϊ��Ч���£�ϵͳ�������о־�����ע����Ϸ�ң�");
					break;
				default:
					_snprintf(szMsg, sizeof(szMsg), "������ϷΪ��Ч���£�ϵͳ������������Ϸ��ע����Ϸ�ң�");
				}
				SendShowMessage2UserModalLess(m_LookerOn[i].sPlayerID, szMsg);
			
				if( m_pLogFile )
				{
					m_pLogFile->Log(szMsg);
					m_pLogFile->Log(" *****�Թ���id:%d, uin:%u ��Ϸ��%d\n",
						m_LookerOn[i].sPlayerID, m_LookerOn[i].unUin, score.lMoney);
				}
			}
		}
	}
}

BOOL	GuessSvr::GetGuessMoneyStep(eGuessMode eMode, unsigned int& unTotleMoney, int nCuteType)
{
	if( eMode<eGMBegin || eMode>=eGMOverflow )
	{
		return FALSE;
	}
	unsigned int unMoney = 0;
	for( int i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
	{
		if( m_LookerOn[i].IsValid() && m_LookerOn[i].IsGuessMoneyValid() )
		{
			unsigned int unCurMoney = 0;
			switch( nCuteType )
			{
			case 1:
				unCurMoney = m_LookerOn[i].unGuessMoney15Step[eMode];
				break;
			case 2:
				if( m_LookerOn[i].unGuessMoney[eMode] >= m_LookerOn[i].unGuessMoney15Step[eMode] )
				{
					unCurMoney = m_LookerOn[i].unGuessMoney[eMode] - m_LookerOn[i].unGuessMoney15Step[eMode];
				}
				else
				{
					unCurMoney = 0;
				}
				break; 
			default:
				unCurMoney = m_LookerOn[i].unGuessMoney[eMode];
			}
			if( m_eChargeMode==eGCMPump )
			{
/*				if( eMode==eGMPeace )
				{
					GetDataAfterPumpPeace(TRUE, m_LookerOn[i].byVip, unCurMoney);
				}
				else
*/				{
					GetDataAfterPump(TRUE, m_LookerOn[i].byVip, unCurMoney );
				}
			}
			unMoney += unCurMoney;
		}
	}
	unTotleMoney = unMoney;
	return TRUE;
}

BOOL	GuessSvr::GetGuessMoney(eGuessMode eMode, unsigned int& unTotleMoney, unsigned int& unTotlePerson, BOOL bCheck)
{
	if( eMode<eGMBegin || eMode>=eGMOverflow )
	{
		return FALSE;
	}
	if( !bCheck )
	{
		unTotleMoney  = m_unGuessMoney[eMode];
		unTotlePerson = (unsigned int)m_nPersonCount[eMode];
		return TRUE;
	}

	unsigned int unMoney = 0;
	unsigned int unMoney2 = 0;
	unsigned int unPersons = 0;
	for( int i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
	{
		if( m_LookerOn[i].IsValid() && m_LookerOn[i].IsGuessMoneyValid() )
		{
			unMoney += m_LookerOn[i].unGuessMoney[eMode];
			unsigned int unMoney3 = m_LookerOn[i].unGuessMoney[eMode];
			GetDataAfterPump(TRUE, m_LookerOn[i].byVip, unMoney3);
			unMoney2 += unMoney3;

			unPersons ++;
		}
	}

	unTotleMoney  = unMoney2;//unMoney;
	unTotlePerson = unPersons;

	if( unMoney!=m_unGuessMoney[eMode] )
	{
		char buf[256] = {0};
		_snprintf( buf, sizeof(buf), "!!!!!!!!!!!!ERROR tpye %d totlemoney is not equal: old:%d, new:%d \n", eMode, m_unGuessMoney[eMode], unTotleMoney );
		printf(buf);
		if( m_pLogFile )
		{
			m_pLogFile->Log(buf);
		}
		//����Ϊ�����
		m_unGuessMoney[eMode] = unMoney;
	}
	if( unTotlePerson!=(unsigned int)(m_nPersonCount[eMode]) )
	{
		char buf[256] = {0};
		_snprintf( buf, sizeof(buf), "!!!!!!!!!!!!ERROR type %d totle persons is not equal: old:%d, new:%d \n", eMode, m_nPersonCount[eMode], unTotlePerson );
		printf(buf);
		if( m_pLogFile )
		{
			m_pLogFile->Log(buf);
		}
		//����Ϊ���������
		m_nPersonCount[eMode] = (int)unTotlePerson;
	}
	return TRUE;
}

void	GuessSvr::BlackWinGuessMode()//��ʤ
{
//	if( 0==m_unBaseGuessMoney )
//	{
//		return;
//	}
	if( m_pLogFile )
	{
		m_pLogFile->Log("����GuessSvr::BlackWinGuessMode��ʤ m_eChargeMode=%d\n",
			m_eChargeMode);
	}

	switch( m_eChargeMode )
	{
	case eGCMSolid:
		BlackWinGuessModeSolid();
		break;
	default:
		BlackWinGuessModePump();
	}

}

int		GuessSvr::AdjustCutMoney(short nPlayerID, int& nCutMoney)
{
	if( nCutMoney>=0 )
	{
		return nCutMoney;
	}
	int nMoney = 0;
	m_pServer->GetMoney(nPlayerID, &nMoney);
	if( nMoney<=0 )
	{
		nCutMoney = 0;
		return 0;
	}

	if( nMoney + nCutMoney < 0 )
	{
		nCutMoney = -nMoney;
	}

	return nCutMoney;
}

void	GuessSvr::BlackWinGuessModeSolid()//��ʤ	
{
	int nWinnerPos = m_nValues[1];
	//��λ��Ϊ1�����Ӯ��
	//�ж��Ƿ��ж෽ѡ�� 
	unsigned int unLookerOnTotleMoney = 0;
	unLookerOnTotleMoney += CuteLookerOnGuessModeSolid(eGMBlackWin, 1, m_Players[nWinnerPos].byVip );
	unLookerOnTotleMoney += CuteLookerOnGuessModeSolid(eGMBlackWin, 2, m_Players[nWinnerPos].byVip );

	//�������
	//��λ1 ��ʤ 
	unsigned int nPercent = (unsigned int)m_nRatePlayerPercent;
	if( m_Players[nWinnerPos].byVip )
	{
		nPercent = (unsigned int)m_nRatePlayerPercentVip;
	}
	unsigned int unPlayerWinMoney = m_unBaseGuessMoney*2 /*- m_nServicePlayer*/ + 
		unLookerOnTotleMoney * nPercent / 100;
	USER_SCORE score;
	memset(&score, 0, sizeof(score) );
	score.lMoney = (long)unPlayerWinMoney;
	m_Players[nWinnerPos].lWinMoney = score.lMoney;
	m_pServer->SetGameScoreEx(m_Players[nWinnerPos].sPlayerID,
		m_Players[nWinnerPos].unUin, sizeof(score), (void*)&score);

	if( m_pLogFile )
	{
		m_pLogFile->Log(" *****�ڷ�ʤ�� ���id:%d, uin:%u ��Ϸ��%d\n",
			m_Players[nWinnerPos].sPlayerID,m_Players[nWinnerPos].unUin, score.lMoney);
	}
}

void	GuessSvr::BlackWinGuessModePump()//��ʤ
{
	int nWinnerPos = m_nValues[1];

	//��λ��Ϊ1�����Ӯ��
	//�ж��Ƿ��ж෽ѡ��
	unsigned int unLookerOnTotleMoney = 0;
	unLookerOnTotleMoney += CuteLookerOnGuessModePump(eGMBlackWin, 1, m_Players[nWinnerPos].byVip );
	unLookerOnTotleMoney += CuteLookerOnGuessModePump(eGMBlackWin, 2, m_Players[nWinnerPos].byVip );

	printf("\n black win totleMoney is %u \n", unLookerOnTotleMoney);
	//�������
	//��λ1 ��ʤ 
	unsigned int unPlayerWinMoney = 0;
	unsigned int nRate = (unsigned int)m_nRatePlayer;
	unsigned int nPercent = (unsigned int)m_nRatePlayerPercent;
	if( m_Players[nWinnerPos].byVip )
	{
		nRate = (unsigned int)m_nRatePlayerVip;
		nPercent = (unsigned int)m_nRatePlayerPercentVip;
	}
	
//	int nPersonsCount = GetTotleGuessPersonsCount();
//	unsigned int	unServicesLookOn = (unsigned int)m_nServiceLookOn * (unsigned int)nPersonsCount;

	unPlayerWinMoney = m_unBaseGuessMoney*2*(100-nRate)/100 + 
		/*unServicesLookOn*/unLookerOnTotleMoney * nPercent / 100;
	USER_SCORE score;
	memset(&score, 0, sizeof(score) );
	score.lMoney = (long)unPlayerWinMoney;
	m_Players[nWinnerPos].lWinMoney = score.lMoney;
	m_pServer->SetGameScoreEx(m_Players[nWinnerPos].sPlayerID, 
		m_Players[nWinnerPos].unUin, sizeof(score), (void*)&score);
	if( m_pLogFile )
	{
		m_pLogFile->Log(" *****�ڷ�ʤ�� ���id:%d, uin:%u ��Ϸ��%d\n",
			m_Players[nWinnerPos].sPlayerID,m_Players[nWinnerPos].unUin, score.lMoney);
	}
}

void	GuessSvr::RedWinGuessMode()	//��ʤ
{
//	if( 0==m_unBaseGuessMoney )
//	{
//		return;
//	}
	if( m_pLogFile )
	{
		m_pLogFile->Log("����GuessSvr::RedWinGuessMode��ʤ m_eChargeMode=%d\n",
			m_eChargeMode);
	}

	switch( m_eChargeMode )
	{
	case eGCMSolid:
		RedWinGuessModeSolid();
		break;
	default:
		RedWinGuessModePump();
	}
}

void	GuessSvr::RedWinGuessModeSolid()	//��ʤ
{
	int nWinnerPos = m_nValues[0];
	//��λ��Ϊ0�����Ӯ��
	//�ж��Ƿ��ж෽ѡ��
	unsigned int unLookerOnTotleMoney = 0;
	unLookerOnTotleMoney += CuteLookerOnGuessModeSolid(eGMRedWin, 1, m_Players[nWinnerPos].byVip );
	unLookerOnTotleMoney += CuteLookerOnGuessModeSolid(eGMRedWin, 2, m_Players[nWinnerPos].byVip );

	//�������
	//��λ 
	unsigned int nPercent = (unsigned int)m_nRatePlayerPercent;
	if( m_Players[nWinnerPos].byVip )
	{
		nPercent = (unsigned int)m_nRatePlayerPercentVip;
	}
	unsigned int unPlayerWinMoney = m_unBaseGuessMoney*2 /*- m_nServicePlayer*/ + 
		unLookerOnTotleMoney * nPercent / 100;
	USER_SCORE score;
	memset(&score, 0, sizeof(score) );
	score.lMoney = (long)unPlayerWinMoney;
	m_Players[nWinnerPos].lWinMoney = (int)score.lMoney;
	m_pServer->SetGameScoreEx(m_Players[nWinnerPos].sPlayerID,
		m_Players[nWinnerPos].unUin, sizeof(score), (void*)&score);
	if( m_pLogFile )
	{
		m_pLogFile->Log("***** �췽ʤ�� ���id:%d, uin:%u ��Ϸ��%d\n",
			m_Players[nWinnerPos].sPlayerID,m_Players[nWinnerPos].unUin, score.lMoney);
	}
}

unsigned int	GuessSvr::CuteLookerOnGuessModeSolid(int eMode, int nType, BOOL bPlayerVip)
{
	int nGuessCount = 0;
	//�Թ��ߵ��ܾ�����
	unsigned int unLookerOnTotleMoney = 0;
	//��Ӯ������ܺ�
	unsigned int unTypeTotleWin	= 0;
	for( int kk=eGMBegin; kk<eGMOverflow; kk++ )
	{
		unsigned int unTotle	= 0;
		GetGuessMoneyStep( (eGuessMode)kk, unTotle, nType );  
		if( unTotle>0 )
		{
			nGuessCount++;
			unLookerOnTotleMoney += unTotle;
			if( kk==eMode )
			{
				unTypeTotleWin = unTotle;
			}
		}
	}
	
	if( m_pLogFile )
	{
		m_pLogFile->Log("\n *****Win Mode %d, guess count %d, Totle money %u, mode win %u \n", eMode
			, nGuessCount, unLookerOnTotleMoney, unTypeTotleWin);
	}
	printf("\n Win Mode %d, guess count %d, Totle money %u, mode win %u \n", eMode
			, nGuessCount, unLookerOnTotleMoney, unTypeTotleWin);

	//�����Թ���
	if( nGuessCount<=1 || unLookerOnTotleMoney==0 || unTypeTotleWin==0 )
	{
		unLookerOnTotleMoney = 0;
		unTypeTotleWin		 = 0;
		GiveBackInvalidMoney(nType);
	}
	else
	{
		float fRate = ((float)unLookerOnTotleMoney)/unTypeTotleWin;
		for( int i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
		{
			if( m_LookerOn[i].IsValid() && m_LookerOn[i].IsGuessMoneyValid() )
			{
				//�����Ǽ�Ǯ�Ĳ���  ����lockmoney��
				unsigned int unMoney = 0;
				switch( nType )
				{
				case 1:
					unMoney = m_LookerOn[i].unGuessMoney15Step[eMode];
					break;
				case 2:
					if( m_LookerOn[i].unGuessMoney[eMode] < m_LookerOn[i].unGuessMoney15Step[eMode] )
					{
						unMoney = 0;
					}
					else
					{
						unMoney = m_LookerOn[i].unGuessMoney[eMode] - m_LookerOn[i].unGuessMoney15Step[eMode];
					}
					break; 
				default:
					unMoney = m_LookerOn[i].unGuessMoney[eMode];
				}
				if( unMoney>0 )
				{
					unMoney = (unsigned int)( fRate * unMoney );
					/*
					long lMoneyGet = 0;
					int nRateOfGet = bPlayerVip?m_nRateLookOnVip:m_nRateLookOn;
					if (nRateOfGet < 100)
					{
						lMoneyGet = (unMoney * ((float)100) / (100 - nRateOfGet)) * nRateOfGet / 100;
					}
					*/
					if( eMode!=eGMPeace )
					{
						int nRate = bPlayerVip ? m_nRatePlayerPercentVip : m_nRatePlayerPercent;
						unMoney = unMoney * (100-nRate) / 100;
					}
					USER_SCORE score;
					memset( &score, 0, sizeof(USER_SCORE) );
					score.lMoney = (long)( unMoney );
					m_LookerOn[i].lWinMoney += score.lMoney;
					m_pServer->SetGameScoreEx(m_LookerOn[i].sPlayerID, m_LookerOn[i].unUin,
							sizeof(score), (void*)&score);
					if( m_pLogFile )
					{
						m_pLogFile->Log("*****�Թ����id:%d, uin:%u Ӯ��Ϸ��%d\n",
							m_LookerOn[i].sPlayerID, m_LookerOn[i].unUin, score.lMoney);
					}
				}
			}
		}	
	}
	return unLookerOnTotleMoney;
}

unsigned int	GuessSvr::CuteLookerOnGuessModePump(int eMode, int nType, BOOL bPlayerVip)
{
	int nGuessCount = 0;
	//�Թ��ߵ��ܾ�����
	unsigned int unLookerOnTotleMoney = 0;
	//��Ӯ������ܺ�
	unsigned int unTypeTotleWin	= 0;
	for( int kk=eGMBegin; kk<eGMOverflow; kk++ )
	{
		unsigned int unTotle	= 0;
		GetGuessMoneyStep( (eGuessMode)kk, unTotle, nType );  
		printf("\n get guess money step mode %d, money:%d, nType:%d\n", kk, unTotle, nType);
		if( unTotle>0 )
		{
			nGuessCount++;
			unLookerOnTotleMoney += unTotle;
			if( kk==eMode )
			{
				unTypeTotleWin = unTotle;
			}
		}
	}
	
	//�����Թ���
	if( nGuessCount<=1 || unLookerOnTotleMoney==0 || unTypeTotleWin==0 )
	{
		printf("\n nGuessCount<=1 || unLookerOnTotleMoney==0 || unTypeTotleWin==0\n");
		unLookerOnTotleMoney = 0;
		unTypeTotleWin		 = 0;
		GiveBackInvalidMoney(nType);
	}
	else
	{
		float fRate = ((float)unLookerOnTotleMoney)/unTypeTotleWin;
		for( int i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
		{
			if( m_LookerOn[i].IsValid() && m_LookerOn[i].IsGuessMoneyValid() )
			{
				//�����Ǽ�Ǯ�Ĳ���  ����lockmoney��
				unsigned int unMoney = 0;
				switch( nType )
				{
				case 1:
					unMoney = m_LookerOn[i].unGuessMoney15Step[eMode];
					break;
				case 2:
					if( m_LookerOn[i].unGuessMoney[eMode] < m_LookerOn[i].unGuessMoney15Step[eMode] )
					{
						unMoney = 0;
					}
					else
					{
						unMoney = m_LookerOn[i].unGuessMoney[eMode] - m_LookerOn[i].unGuessMoney15Step[eMode];
					}
					break; 
				default:
					unMoney = m_LookerOn[i].unGuessMoney[eMode];
				}
				if( unMoney>0 )
				{
					unMoney = (unsigned int)(fRate * unMoney);
					printf("\n win money is %u, ", unMoney );
/*					if( eMode==eGMPeace )
					{
						GetDataAfterPumpPeace(TRUE, m_LookerOn[i].byVip, unMoney);
					}
					else 
					{
*/					
					GetDataAfterPump(TRUE, m_LookerOn[i].byVip, unMoney );
					if( eMode!=eGMPeace )
					{	
						int nRate = bPlayerVip ? m_nRatePlayerPercentVip : m_nRatePlayerPercent;
						unMoney = unMoney * (100-nRate) / 100;
					}
					printf("  after pump is %u\n", unMoney );
					USER_SCORE score;
					memset( &score, 0, sizeof(USER_SCORE) );
					score.lMoney = (long)( unMoney ); 
					m_LookerOn[i].lWinMoney += score.lMoney;
					m_pServer->SetGameScoreEx(m_LookerOn[i].sPlayerID, m_LookerOn[i].unUin,
							sizeof(score), (void*)&score);
					if( m_pLogFile )
					{
						m_pLogFile->Log("*****�Թ����id:%d, uin:%u Ӯ��Ϸ��%d\n",
							m_LookerOn[i].sPlayerID, m_LookerOn[i].unUin, score.lMoney);
					}
				}
			}
		}	
	}
	printf(" \n totle money is %u \n", unLookerOnTotleMoney );
	return unLookerOnTotleMoney;
}
	
void	GuessSvr::RedWinGuessModePump()	//��ʤ
{
	int nWinnerPos = m_nValues[0];

	unsigned int unLookerOnTotleMoney = 0;
	unLookerOnTotleMoney += CuteLookerOnGuessModePump(eGMRedWin, 1, m_Players[nWinnerPos].byVip );
	unLookerOnTotleMoney += CuteLookerOnGuessModePump(eGMRedWin, 2, m_Players[nWinnerPos].byVip );
	//�������
	//��λ0 ��ʤ
	unsigned int unPlayerWinMoney = 0;
	int	nRate = m_nRatePlayer;
	int	nPercent = m_nRatePlayerPercent;
	if( m_Players[nWinnerPos].byVip )
	{
		nRate = m_nRatePlayerVip;
		nPercent = m_nRatePlayerPercentVip;
	}

	unPlayerWinMoney = m_unBaseGuessMoney*2*(100-nRate)/100 + 
		unLookerOnTotleMoney/*unServicesLookOn*/ * nPercent / 100;

	USER_SCORE score;
	memset(&score, 0, sizeof(score) );
	score.lMoney = (long)unPlayerWinMoney;
	m_Players[nWinnerPos].lWinMoney = score.lMoney;
	m_pServer->SetGameScoreEx(m_Players[nWinnerPos].sPlayerID, 
		m_Players[nWinnerPos].unUin, sizeof(score), (void*)&score);
	if( m_pLogFile )
	{
		m_pLogFile->Log(" *****�췽ʤ�� ���id:%d, uin:%u ��Ϸ��%d\n",
			m_Players[nWinnerPos].sPlayerID,m_Players[nWinnerPos].unUin, score.lMoney);
	}

}
void	GuessSvr::PeaceGuessMode()	//�;�
{
//	if( 0==m_unBaseGuessMoney )
//	{
//		return;
//	}
	if( m_pLogFile )
	{
		m_pLogFile->Log("����GuessSvr::PeaceGuessMode�;� m_eChargeMode=%d\n",
			m_eChargeMode);
	}

	switch( m_eChargeMode )
	{
	case eGCMSolid:
		PeaceGuessModeSolid();
		break;
	default:
		PeaceGuessModePump();
	}
}

void	GuessSvr::PeaceGuessModeSolid()
{
	//��� �׷�-�����
	int i = 0;
	for( i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
	{
		//�޸� ������Ѿ���gamebegin��ʱ��۵���
		USER_SCORE score;
		memset(&score, 0, sizeof(score) );
		score.lMoney = (m_unBaseGuessMoney);// - m_nServicePlayer);
		m_Players[i].lWinMoney = score.lMoney;
		m_pServer->SetGameScoreEx(m_Players[i].sPlayerID, m_Players[i].unUin, 
			sizeof(score), (void*)&score);
		if( m_pLogFile )
		{
			m_pLogFile->Log(" *****���� ���id:%d, uin:%u ��Ϸ��%d\n",
				m_Players[i].sPlayerID,m_Players[i].unUin, score.lMoney);
		}

	}

	unsigned int unLookerOnTotleMoney = 0;
	unLookerOnTotleMoney += CuteLookerOnGuessModeSolid(eGMPeace, 1, FALSE );
	unLookerOnTotleMoney += CuteLookerOnGuessModeSolid(eGMPeace, 2, FALSE );

}

void	GuessSvr::PeaceGuessModePump()
{
	//��� �׷�*(1-�������)
	int i = 0;
	for( i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
	{
		int	nRate = m_nRatePlayerPeace;
		if( m_Players[i].byVip )
		{
			nRate = m_nRatePlayerPeaceVip;
		}
		USER_SCORE score;
		memset(&score, 0, sizeof(score) );
		score.lMoney = (long)( m_unBaseGuessMoney*(100-nRate)/100 );
		m_Players[i].lWinMoney = score.lMoney;
		m_pServer->SetGameScoreEx(m_Players[i].sPlayerID, m_Players[i].unUin, 
			sizeof(score), (void*)&score);
		if( m_pLogFile )
		{
			m_pLogFile->Log(" *****�� ���id:%d, uin:%u ��Ϸ��%d\n",
				m_Players[i].sPlayerID,m_Players[i].unUin, score.lMoney);
		}

	}
	
	unsigned int unLookerOnTotleMoney = 0;
	unLookerOnTotleMoney += CuteLookerOnGuessModePump(eGMPeace, 1, FALSE );
	unLookerOnTotleMoney += CuteLookerOnGuessModePump(eGMPeace, 2, FALSE );

}

void GuessSvr::InvalidGuessMode(BOOL bSetPlayerMoney)
{
//	if( 0==m_unBaseGuessMoney )
//	{
//		return;
//	}
	if( m_pLogFile )
	{
		m_pLogFile->Log("����GuessSvr::InvalidGuessMode��Ч�Ծ�\n");
	}

	for( int i=0; i<MAX_GAME_LOOKON_COUNT; i++ )
	{
		if( m_LookerOn[i].IsValid() && m_LookerOn[i].IsGuessMoneyValid() )
		{
			USER_SCORE score;
			memset( &score, 0, sizeof(score) );
			for( int m=0; m<eGMOverflow; m++ )
			{
				score.lMoney += m_LookerOn[i].unGuessMoney[m];
			}
			if( score.lMoney>0 )
			{
				if( m_eChargeMode==eGCMSolid )
				{
					score.lMoney += m_nServiceLookOn;
				}
				m_pServer->SetGameScoreEx( m_LookerOn[i].sPlayerID, m_LookerOn[i].unUin,
					sizeof(score), (void*)&score);
				if( m_pLogFile )
				{
					m_pLogFile->Log(" *****��Ч�Ծ�/���� �Թ���id:%d, uin:%u ���� ��Ϸ��%d\n",
						m_LookerOn[i].sPlayerID, m_LookerOn[i].unUin, score.lMoney);
				}


				if( bSetPlayerMoney )
				{
					SendShowMessage2UserModalLess(m_LookerOn[i].sPlayerID, 
						"������ϷΪ��Ч�Ծ֣�ϵͳ��������������ע����Ϸ�ҡ�");
				}
				else
				{
					SendShowMessage2UserModalLess(m_LookerOn[i].sPlayerID, 
						"������ϷΪ��Ч���£�ϵͳ��������������ע����Ϸ�ҡ�");
				}
			}
		}
	}

	if( m_pLogFile != NULL)
	{
//		m_pLogFile->Log("GuessSvr::InvalidGuessMode bSetPlayerMoney=%d,
//			m_bHasSetBaseMoney=%d\n",bSetPlayerMoney,m_bHasSetBaseMoney);
	}

	if( bSetPlayerMoney && m_bHasSetBaseMoney )
	{
		SendShowMessage2UserModalLess( m_Players[0].sPlayerID, "������ϷΪ��Ч�Ծ֣�ϵͳ��������������ע�ĵ׷֡�");
		SendShowMessage2UserModalLess( m_Players[1].sPlayerID, "������ϷΪ��Ч�Ծ֣�ϵͳ��������������ע�ĵ׷֡�");

		if( m_pLogFile != NULL)
		{
			m_pLogFile->Log("GuessSvr::InvalidGuessMode m_unBaseGuessMoney=%d\n",
				m_unBaseGuessMoney);
		}
		if( 0<m_unBaseGuessMoney )
		{
			for( int i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
			{
				int nAddMoney = 0;
				if( m_eChargeMode==eGCMSolid )
				{
					nAddMoney = m_nServicePlayer;
				}
				USER_SCORE score;
				memset( &score, 0, sizeof(score) );
				score.lMoney = (int)m_unBaseGuessMoney + nAddMoney;
				m_pServer->SetGameScoreEx( m_Players[i].sPlayerID, m_Players[i].unUin,
						sizeof(score), (void*)&score);
				if( m_pLogFile )
				{
					m_pLogFile->Log(" *****��Ч�Ծ� ���:%d, uin:%u ���� ��Ϸ��%d\n",
						m_Players[i].sPlayerID, m_Players[i].unUin, score.lMoney);
				}

			}
		}
	}
}


int		GuessSvr::GetPlayerScore( short nPlayerID )
{
	USER_SCORE score;
	memset(&score, 0, sizeof(score) );
	m_pServer->GetPlayerScore( nPlayerID, (int*)&score );
	return score.lUserScore;
}

int		GuessSvr::GetPlayerRank( short nPlayerID, char* szRankName, int nSize)
{
	int nScore = GetPlayerScore(nPlayerID);
	if( nScore>=2600 )
	{
		_snprintf(szRankName, nSize, "�ؼ���ʦ");
		return 0;
	}
	else if( nScore>=2400 )
	{
		_snprintf(szRankName, nSize, "һ����ʦ");
		return 1;
	}
	else if( nScore>=2200 )
	{
		_snprintf(szRankName, nSize, "������ʦ");
		return 2;
	}
	else if( nScore>=2000 )
	{
		_snprintf(szRankName, nSize, "������ʦ");
		return 3;
	}
	else if( nScore>=1800 )
	{
		_snprintf(szRankName, nSize, "һ������");
		return 4;
	}
	else if( nScore>=1700 )
	{
		_snprintf(szRankName, nSize, "��������");
		return 5;
	}
	else if( nScore>=1600 )
	{
		_snprintf(szRankName, nSize, "��������");
		return 6;
	}
	else if( nScore>=1500 )
	{
		_snprintf(szRankName, nSize, "�ļ�����");
		return 7;
	}
	else if( nScore>=1400 )
	{
		_snprintf(szRankName, nSize, "�弶����");
		return 8;
	}
	else if( nScore>=1300 )
	{
		_snprintf(szRankName, nSize, "��������");
		return 9;
	}
	else if( nScore>=1200 )
	{
		_snprintf(szRankName, nSize, "�߼�����");
		return 10;
	}
	else if( nScore>=1100 )
	{
		_snprintf(szRankName, nSize, "�˼�����");
		return 11;
	}
	else if( nScore>=0 )
	{
		_snprintf(szRankName, nSize, "�ż�����");
		return 12;
	}
	//		 else
	{
		_snprintf(szRankName, nSize, "���");
		return 13;
	}
}

void GuessSvr::SendQQTipsMsg(short sPlayerID, unsigned int unUin, char* pszMsg, long lLen)
{
	m_pServer->SendGameDataTo(sPlayerID, pszMsg, lLen);
	//Ŀǰ��֧����qq����tips 
	//ֻ�� �� �����һ������
}
BOOL	GuessSvr::IsLookerOnValid(int nPos)
{
	if( nPos<0 || nPos>=MAX_GAME_LOOKON_COUNT )
	{
		return FALSE;
	}
	return m_LookerOn[nPos].IsValid();
}
void GuessSvr::CutPlayerBaseMoney()
{
	if( m_bGameOver )
	{
		return;
	}
	
	//�ȿ۷����
	if( eGCMSolid==m_eChargeMode && m_nServicePlayer>0 )
	{
		for( int i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
		{
			USER_SCORE score;
			memset( &score, 0, sizeof(USER_SCORE) );
			int nCutMoney = m_nServicePlayer;
			//�۷����
			score.lMoney = -(long)AdjustCutMoney(m_Players[i].sPlayerID, nCutMoney);
			if( score.lMoney!=0 )
			{
				m_pServer->SetGameScoreEx(m_Players[i].sPlayerID, m_Players[i].unUin,
						sizeof(score), (void*)&score);
			}
		}
		if( m_pLogFile )
		{
			m_pLogFile->Log(" *****�۷���� ��Ϸ��%d\n",	m_nServicePlayer);
		}	
	}

	m_bHasSetBaseMoney = TRUE;

	if( m_unBaseGuessMoney==0 )
	{
		return;
	}

	for( int i=0; i<MAX_GAME_PLAYER_COUNT; i++ )
	{
		USER_SCORE score;
		memset(&score, 0, sizeof(score));
		score.lMoney = -((long)m_unBaseGuessMoney);
		m_pServer->SetGameScoreEx(m_Players[i].sPlayerID, m_Players[i].unUin,
			sizeof(score), (void*)&score);
		if( m_pLogFile )
		{
			m_pLogFile->Log("*****�۵׷� uin %u base money %u\n", m_Players[i].unUin, m_unBaseGuessMoney);
		}
		printf("Cut player %u base money %u\n", m_Players[i].unUin, m_unBaseGuessMoney);
	}
}

long	GuessSvr::GetPlayerWinMoney(char cSeat)
{
	if( cSeat<0 || cSeat>=MAX_GAME_PLAYER_COUNT )
	{
		return 0;
	}
	return m_Players[cSeat].lWinMoney - (int)m_unBaseGuessMoney; //�¼ӵ� 
}
long	GuessSvr::GetLookerOnWinMoney(int nPos)
{
	if( nPos<0 || nPos>=MAX_GAME_LOOKON_COUNT )
	{
		return 0;
	}
	return m_LookerOn[nPos].lWinMoney;
}
void	GuessSvr::SendDataToPlayer(char cSeat, char* pszData, long lLen)
{
	if( cSeat<0 || cSeat>=MAX_GAME_PLAYER_COUNT || pszData==NULL || lLen<=0 )
	{
		return;
	}
	m_pServer->SendGameDataTo(m_Players[cSeat].sPlayerID, pszData, lLen);
}
void	GuessSvr::SendDataToLookerOn(int nPos, char* pszData, long lLen)
{
	if( nPos<0 || nPos>=MAX_GAME_LOOKON_COUNT || pszData==NULL || lLen<=0 )
	{
		return;
	}
	if( m_LookerOn[nPos].IsValid() )
	{
		if( m_LookerOn[nPos].byExit )
		{
			SendQQTipsMsg(m_LookerOn[nPos].sPlayerID, m_LookerOn[nPos].unUin,
				pszData, lLen );
		}
		else
		{
			m_pServer->SendGameDataTo(m_LookerOn[nPos].sPlayerID, pszData, lLen);
			printf("send to looker on nPos %d, sPlayerID %d ok\n", nPos, m_LookerOn[nPos].sPlayerID);
		}
	}
}

int    GuessSvr::GetLookerOnIsPlayer( int nPos )
{
	if ( nPos<0 || nPos>=MAX_GAME_LOOKON_COUNT )
	{
		return -1;
	}

	for ( int i = 0; i < MAX_GAME_PLAYER_COUNT; ++i )
	{
		if ( m_LookerOn[nPos].unUin == m_Players[i].unUin )
		{
			return i;
		}
	}

	return -1;
}

MY_NAMESPACE_END



