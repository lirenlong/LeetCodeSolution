/************************************************************
  FileName:     tlib_log2.h
  Author:       jackyai
  Version:      1.0
  Create Date:  2005��3��25��
  Description:
    ��װtlib_log.c,�����˰���־��¼������м�¼�Ĵ���
	Ŀǰ���֧��15���������־ˮƽ
***********************************************************/
#ifndef _TLIB_LOG2_H_
#define _TLIB_LOG2_H_

#include <time.h>
#include <stdarg.h>

#include "LogEngine.hpp"

#ifndef g_iLogLevel
extern int	g_iLogLevel;
#endif


#	define DEBUG_LOG( level, fmt, arg1, arg2, arg3)	\
	do { \
		if ( g_iLogLevel & (level) ) \
			TLib_Log2_LogMsg( (level), (fmt), (arg1), (arg2), (arg3)); \
	} while ( 0 )


#	define P2PAUX_HANDLE_LOG( level, fmt, arg1, arg2, arg3)	\
	do { \
	if ( g_iLogLevel & (level) )\
			TLib_Log2_WriteLog( (level), "../log/p2paushandle", 0x100000, 5, (fmt), (arg1), (arg2), (arg3)); \
	} while ( 0 )

#define TRACE_FUNCTION_BEGIN \
	do { \
		if ( g_iLogLevel & LOG_LEVEL_CALL ) \
			TLib_Log2_LogMsg(LOG_LEVEL_CALL, "In %s, ---------Begin To Handle ---------\n", __FUNCTION__);\
	} while ( 0 )
		
#define TRACE_FUNCTION_END \
	do { \
		if ( g_iLogLevel & LOG_LEVEL_CALL ) \
			TLib_Log2_LogMsg(LOG_LEVEL_CALL, "In %s, ---------Handle OK---------\n", __FUNCTION__);\
	} while ( 0 )

	
char *TLib_Tools_GetDateTimeStr2(time_t *mytime);
char *TLib_Tools_GetCurDateTimeStr2(void);

//int TLib_Log2_VWriteLog(int iInfoLevel, char *sLogBaseName, long lMaxLogSize, int iMaxLogNum, char *sErrMsg, const char *sFormat, va_list ap);
//int TLib_Log2_WriteLog(int iInfoLevel, char *psLogBaseName, long lMaxLogSize, int iMaxLogNum, char *sErrMsg, const char *Format, ...);

int TLib_Log2_VWriteLog(int iInfoLevel, char *sLogBaseName, long lMaxLogSize, int iMaxLogNum, const char *sFormat, va_list ap);
int TLib_Log2_WriteLog(int iInfoLevel, char *psLogBaseName, long lMaxLogSize, int iMaxLogNum, const char *Format, ...);


void TLib_Log2_LogMsg(int iInfoLevel, const char *sFormat, ...);
void TLib_Log2_LogMsgDef(int iInfoLevel, int iShow, const char *sFormat, ...);
void TLib_Log2_LogInit(char *sPLogBaseName, long lPMaxLogSize, int iPMaxLogNum, int iShow, int iLogLevel);

void TLib_Log2_SetLogLevel(int iLogLevel);

void TLib_Log2_PrintBin(int iInfoLevel, const char *szPromt, const char *data, int len);
void TLib_Log2_WriteBin(int iInfoLevel, char *sLogBaseName, long lMaxLogSize, int iMaxLogNum, const char *szPromt, const char *data, int len);

#endif
