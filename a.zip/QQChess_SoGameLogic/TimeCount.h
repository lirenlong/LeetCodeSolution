#if !defined _TIME_COUNT_HEADER
#define _TIME_COUNT_HEADER

typedef enum 
{
	tPause,
	tCounting
}TimeCountState;

class CTimeCount
{
public:
	CTimeCount():m_tTimeMark(0),m_nTimePreCount(0),m_nState(tPause),m_bEnable(true)
	{}

	void ReStart();	// ���¿�ʼ��ʱ
	void Pause();	// ��ͣ��ʱ
	void Resume();	// �ָ���ʱ
	void Clean();	// ��ʱ���㣬��һ�����Ե��� resume
	long GetTickCount();
	int GetHour();
	int GetMinute();
	int GetSecond();

	BOOL SetEnable(BOOL bEnable);
	BOOL IsEnable();
	void SetTickCount(long nTickCount);
	int GetState();

protected:
	time_t m_tTimeMark;
	long m_nTimePreCount;
	int	m_nState;

	int  m_nDisableState;
	BOOL m_bEnable;
};

#endif