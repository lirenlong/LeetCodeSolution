#include "SmallClass.h"

MY_NAMESPACE_BEGIN

//#####################################################################################
CPlayerScore::CPlayerScore()
{
	memset(&Score, 0, sizeof(USER_SCORE));
	InitData();
}

void CPlayerScore::InitData()
{
	bIsScoreSet	 = FALSE;
	bNotSubScore = FALSE;
	overType     = overNone;
	nUserID      = INVALID_USER_ID;
	memset(&Score, 0, sizeof(Score));
}

BOOL CPlayerScore::IsValidUser()
{
	return TRUE;
}

BOOL CPlayerScore::IsNotSet()
{ 
	// �жϳɼ��Ƿ��Ѿ�������
	return !bIsScoreSet;
}

void CPlayerScore::SetScoreIsSet(BOOL bSet )
{ 
	// ���óɼ��Ƿ��Ѿ������ã����ڵ�����ϵͳ������ĳ����Ϸ����ʱ��ǿ�����óɼ��Ѿ�����Ϊ��
	bIsScoreSet = bSet;
}

void CPlayerScore::SetNotSubScore(BOOL bNotSub)
{ 
	// һ�ֲ���̫�١�ϵͳ����ͶԼ�������������£����۷�
	bNotSubScore = bNotSub;
	if(bNotSub)
		memset(&Score,0,sizeof(USER_SCORE));
}

void CPlayerScore::SetEscape(long lScore, long lMoney)
{ 
	// ��������һ��
	Score.lUserScore = lScore;
	Score.lMoney = lMoney;
	Score.dwLostCount = 0;
	Score.dwEscapeCount = 1;
	bIsScoreSet = TRUE;
}

void CPlayerScore::SetFail(long lScore, long lMoney)
{ 
	// �������˱���
	if(!bNotSubScore)
	{
		Score.lUserScore = lScore;
		Score.dwLostCount = 1;
		Score.lMoney = lMoney;
	}
	bIsScoreSet = TRUE;
}

void CPlayerScore::SetWin(long lScore, long lMoney)
{ 
	// ����Ӯ�˴˾�
	Score.lUserScore = lScore;
	Score.lMoney = lMoney;
	Score.dwWinCount = 1;
	bIsScoreSet = TRUE;
	overType = overWin;
}

void CPlayerScore::SetPeace(long lScore, long lMoney)
{ 
	// ���ú��˱���
	Score.lUserScore = lScore;
	Score.lMoney = lMoney;

	Score.dwDogfall = 1;
	bIsScoreSet = TRUE;
	overType = overNone;
}
//#####################################################################################

CPlayerInfo::CPlayerInfo()
{
	m_pstLogFile = NULL;
	m_pMainServer = NULL;
	InitData();
}

void CPlayerInfo::SetLogPtr(ITable* pMainServer, CLogFile* pLogFile)
{
	m_pstLogFile = pLogFile;
	m_pMainServer = pMainServer;
}

void CPlayerInfo::InitData()
{
	nUserID			= INVALID_USER_ID;
	m_nRegretTimes	= 0;
	m_nUIN			= 0;
	stage			= stageNone;
	unChessMoveAni		= 0;
	m_bSupportSetTime = FALSE;
}

int CPlayerInfo::GetRegretTimes()
{
	LOG("���%u��������Ĵ�����%d\n", m_nUIN, m_nRegretTimes);
	return m_nRegretTimes;
}

void CPlayerInfo::AddRegretTimes()
{
	m_nRegretTimes++;
	LOG("���%u����һ�������������,��Ϊ:%d��\n", m_nUIN, m_nRegretTimes);
}

void CPlayerInfo::CleanRegretTimes()
{
	LOG("���%u�����������������\n", m_nUIN);
	m_nRegretTimes = 0;
}

BOOL CPlayerInfo::IsValidUser()
{
	return (nUserID!=INVALID_USER_ID);
}

BOOL CPlayerInfo::SetGameBegin()
{
	CleanRegretTimes();
	
	if(!IsValidUser())
	{
		LOG("ERROR CPlayerInfo::SetGameBegin : user is invalid\n");
		return FALSE;
	}

	if(stage != stageReady)
	{
		LOG("ERROR CPlayerInfo::SetGameBegin : stage = %d, not stageReady\n",stage);
		return FALSE;
	}

	bIsOffline		=	FALSE;
	stage			=	stagePlaying;
	lScore			=	0;
	bAgreePeace		=	FALSE;
	nTimeOutCount	=	0;
	return TRUE;
}

void CPlayerInfo::SetGameEnd()
{
	bIsOffline		= FALSE;
	stage			= stagePlaceChess;
	lScore			= 0;
	bAgreePeace		= FALSE;
	nTimeOutCount	= 0;
}

void CPlayerInfo::FillTableUserInfo( TABLE_USER_INFO &kTableUserInfo )
{
    kTableUserInfo.m_iUin = m_nUIN;
    kTableUserInfo.m_nPlayerID = nUserID;
    kTableUserInfo.m_nChair = nChair;
    kTableUserInfo.m_nState = nState;
    kTableUserInfo.m_nFaceID = nFaceID;
    kTableUserInfo.m_uiRightLevel = dwRightLevel;
    strncpy(kTableUserInfo.m_szUserName, szUserName, MAX_NAME_LEN);
}
//#####################################################################################

int CStepList::GetSize()
{
	return m_size;
}

MOVE_RESULT_EX CStepList::GetData(int nIndex)
{
	return m_data[nIndex];
}

void CStepList::RemoveAll()
{
	m_size = 0;
	memset(m_data,0x00,MAX_GAME_STEPS*sizeof(MOVE_RESULT_EX));
}

void CStepList::Add(MOVE_RESULT_EX* step)
{
	if(m_size>=MAX_GAME_STEPS)
		return;
	memcpy(&m_data[m_size],step,sizeof(MOVE_RESULT_EX));
	m_size++;
}

void CStepList::Regret()
{
	if(m_size > 0)
		m_size--;
}

//#####################################################################################

CPlayerList::CPlayerList()
{
	m_pstLogFile = NULL;
	m_pMainServer = NULL;
}

void CPlayerList::SetLogPtr(ITable* pMainServer, CLogFile* pLogFile)
{
	m_pstLogFile = pLogFile;
	m_pMainServer = pMainServer;

	for(int i = 0; i < MAX_TABLE_PLAYER; i++)
	{
		m_player[i].SetLogPtr(pMainServer, pLogFile);
	}
	
}

void CPlayerList::InitData()
{
	for(int i = 0; i < MAX_TABLE_PLAYER; i++)
	{
		m_player[i].InitData();
	}
	
	GameEnd();
}

BOOL CPlayerList::GameBegin()
{
	m_nPlayerCount = 0;

	for(int chair = 0; chair < MAX_TABLE_PLAYER; chair++)
	{
		if(m_player[chair].IsValidUser())
		{
			if(!m_player[chair].SetGameBegin())
				return FALSE;
			m_nPlayerCount++;
		}
	}

	if(m_nPlayerCount < 2)
		return FALSE;

	return TRUE;
}

void CPlayerList::GameEnd()	// ��Ϸ����ʱ�������ҵ�״̬
{
	m_nPlayerCount = 0;
	m_nAnswerPeaceCount = 0;
	for(int i = 0; i < MAX_TABLE_PLAYER;i++)
	{
		m_player[i].SetGameEnd();
	}
}

BOOL CPlayerList::AddPlayer(TABLE_USER_INFO *pUser)
{
	if(!IsValidChair(pUser->m_nChair))
	{
		LOG("Error : CPlayerList::AddPlayer() : invalid UserID = %d or invalid chair = %d\n",pUser->m_nPlayerID,pUser->m_nChair);
		return FALSE;
	}
	int nChair = pUser->m_nChair;

	for(int i = 0; i < MAX_TABLE_PLAYER; i++)
	{
		LOG("now in the playerlist,userid:%d\n",m_player[i].nUserID);
		if(m_player[i].nUserID == pUser->m_nPlayerID)
		{
			LOG("Error : CPlayerList::AddPlayer() : same player[%d] found\n",(WORD)pUser->m_nPlayerID);
			return FALSE;
		}
	}

	m_player[nChair].InitData();
	m_player[nChair].nUserID = pUser->m_nPlayerID;
	m_player[nChair].nFaceID = pUser->m_nFaceID;
	m_player[nChair].nState  = pUser->m_nState;
	m_player[nChair].m_nUIN  = pUser->m_iUin;
	//test to check faceid
	LOG("AddPlayer, UIN %u\n", pUser->m_iUin);

	strncpy(m_player[nChair].szUserName,pUser->m_szUserName,MAX_NAME_LEN);
	m_player[nChair].nChair = nChair;
	m_player[nChair].dwRightLevel = pUser->m_uiRightLevel;
	m_player[nChair].stage = stagePlaceChess;	// ����sSit״̬����������Ǵ��˽�������о֣���Ӧ��JQServer�����⴦��
	m_player[nChair].bIsOffline = FALSE;
	return TRUE;
}

BOOL CPlayerList::DeletePlayer(short nPlayerID)
{
	int nIndex = FindPlayer(nPlayerID);
	if(nIndex < 0)
	{
		LOG(">> CPlayerList::Deletelayer() : player[%d] not found\n",(WORD)nPlayerID);
		return TRUE;
	}
	m_player[nIndex].InitData();
	return TRUE;
}

BOOL CPlayerList::DeletePlayer(int nChair)
{
	if(!IsValidChair(nChair))
	{
		LOG(">> CPlayerList::Deletelayer() : chair = %d\n",nChair);
		return FALSE;
	}
	m_player[nChair].InitData();
	return TRUE;
}

int CPlayerList::FindPlayer(short nPlayerID)
{
	for(int i = 0; i < MAX_TABLE_PLAYER; i++)		
	{
		if(m_player[i].nUserID == nPlayerID)
			return i;
	}
	return -1;
}

BOOL CPlayerList::IsValidUser(int nChair)
{
	return m_player[nChair].IsValidUser();
}

char* CPlayerList::GetUserName(int nChair)
{
	if(!IsValidChair(nChair))
	{
		LOG(">> CPlayerList::GetUserName() : chair = %d\n",nChair);
		return NULL;
	}

	if(!m_player[nChair].IsValidUser())
		return NULL;

	return m_player[nChair].szUserName;
}

DWORD CPlayerList::GetUserFaceID(int nChair)
{
	if(!IsValidChair(nChair))
	{
		LOG(">> CPlayerList::GetUserFaceID() : chair = %d\n",nChair);
		return 0;
	}

	if(!m_player[nChair].IsValidUser())
		return 0;

	return m_player[nChair].nFaceID;
}

BOOL CPlayerList::SetEnableLookOn(int nChair,int bEnableLookOn)
{
	if(!IsValidChair(nChair))
	{
		LOG(">> CPlayerList::SetEnableLookOn() : chair = %d\n",nChair);
		return FALSE;
	}
	if(!m_player[nChair].IsValidUser())
	{
		LOG(">> CPlayerList::SetEnableLookOn() : chair = %d\n",nChair);
		return FALSE;
	}
	m_player[nChair].bEnableLookOn = bEnableLookOn;
	return TRUE;
}

BOOL CPlayerList::SetPlayerStage(short nPlayerID,GAME_STAGE stage)
{
	int nChair = FindPlayer(nPlayerID);
	if(nChair < 0)
	{
		LOG(">> CPlayerList::SetPlayerStage() : can find player[%d]\n",(WORD)nPlayerID);
		return FALSE;
	}
	if(!m_player[nChair].IsValidUser())
	{
		LOG(">> CPlayerList::SetPlayerStage() : invalid player on chair[%d]",nChair);
		return FALSE;
	}
	m_player[nChair].stage = stage;
	return TRUE;
}

DWORD CPlayerList::GetPlayerID(int nChair)
{
	if(!IsValidChair(nChair))
	{
		LOG(">> CPlayerList::GetPlayerID() : invalid chair[%d]",nChair);
		return MAX_TABLE_USER_ID;
	}
	return m_player[nChair].nUserID;
}

BOOL CPlayerList::SetAgreePeace(int nChair)
{
	m_player[nChair].bAgreePeace = TRUE;
	return TRUE;
}

BOOL CPlayerList::SetWaitPeace(BOOL bWait)
{
	m_bWaitForAnswerPeace = bWait;
	return TRUE;
}

BOOL CPlayerList::GetCanSetPeace()
{ // ����Ƿ�������ú���
	if(!m_bWaitForAnswerPeace)
		return FALSE;
	for(int chair = 0; chair < MAX_TABLE_PLAYER; chair++)
		if(m_player[chair].IsValidUser())
			if(!m_player[chair].bAgreePeace)
				return FALSE;
	return TRUE;
}

CPlayerInfo* CPlayerList::GetPlayerByPlayerID(short sPlayerID)
{
	for( int i=0; i<MAX_TABLE_PLAYER; i++ )
	{
		if( m_player[i].nUserID == sPlayerID )
		{
			return &m_player[i];
		}
	}
	return NULL;
}
CPlayerInfo* CPlayerList::GetPlayerInfo(int nChair)
{
	if(nChair >= MAX_TABLE_PLAYER || nChair < 0)
	{
		LOG("����:CPlayerList::GetPlayerInfo, nChair=%d ������Χ", nChair);
		return NULL;
	}

	return &m_player[nChair];
}

//#####################################################################################
	
MY_NAMESPACE_END