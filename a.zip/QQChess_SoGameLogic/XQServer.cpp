#include "StdAfx.h"
#include "XQServer.h"
#include "ScaleScore.h"

MY_NAMESPACE_BEGIN
#ifndef PLAYER_IDENTTITY_PLAYER_GVIP
#define PLAYER_IDENTTITY_PLAYER_GVIP		0x00000080		// �������
#endif


#define SHOW_REMOVE_GUESS_TIP ShowMsg(nPlayerID, ("�Բ��𣬾��²��ֹ����Ѿ��رա��������µ���Ϸ�ͻ����Ի�ȡ��������"))

#define REGRET_TIME_LIMIT  30
int CXQServer::m_nReadTime = -1;

static const int INIT_USER_SCORE = 1300; // ����ҵĳ�ʼ����
static const int IGNORE_STEP	 = 2;	 // ���ڴ˲���, ����������

//######################################################################################
CXQServer::CXQServer()
: m_nSameRankScoreVary(10)
, m_nHighRankScoreWin(5)
, m_nHighRankScoreLose(15)
, m_nLowRankScoreWin(15)
, m_nLowRankScoreLose(5)
, m_bRankEvaluationRoom(False)
{
	m_nRoundTime = 0;	// ��Ϸ��ʱ
	m_nStepTime  = 0;
	m_nLastTime  = 0;
	m_bStopCounting  = FALSE;
	m_bTimeCountting = FALSE;
	
	m_pMainServer   = NULL;
	m_nCountCur     = -1;
	m_bSetTimeState = FALSE;

	m_nMainState = STATE_GETREADY;

	m_nRedSide = -1;

	// ��ǰû���˻�������

	m_nRegretSide = -1;
	m_nPeaceSide  = -1;
	cansettime[0]=FALSE;
	cansettime[1]=FALSE;
	m_nowregret=FALSE;

	m_bOnceStart = FALSE;
	memset(&m_stRankCfgInfo, 0, sizeof(m_stRankCfgInfo));
	m_dwGameSecond = 0;
    m_pSoCL = NULL;
}

CXQServer::~CXQServer()
{
    if (m_pSoCL)
    {
        m_pSoCL->FinalSoCommLogic();
    }
}

//######################################################################################

enum enRankRoomType
{
    ENM_RANK_ROOM_TEST = 1,     //�������ⷿ�� 
	ENM_RANK_ROOM_GAME = 2,     //��λ����
};

void CXQServer::Create(ITable* pTable, int iMode, const char* pszConFile, ISoCommLogic *pSoCL)
{
	m_pMainServer = pTable;
	//��ʼ�� ����ģ��
//	m_GuessSvr.Initialize( pTable, &m_stLogFile, &m_ServerConfig.m_CfgFile );
    STRUCT_SO_INIT_PARAM stInitParam;
    stInitParam.pITable = pTable;
    stInitParam.unGameID = 27;
    stInitParam.unGameMsgID = ID_COMMLOGIC;
    stInitParam.unMsgHeaderLen = offsetof(GAME_CMD_DATA, data);
    stInitParam.unMaxNumPlayer = 2;
    if (!pSoCL->InitSoCommLogic(*this, stInitParam))
    {
        pSoCL->FinalSoCommLogic();
        m_pSoCL = NULL;
    }
    else
    {
        m_pSoCL = pSoCL;
    }

	ReadConFile(pszConFile, m_pMainServer->GetGameTableID());
	if(iMode==0) Init();

	m_PlayerList.SetLogPtr(m_pMainServer, m_pstLogFile);
	m_game.SetLogPtr(m_pMainServer, m_pstLogFile);

#ifndef WIN32
	m_pMainServer->GetRankCfgInfo(&m_stRankCfgInfo);
#endif

	m_bRankEvaluationRoom = ENM_RANK_ROOM_TEST == m_stRankCfgInfo.m_iRankRoomType;

	m_nSameRankScoreVary = m_ServerConfig.m_nSameRankScoreVary;
	m_nHighRankScoreWin = m_ServerConfig.m_nHighRankScoreWin;
	m_nHighRankScoreLose = m_ServerConfig.m_nHighRankScoreLose;
	m_nLowRankScoreWin = m_ServerConfig.m_nLowRankScoreWin;
	m_nLowRankScoreLose = m_ServerConfig.m_nLowRankScoreLose;
}

//######################################################################################

int CXQServer::OnRankInfoChanged(short nPlayerID)
{
/*	TPlayerRankInfo stRankInfo = {0};
	m_pMainServer->GetPlayerRankInfo(nPlayerID, &stRankInfo);

	CPlayerInfo* pPlayerInfo = m_PlayerList.GetPlayerByPlayerID(nPlayerID);
	if (pPlayerInfo != NULL)
	{
		GAME_CMD_DATA data;
		data.cCmdID = SID_RANK_INFO_CHANGED;
		data.cChair = 0;
		data.nDataLen = sizeof(TPlayerRankInfo) + sizeof(UINT);
		memcpy(data.data, &(pPlayerInfo->m_nUIN), sizeof(UINT));
		memcpy(data.data + sizeof(UINT), &stRankInfo, sizeof(TPlayerRankInfo));
		SendTheGameData((char*)&data, offsetof(GAME_CMD_DATA, data) + data.nDataLen);
	}*/
	return TRUE;
}

BOOL CXQServer::Init()
{
	m_PlayerList.InitData();
	m_PlayerList.GameEnd();
	m_game.End();
	m_nCurOrder = -1;
	SetAllTimerEnable(FALSE);
	m_nGameRound = 0;
	m_game.SetRoundCount(m_nGameRound);
	return TRUE;
}

//######################################################################################

void CXQServer::GameEnd()
{
	LOG("GameEnd\n");
	m_bSetTimeState = FALSE;
	
	KickOfflineUsers();
	m_PlayerList.GameEnd();
	m_game.End();
	m_nCurOrder = -1;

	// 2004-11-09
	// �����ǰ����;ֺͻ����һ��
	m_nRegretSide = -1;
	m_nPeaceSide  = -1;
	
	m_nGameRound ++;
	m_game.SetRoundCount(m_nGameRound);
	SetAllTimerEnable(FALSE);
	CleanAllTimer();
	UpdateTime();
}
//######################################################################################
//������������ǿ�ƽ�����Ϸ

BOOL CXQServer::OnGameSetGameEnd()
{ 
	GameDismiss("��������ɢ���");
	return TRUE;
}

//######################################################################################
//�û��˳���Ϸ
BOOL CXQServer::OnGameUserExit(short nPlayerID)
{
    CPlayerInfo *pPlayerInfo = m_PlayerList.GetPlayerByPlayerID(nPlayerID);
    if (pPlayerInfo)
    {
        TABLE_USER_INFO stUserInfo;
        MEMSET(stUserInfo);
        pPlayerInfo->FillTableUserInfo(stUserInfo);
        TSOPARA_COMMON_G2CL_USER_EXIT stPara;
        stPara.pUser = &stUserInfo;
        m_pSoCL->SoGameCallCommLogic(stPara);
    }
	// glacier 2009-12-8
	// �Թ��˳�������Ӱ�죬��SO�в����Թ��������Ϸ��
	if(!IsGamePlayer(nPlayerID))
	{
		// glacier 2009-12-8 note
//		m_GuessSvr.LookerExit(nPlayerID);
		return TRUE;
	}

	if(IsGamePlaying())
	{
		UserEscape(nPlayerID);
	}
	else
	{
		if (m_ServerConfig.RoomSetting.nTGA && !m_bOnceStart) 	// TGA������Ϸһ�ζ�û��ʼ�����������ߵķ�
		{
			CPlayerInfo * pExitPlayer =  m_PlayerList.GetPlayerByPlayerID(nPlayerID);
			if (pExitPlayer)
			{
				USER_SCORE score;
				memset(&score, 0, sizeof(score));
				score.dwEscapeCount = 1;
				score.lUserScore = -10;
				m_pMainServer->SetGameStart();
				m_dwGameSecond = 0;
				SetGameScoreEx(nPlayerID, pExitPlayer->m_nUIN, sizeof(USER_SCORE), &score);
				m_bOnceStart = TRUE;
				m_pMainServer->SetGameEnd();
			}
		}

		UnlockPlayerMoney(nPlayerID);
	}
// glacier 2009-12-8 note
//	m_GuessSvr.PlayerExit(nPlayerID);
// 	CPlayerInfo* pPlayerInfo = m_PlayerList.GetPlayerByPlayerID(nPlayerID);
// 	if( pPlayerInfo )
// 	{
// 		int nCount = 0;
// 		short LookerID[400];
// 		memset(LookerID, -1, sizeof(LookerID) );
// 		m_pMainServer->GetAllViewerIDBySeat( pPlayerInfo->nChair, nCount, LookerID );
// 		// glacier 2009-12-8 note
// // 		for( int i=0; i<nCount; i++ )
// // 		{
// // 			m_GuessSvr.LookerExit(LookerID[i]);
// // 		}
// 	}
	// note end

	m_PlayerList.DeletePlayer(nPlayerID);
	m_nGameRound = 0;
	m_game.SetRoundCount(m_nGameRound);

	// �������״̬����
	SendPlayerStages();

	return TRUE;
}

//######################################################################################
//�û�����ʼ

BOOL CXQServer::OnGameUserReady(short nPlayerID)
{
	LOG("OnGameUserReady\n");

	char szMsgBuf[MSG_LEN];
	memset(szMsgBuf, 0, MSG_LEN);

	EnsureScore(nPlayerID);
	
	if(!IsTestRoom())
	{
		LOG("���ǲ��Է���\n");

		if(!EnsureMoney(nPlayerID))	// �����Ϸ��
			return 0;
			
		// ��ҵ�����Ϸ��
		int nResult = m_pMainServer->LockMoney(nPlayerID, szMsgBuf);

		if(nResult == 0)
		{
			LOG("�ȴ���OnLockMoney��ȡ���������\n");
			return 0;
		}

		if(nResult != 1)
		{
			LOG("������Ϸ��ʧ��\n");
			RefuseEnter(nPlayerID, "������Ϸ��ʧ�ܣ���ȷ����û�������ط�������Ϸ��");
			return 0;
		}

		LOG("�ɹ�������Ϸ��\n");
	}

	return UserReady(nPlayerID);		
}

//######################################################################################
//�û�����

int CXQServer::OnGameUserOffLine(short nPlayerID)
{
	LOG("�û����� OnGameUserOffline\n");
	
	int nChair = m_PlayerList.FindPlayer(nPlayerID);
	
	if(nChair >= 0)
	{
		m_PlayerList.m_player[nChair].bIsOffline = TRUE;
		LOG("���%d����\n", nPlayerID);

		if(m_bSetTimeState)
		{
			LOG("���������ʱ������е��ߣ��������");
			m_bSetTimeState = FALSE;
			SendGameEnd(endDismiss, TRUE);
		}

//		SetAllTimerEnable(FALSE);
//		UpdateTime();

		return TRUE;
	}
	else
	{
		LOG("�Թ���%d����\n", nPlayerID);
		return FALSE;
	}

	LOG("\n");
	return TRUE;
}


//######################################################################################
//�û��������½�����Ϸ
void CXQServer::SetAllTimerEnable(BOOL bEnable)
{
	m_tSeat0Total.SetEnable(bEnable);
	m_tSeat1Total.SetEnable(bEnable);
	m_tSeat0Step.SetEnable(bEnable);
	m_tSeat1Step.SetEnable(bEnable);
	m_tSeat0Last.SetEnable(bEnable);
	m_tSeat1Last.SetEnable(bEnable);
	m_bStopCounting = !bEnable;
}
//######################################################################################

//######################################################################################
//�û��������½�����Ϸ

BOOL CXQServer::OnGameUserReplay(short nPlayerID)
{
	LOG("OnGameUserReplay PlayerID=%d\n", nPlayerID);

	if(!IsGamePlayer(nPlayerID)) return FALSE; // �Թ������ֱ�ӷ���

	int nChair = m_PlayerList.FindPlayer(nPlayerID);
	m_PlayerList.m_player[nChair].bIsOffline = FALSE;

	if(IsGamePlaying())
	{
		if(m_bSetTimeState)
		{
			LOG("���������ʱ������е��ߣ��������");
			m_bSetTimeState = FALSE;
			SendGameEnd(endDismiss, TRUE);
		}

/*		if(FALSE == m_PlayerList.m_player[0].bIsOffline &&
			FALSE == m_PlayerList.m_player[1].bIsOffline)
		{
			ResumeTimeCount();
		}*/
		
		// glacier 2009-12-11 add -- �����ػ�ʱһ��ҲҪ�������
		// ��ͻ��˷��ͷ������ͣ��Ƿ�����Ϸ�ҳ�
		GAME_CMD_DATA data;
		data.cCmdID = SID_ROOM_TYPE;
		data.cChair = -1;
		data.nDataLen = sizeof(GAME_ROOM_TYPE);
		GAME_ROOM_TYPE *pRoomType = (GAME_ROOM_TYPE*)data.data;
		
		if (IsTestRoom())
		{
			pRoomType->bTestRoom = true;
		}
		else
		{
			pRoomType->bTestRoom = false;
		}
		// �����зַ���
		SendTheGameData((char *)&data, 
			offsetof(GAME_CMD_DATA,data) + sizeof(GAME_ROOM_TYPE));
		// add end

		if(!SendGameContext(nPlayerID, nChair, nChair))
			return FALSE;

		SendPlayerRegretTimes();
	}

	return TRUE;
}

BOOL CXQServer::EnsureScore(int nPlayerID)
{
	BOOL bPass = TRUE;

	// ������
	USER_SCORE score;
	memset(&score, 0, sizeof(USER_SCORE));
	m_pMainServer->GetPlayerScore(nPlayerID, (int*)&score);
	
	if(score.lUserScore < m_ServerConfig.RoomSetting.nMinPlayerScore)
	{
		char buf[50];
		_snprintf(buf, sizeof(buf), "���Ļ��ֲ���%d�������ڱ���������Ϸ��", 
			m_ServerConfig.RoomSetting.nMinPlayerScore);
		
		RefuseEnter(nPlayerID, buf);

		LOG("Not enough score! PlayerID:%d  Require:%d\n", 
			nPlayerID, m_ServerConfig.RoomSetting.nMinPlayerScore);

		bPass = FALSE;
	}

	return bPass;
}

//######################################################################################
// ȷ�������Ϸ������Ҫ�󣬷���Ҫ�����˳�

BOOL CXQServer::EnsureMoney(int nPlayerID)
{
	// �����Ϸ��

	int nUserMoney;
	m_pMainServer->GetMoney(nPlayerID, &nUserMoney);
	
	if(nUserMoney < m_ServerConfig.RoomSetting.nMinPlayerChip)
	{
		char buf[50];
		_snprintf(buf, sizeof(buf), "������Ϸ�Ҳ���%d�������ڱ���������Ϸ��", m_ServerConfig.RoomSetting.nMinPlayerChip);
		RefuseEnter(nPlayerID, buf);
		LOG("Not enough money! Player:%d  Require:%d\n", nUserMoney, m_ServerConfig.RoomSetting.nMinPlayerChip);
		return FALSE;
	}

	LOG("Enougth Money, Welcome!\n");
	return TRUE;
}

//######################################################################################
// ��Ϸ��ʱ

int CXQServer::OnGameTimer()
{

	++m_dwGameSecond;

	if (m_requesttpeace.GetTickCount()>15&&m_PlayerList.m_bWaitForAnswerPeace==TRUE)
	{
			char ans[10];
			BOOL *myans=(BOOL *)ans;
			*myans=FALSE;
			RecvAnswerPeace(m_otherplayer,m_otherchair,ans,10);	
	}
	if (m_regret.GetTickCount()>15&&m_nowregret==TRUE)
	{
			char ans[10];
			BOOL *myans=(BOOL *)ans;
			*myans=FALSE;
			RecvAnswerRegret(m_otherplayerex,m_otherchairex,ans,10);	
	}

	if ((game_room_notimelimit != m_ServerConfig.RoomSetting.eRoomStyle) && m_bTimeCountting && !m_bStopCounting)
	{
		if(m_nCurOrder == 0)
		{
			if(!m_bSeat0Over)
			{
				if(m_tSeat0Total.GetTickCount() >= m_nRoundTime)
				{
					// Seat 0 ��ʱ��ʱ
					LOG("Seat 0 ��ʱ��ʱ\n");
					m_bSeat0Over = TRUE;
					
					m_tSeat0Total.Pause();
					m_tSeat0Total.SetTickCount(m_nRoundTime);
					
					m_tSeat0Step.Pause();
					m_tSeat0Step.SetTickCount(0);
					
					SetTimeCount();
				}
				else if(m_tSeat0Step.GetTickCount() >= m_nStepTime)
				{
					LOG("Seat 0 ��ʱ��ʱ");
					GameOver((SIDE)m_nCurOrder, overTimeOut);
				}
			}
			else
			{
				if(m_tSeat0Last.GetTickCount() >= m_nLastTime)
				{
					LOG("Seat 0 ���볬ʱ\n");
					GameOver((SIDE)m_nCurOrder, overTimeOut);
				}
			}
		}
		else
		{
			if(!m_bSeat1Over)
			{
				if(m_tSeat1Total.GetTickCount() >= m_nRoundTime)
				{
					// Seat 1 ��ʱ��ʱ
					LOG("Seat 1 ��ʱ��ʱ\n");
					m_bSeat1Over = TRUE;
					
					m_tSeat1Total.Pause();
					m_tSeat1Total.SetTickCount(m_nRoundTime);
					
					m_tSeat1Step.Pause();
					m_tSeat1Step.SetTickCount(0);
					
					SetTimeCount();
				}
				else if(m_tSeat1Step.GetTickCount() >= m_nStepTime)
				{
					// Seat 1 ��ʱ��ʱ
					LOG("Seat 1 ��ʱ��ʱ\n");
					GameOver((SIDE)m_nCurOrder, overTimeOut);
				}
			}
			else
			{
				if(m_tSeat1Last.GetTickCount() >= m_nLastTime)
				{
					LOG("Seat 1 ���볬ʱ\n");
					GameOver((SIDE)m_nCurOrder, overTimeOut);
				}
			}
		}
	}
	
	if (stagePlaying == m_game.GetGameStage() 
		&& m_ServerConfig.RoomSetting.bSupportCapacityLookOn 
		&& m_ServerConfig.RoomSetting.nSyncGameDataInterval > 0 
		&& m_dwGameSecond % m_ServerConfig.RoomSetting.nSyncGameDataInterval == 0)
	{
		SendTheLookOnSyncGameData();
	}
	
	return 1;
}

void CXQServer::SetTestUser(TABLE_USER_INFO* pInfo)
{

}

//######################################################################################
//�û�������Ϸ

BOOL CXQServer::OnGameUserEnter(TABLE_USER_INFO *pUser)
{
	printf("m_stRankCfgInfo.m_iRankRoomType ===============================%d\n", m_stRankCfgInfo.m_iRankRoomType);
	LOG("OnGameUserEnter UIN:%u\n", pUser->m_iUin);

	SetTestUser(pUser);

	SendVersion(pUser->m_nPlayerID);
	
	// �������״̬����
	SendPlayerStages();

	// ����ǳ�ʼ�û�, �����ͳ�ʼ����
	InitPlayerScore(pUser);

	SendLuxuryVipInfo(pUser->m_nPlayerID);

	short nState = pUser->m_nState;

	if(sSit == nState)
	{
		LOG("�û�����sSit״̬\n");
		
		EnsureScore(pUser->m_nPlayerID);

		if(!IsTestRoom())
		{
			if(!EnsureMoney(pUser->m_nPlayerID))
				return 0;
			else
				ShowWelcomeMsg(pUser->m_nPlayerID);
		}

		if(!m_PlayerList.AddPlayer(pUser))
			return FALSE;

		m_score[pUser->m_nChair].InitData();
		SendReadyStateToAll();
		SetEnterTimer();

		// glacier 2009-12-8 note
		//��ҽ���
		// m_GuessSvr.PlayerEnter(pUser);

		//���� ��ҿ��Ծ���
		// m_GuessSvr.LookerEnter(pUser);

		//���������Ϣ
		// m_GuessSvr.SendBaseGuessInfo(pUser->m_nPlayerID);
		// note end

		m_bOnceStart = FALSE;
	}
	else if(sLookOn == nState)
	{
		LOG("�û�����sLookOn״̬\n");
		SendGameContext(pUser->m_nPlayerID, pUser->m_nChair, pUser->m_nChair);

		// glacier 2009-12-8 note
		//�Թ��߽���
		// m_GuessSvr.LookerEnter(pUser);
		//���������Ϣ
		// m_GuessSvr.SendBaseGuessInfo(pUser->m_nPlayerID);
		// note end
	}
	else
	{
		LOG("�û�����sLookOn �� sSit �����״̬%d\n", nState);
		return FALSE;
	}

	// glacier 2009-12-11 add
	// ��ͻ��˷��ͷ������ͣ��Ƿ�����Ϸ�ҳ�
	GAME_CMD_DATA data;
	data.cCmdID = SID_ROOM_TYPE;
	data.cChair = -1;
	data.nDataLen = sizeof(GAME_ROOM_TYPE);
	GAME_ROOM_TYPE *pRoomType = (GAME_ROOM_TYPE*)data.data;

	if (IsTestRoom())
	{
		pRoomType->bTestRoom = true;
	}
	else
	{
		pRoomType->bTestRoom = false;
	}
	// �����зַ���
	SendTheGameData((char *)&data, 
		offsetof(GAME_CMD_DATA,data) + sizeof(GAME_ROOM_TYPE));

    data.cCmdID = SID_ROOM_TYPE_EX;
    data.cChair = -1;
    data.nDataLen = sizeof(GAME_ROOM_TYPE_EX);
    memset(data.data, 0, sizeof(data.data));
	GAME_ROOM_TYPE_EX *pRoomTypeEx = (GAME_ROOM_TYPE_EX*)data.data;
    pRoomTypeEx->eRoomStyle = m_ServerConfig.RoomSetting.eRoomStyle;
    SendTheGameDataTo(pUser->m_nPlayerID, (char *)&data, 
        offsetof(GAME_CMD_DATA,data) + sizeof(GAME_ROOM_TYPE_EX));

    TSOPARA_COMMON_G2CL_USER_ENTER stPara;
    stPara.pUser = pUser;
    m_pSoCL->SoGameCallCommLogic(stPara);

	// add end
	if (IsRankEvaluationRoom())
	{
		if (sSit == nState)
		{
			UserReady(pUser->m_nPlayerID);
		}
	}
	
	return TRUE;
}

//######################################################################################

void CXQServer::SendReadyStateToAll()
{
	for(int chair = 0; chair < MAX_TABLE_PLAYER; chair++)
	{
		if(m_PlayerList.m_player[chair].IsValidUser())
		{
			if(m_PlayerList.m_player[chair].stage == stageReady)
			{
				GAME_CMD_DATA data;
				data.cCmdID = SID_GAME_USER_READY;
				data.cChair = -1;
				data.nDataLen = sizeof(NOTIFY_GAME_READY);
				NOTIFY_GAME_READY* gameready =(NOTIFY_GAME_READY*) data.data;
				gameready->nChair = chair;
				
				SendTheGameData((char *)&data,offsetof(GAME_CMD_DATA,data) + sizeof(NOTIFY_GAME_READY));
				
				LOG("Read user:%d found,send to all player \n ",chair);
			}
		}		
	}	
}

//######################################################################################

BOOL CXQServer::GameBegin()
{
	LOG("GameBegin\n");

	m_dwGameSecond = 0;
	m_bSetTimeState = TRUE;
	m_StepList.RemoveAll();
	
	m_game.ResetLongCatchRecord();

	if(m_game.GetGameStage() != stagePlaceChess)
	{
		LOG("����:GameStage ���Ǵ��� stagePlaceChess ״̬\n");
		return FALSE;
	}
	
	if(!m_PlayerList.GameBegin())
	{
		LOG("m_PlayerList.GameBegin() error\n");
		return FALSE;
	}

	// �������״̬����
	SendPlayerStages();
	SendSetTimeSetting(-1);
	
	if(!m_game.OnGameBegin())
	{
		LOG("m_game.OnGameBegin() error\n");
		return FALSE;
	}

	m_SaveGameContext.InitData();
	m_game.SetGameStage(stagePlaying);

	for(int chair = 0; chair < MAX_TABLE_PLAYER; chair++)
	{
		m_score[chair].InitData();
		if(!m_PlayerList.IsValidUser(chair))
			continue;
		m_score[chair].nUserID = m_PlayerList.m_player[chair].nUserID;

		SIDE_INFO *pSideInfo = &m_SaveGameContext.sideInfo[chair];
		pSideInfo->InitData();
		pSideInfo->nUserID = (WORD)m_PlayerList.GetPlayerID(chair);
		pSideInfo->nFaceID = (WORD)m_PlayerList.GetUserFaceID(chair);
		pSideInfo->chair = chair;
		strncpy(pSideInfo->szName,m_PlayerList.GetUserName(chair),MAX_NAME_LEN);
		pSideInfo->lScore = 0;	

	}
	m_SaveGameContext.cbSideCount = (BYTE)m_PlayerList.m_nPlayerCount;

	SetNextOrder();
	m_SaveGameContext.cRedSide = m_nCurOrder;
	
	LOG("��Ϸ��ʼ,�������壨�췽����Ϊ%d\n",m_nCurOrder);

	m_nRedSide = m_nCurOrder;

	// glacier 2009-12-8 note
	//samygong zengjia 2006 10 30
	// m_GuessSvr.SetFirstRunOrder(m_nRedSide, FALSE);
	//end
	// note end
	
	//������Ϸ��ʼ��Ϣ����
	GAME_CMD_DATA data;
	data.cCmdID = SID_GAME_BEGIN;
	data.cChair = -1;
	data.nDataLen = sizeof(NOTIFY_GAME_BEGIN);
	NOTIFY_GAME_BEGIN* gamebegin =(NOTIFY_GAME_BEGIN*) data.data;
	gamebegin->nCurOrder = m_nCurOrder;
	gamebegin->nPlayerNum = m_PlayerList.m_nPlayerCount;
	SendTheGameData((char *)&data,offsetof(GAME_CMD_DATA,data) + sizeof(NOTIFY_GAME_BEGIN));

	GAME_BOARD_DATA board;
	board.cCurOrder = m_nCurOrder;
	//��m_game�л�ȡ��������
	memcpy(board.achessman,m_game.m_iChessmanMap,132*sizeof(int));
	memcpy(board.pointChessman,m_game.m_pointChessman,32*sizeof(POINT));
	board.pointBoxFrom = m_game.m_pointBoxFrom;
	board.pointBoxTo   = m_game.m_pointBoxTo;
	board.iSide        = m_game.m_iSide;

	m_GameBoardList.InitData(&board);	

	SendTheLookOnSyncGameData();
	
	m_bOnceStart = TRUE;

	return TRUE;
}

//######################################################################################
// ��鵱ǰ��Ϸ�����Ƿ�Ӧ���ɴ�λ���з������������Ƿ�����Ϸ��

BOOL CXQServer::IsActionExpected(int nChair, int nGameCmdID)
{
	LOG("����Ƿ��ֵ����û�ִ�д˶��� IsActionExpected\n");

	if(m_game.GetGameStage() != stagePlaying)
	{
		LOG("����:IsActionExpected GameStage=%d����stagePlaying״̬\n", m_game.GetGameStage());
		return FALSE;	
	}

	if(nGameCmdID == CID_REQ_REGRET)
	{
		if(nChair == m_nCurOrder)
		{
			LOG("����:���û������ڴ�ʱ�������\n");
			return FALSE;
		}
		else
			return TRUE;
	}

	if(nChair != m_nCurOrder)
	{
		LOG("����:��Ӧ�õ����û�����\n");
		return FALSE;
	}

	return TRUE;
}

//######################################################################################

BOOL CXQServer::SetNextOrder()
{
	if(m_game.GetGameStage() != stagePlaying)
	{
		LOG("SetNextOrder() : m_GameStage = %d\n",m_game.GetGameStage());
		return FALSE;
	}

	int nStart = 1;

	if(m_nGameRound%2)
		nStart = 0;

	// �������һ�ֿ�ʼ(m_nCurOrder = -1), ����ʵ�����������췽���߼�

	int nLoopChair = m_nCurOrder == -1 ? nStart : (m_nCurOrder - 1);

	BOOL bFound = FALSE; int nFindCount = 0;

	while(!bFound && nFindCount < MAX_TABLE_PLAYER)
	{			
		if(nLoopChair < 0)
			nLoopChair = MAX_TABLE_PLAYER - 1;
		if(m_PlayerList.m_player[nLoopChair].IsValidUser()
			&& m_PlayerList.m_player[nLoopChair].stage == stagePlaying)
		{
			bFound = TRUE;
			break;
		}
		nLoopChair--; nFindCount++;
	}
	if(!bFound)
	{
		LOG("SetNextOrder() : can not find next order\n");
		return FALSE;
	}
	m_nCurOrder = nLoopChair;

	SetTimeCount();
	m_PlayerList.SetWaitPeace(FALSE);
	
	return TRUE;
}

//######################################################################################

BOOL CXQServer::GameOver(SIDE side, GAME_OVER_TYPE overType)
{
	LOG("CXQServer::GameOver() : side = %d,overType = %d\n",side,overType);

	if(!m_PlayerList.IsValidUser(side))
	{
		LOG("Error : CXQServer::GameOver() : user on chair[%d] is invalid\n",side);
		return FALSE;
	}

	short nPlayerID = m_PlayerList.GetPlayerID(side);

	if(m_PlayerList.m_player[side].stage != stagePlaying)
	{
		LOG("Error : CXQServer::GameOver() : user on chair[%d]'s stage = %d\n",side,m_PlayerList.m_player[side].stage);
		return FALSE;
	}
	
	m_score[side].overType = overType;
	m_PlayerList.m_player[side].stage = stageGameOver;

//	if(overType == overEscape || overType == overError)		
//	{
//		if(overType == overEscape)
//			m_score[side].SetEscape(-m_ServerConfig.RoomSetting.nEscapeScore, -m_ServerConfig.RoomSetting.nEscapeChip);	
//		else 
//			m_score[side].SetNotSubScore();	
//	}

	BOOL bGameEnd = FALSE;

	if(m_PlayerList.m_nPlayerCount == 2)
	{
		bGameEnd = TRUE;
		int sideEnemy = (side + 1) % 2 ;
		
		if(!IsLessToIgnore())
		{
			if(overEscape != overType)
			{
//				OutputDebugString("Chat---GameOver");
				CountChessScore(false, sideEnemy);
			}
		}
		else
		{
			m_score[side].SetFail(0, 0);
			m_score[sideEnemy].SetWin(0, 0);
		}
	}
	
	if(!bGameEnd)
	{
		if(m_nCurOrder == side)
			SetNextOrder();		// ���NOTIFY_GAME_OVER.nCurOrder 
	}
	else 
	{
		m_nCurOrder = -1;
	}

	m_bTimeCountting = FALSE;
	// ֪ͨ������Ϸ����

	GAME_CMD_DATA data(side,SID_GAME_OVER);
	NOTIFY_GAME_OVER gameover;
	gameover.cChair  =  side;
	gameover.nUserID =  nPlayerID;
	gameover.overType = overType;
	gameover.nCurOrder = m_nCurOrder;
	data.SetData(&gameover,sizeof(NOTIFY_GAME_OVER));
	
	LOG("GameOver, gameend is %d,side:%d,playerid:%d,m_nCurOrder:%d\n",bGameEnd,side,nPlayerID,m_nCurOrder);

	SendTheGameData((char *)&data,offsetof(GAME_CMD_DATA,data) + sizeof(NOTIFY_GAME_OVER));

	if(bGameEnd)
	{		
		if(overEscape == overType)
		{
			return SendGameEnd(endEscape,TRUE);
		}
		else
		{
			return SendGameEnd(endGameEnd,TRUE);
		}
	}
	
	return TRUE;
}

BOOL CXQServer::AddStep(MOVE_RESULT_EX* step)
{
	m_StepList.Add(step);
	return m_StepList.GetSize() <= MAX_GAME_STEPS;
}

enum enmRankOpType
{
    ENM_ADD = 0,
	ENM_SET
};

BOOL CXQServer::SendGameEnd(GAME_END_TYPE endType, BOOL bScoreValid)
{
	//#######################################################
	//# 1�����������Ϊ���ܶ�����������������ҵķ���(��Ϸ��)
	//# 2����������ҷ���SID_GAME_END
	//# 3������GameEnd()������б���
	//# 4��֪ͨMainServer��Ϸ����
	//# 4�����������˵���Ϸ��
	//#######################################################
	
	m_nMainState   = STATE_GETREADY;

	m_bTimeCountting = FALSE;
	NOTIFY_GAME_END end;

	end.GameEndType   = endType;
	end.bIsValidScore = bScoreValid;

	end.lLookerOnWinMoney = 0;

// 	TCHAR szTemp[MAX_PATH] = {0};
// 	_snprintf(szTemp, MAX_PATH-1, "Chat---SendGameEnd0::Money0:%d--Money1:%d", m_score[0].Score.lMoney, m_score[1].Score.lMoney);
//	OutputDebugString(szTemp);
	// ��ע�⡿

	for(int chair = 0; chair < MAX_TABLE_PLAYER; chair++)
	{
		if(bScoreValid && !m_score[chair].IsNotSet() 
			&& m_score[chair].overType != overEscape) // overEscapeʱ���Ѿ��۹���
		{
			if(endEscape != endType)
			{
//				OutputDebugString("Chat---SendGameEnd0");
				unsigned int uin = 0;
				CPlayerInfo *p =  m_PlayerList.GetPlayerInfo(chair);
				if (p != NULL)
				{
					uin = p->m_nUIN;
				}
				
				SetMoneyScore(m_score[chair].nUserID, &m_score[chair].Score,uin);
			}
		}
		else if (m_ServerConfig.RoomSetting.nTGA != 0)
		{
			// TGA�����к;�Ҫ����
			if (endStepOver == endType || endPeace == endType)
			{
				m_score[chair].SetPeace(0, 0);
				unsigned int uin = 0;
				CPlayerInfo *p =  m_PlayerList.GetPlayerInfo(chair);
				if (p != NULL)
				{
					uin = p->m_nUIN;
				}
				SetMoneyScore(m_score[chair].nUserID, &m_score[chair].Score, uin);
			}
		}
		// glacier 2009-12-9 note
		// ����ֻ��Ϊ�˿ͻ��˵���ʾ������Ϸ�Ҳ�Ϊ0ʱ����ʾ��Ϸ�ң���Ϸ��Ϊ0ʱ����ʾ����
		// ��ʵ���϶���Ϸ�Һͻ��ֶ�д���ݿ���
		// blueliu 2007.07.12
		// ��������Ϸ�ұ仯ʱʵ�ʻ��ֲ��仯,(ΪʲôҪ����?I don't know,��ֻ�Ǹ�bug)
		// ���ｫ���͸��ͻ��˵����ݴ�����ʵ��һ��(��ʱ���ٸĳɱȽϷ����߼���������)
		if(m_score[chair].Score.lMoney != 0)
		{
			end.lScore[chair] = 0;
		}
		else
		{
			end.lScore[chair] = m_score[chair].Score.lUserScore;
		}
		// end
		// note end
		end.GameOverType[chair] = m_score[chair].overType;

		// Living 2003-9-28
		end.lMoney[chair] = m_score[chair].Score.lMoney;
		
// 		memset(szTemp, 0, MAX_PATH);
// 		_snprintf(szTemp, MAX_PATH-1, "Chat---SendGameEnd1::Score:%d--Money:%d", m_score[chair].Score.lUserScore, m_score[chair].Score.lMoney);
// 		OutputDebugString(szTemp		LOG("Chair:%d Score:%d Money:%d\n", chair, m_score[chair].Score.lUserScore, m_score[chair].Score.lMoney);
	}

	// ���� Living Version 2.7
	end.bWinner = GetWinner();

	if( end.bWinner==2 || (end.bWinner!=2 && end.lMoney[0]<0 && end.lMoney[1]<0) )
	{
		end.lMoney[0] = end.lMoney[1] = 0;
	}
	
	int nPos = 0;
	GAME_CMD_DATA data(NO_CHAIR,SID_GAME_END);
	data.SetData(&end,sizeof(NOTIFY_GAME_END));

	NOTIFY_GAME_END cmdEnd;
	memcpy( &cmdEnd, &end, sizeof(NOTIFY_GAME_END) );

	data.SetData(&cmdEnd,sizeof(NOTIFY_GAME_END));
	if (!IsRankEvaluationRoom())
	{
		SendTheGameData((char*)&data,
			offsetof(GAME_CMD_DATA,data) + sizeof(NOTIFY_GAME_END));
	}

	//////////////////////////////////////////////////////////////////////////
	if (IsRankEvaluationRoom()
		&& m_PlayerList.GetPlayerInfo(0) != NULL
		&& m_PlayerList.GetPlayerInfo(1) != NULL)
	{
		short shPlayerId0 = m_PlayerList.GetPlayerID(0);
		short shPlayerId1 = m_PlayerList.GetPlayerID(1);

		TPlayerRankInfo stRankInfo0 = {0};
		TPlayerRankInfo stRankInfo1 = {0};
		m_pMainServer->GetPlayerRankInfo(shPlayerId0, &stRankInfo0);
		m_pMainServer->GetPlayerRankInfo(shPlayerId1, &stRankInfo1);

		NOTIFY_RANK_EVALUATION_GAME_END stEndInfo;
		for (int i = 0 ; i < 2 ; ++i)
		{
			short shPlayerId = 0 == i ? shPlayerId0 : shPlayerId1;
			short shOppPlayerId = 0 == i ? shPlayerId1 : shPlayerId0;
			const TPlayerRankInfo& stRankInfo = 0 == i ? stRankInfo0 : stRankInfo1;
			const TPlayerRankInfo& stOppRankInfo = 0 == i ? stRankInfo1 : stRankInfo0;
			const BYTE byWinner = GetWinner();

			TRankGameResult stResult = {0};
			stResult.m_iWinOrLose = ((2 == byWinner) ? ENM_EQUAL : ((byWinner == i) ? ENM_WIN : ENM_LOSE));
			if (stResult.m_iWinOrLose != ENM_EQUAL)
			{
				stResult.m_iPoints = (ENM_WIN == stResult.m_iWinOrLose ? 1 : (endEscape == endType ? -2 : -1))
					* (stRankInfo.m_shRank == stOppRankInfo.m_shRank ? m_nSameRankScoreVary 
					: (stRankInfo.m_shRank > stOppRankInfo.m_shRank ? (ENM_WIN == stResult.m_iWinOrLose ? m_nHighRankScoreWin : m_nHighRankScoreLose)
					: (ENM_WIN == stResult.m_iWinOrLose ? m_nLowRankScoreWin : m_nLowRankScoreLose)));
			}
			stResult.m_iPointsOpType = ENM_ADD;
			stResult.m_shOppID = shOppPlayerId;
			stResult.m_shOppRank = stOppRankInfo.m_shRank;
			m_pMainServer->UpdateRankGameResults(shPlayerId, &stResult);

			TPlayerRankInfo stPlayerRankInfo = {0};
			m_pMainServer->GetPlayerRankInfo(shPlayerId, &stPlayerRankInfo);
			stEndInfo.bGrandMaster[i] = (stPlayerRankInfo.m_shRank + 1) >= m_stRankCfgInfo.m_uiRankCount;
			if (!stEndInfo.bGrandMaster[i])
			{
				const TRankInfo& stRankInfo = m_stRankCfgInfo.m_stRanks[stPlayerRankInfo.m_shRank + 1];
				int nOffsetScore = stRankInfo.m_iLowerBound - stPlayerRankInfo.m_iRankPoints;
				if (nOffsetScore > 0
					&& m_nSameRankScoreVary != 0
					&& m_nHighRankScoreWin != 0)
				{
					stEndInfo.nLeftWinInningCountSame[i] = nOffsetScore / m_nSameRankScoreVary + ((nOffsetScore % m_nSameRankScoreVary) == 0 ? 0 : 1);
					stEndInfo.nLeftWinInningCountLow[i] = nOffsetScore / m_nHighRankScoreWin + ((nOffsetScore % m_nHighRankScoreWin) == 0 ? 0 : 1);
				}
			}
			stEndInfo.nWinInningCount[i] = stPlayerRankInfo.m_iRankWin;
			stEndInfo.nLoseInningCount[i] = stPlayerRankInfo.m_iRankLose;
			stEndInfo.nEqualInningCount[i] = stRankInfo.m_iRankEqual;
			stEndInfo.cRankChange[i] = stRankInfo.m_shRank == stPlayerRankInfo.m_shRank ? 0 : (stRankInfo.m_shRank < stPlayerRankInfo.m_shRank ? 1 : 2);
			unsigned int nMatchCountThisMonth = 0;
			m_pMainServer->GetPlayerPeriodMatchCount(shPlayerId, nMatchCountThisMonth);
			stEndInfo.nLeftInningCount[i] = m_stRankCfgInfo.m_uiMustMatchCountPerMonth > nMatchCountThisMonth ? (m_stRankCfgInfo.m_uiMustMatchCountPerMonth - nMatchCountThisMonth) : 0;
			if (stPlayerRankInfo.m_shRank >= 0
				&& stPlayerRankInfo.m_shRank < m_stRankCfgInfo.m_uiRankCount)
			{
				_snprintf(stEndInfo.szCurRankName[i], sizeof(stEndInfo.szCurRankName[i]), "%s", m_stRankCfgInfo.m_stRanks[stPlayerRankInfo.m_shRank].m_szName);
			}
		}

		GAME_CMD_DATA stCmd(NO_CHAIR, SID_RANK_EVALUATION_GAME_END);
		stEndInfo.GameEndType = endType;
		stEndInfo.bWinner = GetWinner();
		stCmd.SetData(&stEndInfo, sizeof(stEndInfo));
		SendTheGameData((char*)&stCmd,
			offsetof(GAME_CMD_DATA, data) + sizeof(NOTIFY_RANK_EVALUATION_GAME_END));
	}
	//////////////////////////////////////////////////////////////////////////
	
	SaveRoundRecord();
	GameEnd();
	m_pMainServer->SetGameEnd();
	
	UnlockAllMoney();

	return TRUE;
}

// ��ȡ�Ծֽ�� 0 ��ʾ chair 0 ʤ��, 1 ��ʾ chari 1 ʤ��
// 2 ��ʾ�;�.���ô˺���ʱҪ��m_score�б����Ѿ���д����
BYTE CXQServer::GetWinner()
{
	BYTE bRet = 2;

	if( 1 == m_score[0].Score.dwWinCount ||
		1 == m_score[1].Score.dwLostCount||
		1 == m_score[1].Score.dwEscapeCount)
	{
		bRet = 0;
	}
	else if(1 == m_score[0].Score.dwLostCount ||
		    1 == m_score[0].Score.dwEscapeCount)
	{
		bRet = 1;
	}
	else
	{
		bRet = 2;
	}

	return bRet;
}

void CXQServer::GameDismiss(LPCSTR szDismissReason)
{

	// ������ǿ�ƽ�ɢ��Ϸ
	// glacier 2009-12-8 note
	//samygong add
	// m_GuessSvr.SetGameEnd(eGMInvalid);
	//end
	// note end

	m_bTimeCountting = FALSE;
	if(m_game.GetGameStage() != stagePlaying)
	{
		LOG("GameDismiss() : m_GameStage = %d\n",m_game.GetGameStage());
	}

	GAME_CMD_DATA data(NO_CHAIR,SID_DISMISS_GAME);
	data.SetData((void*)szDismissReason,strlen(szDismissReason));
	SendTheGameData(const_cast<char *>(data.GetBuf()),data.GetDataLen());
	
	GameEnd();
	m_pMainServer->SetGameEnd();

	UnlockAllMoney();	
}



BOOL CXQServer::SendGameContext(short nPlayerID, int nChair, int nChairToShowChess)
{
	LOG("CXQServer::SendGameContext nPlayerID=%d nChair=%d nChairToShowChess=%d\n", nChair, nChairToShowChess);

	GAME_CMD_DATA data(-1,SID_GAME_CONTEXT);

	GAME_CONTEXT_DATA gamedata;
	gamedata.cCurOrder = m_nCurOrder;

	//��m_game�л�ȡ��������
	memcpy(gamedata.achessman, m_game.m_iChessmanMap, 132*sizeof(int));
	memcpy(gamedata.pointChessman, m_game.m_pointChessman, 32*sizeof(POINT));
	gamedata.pointBoxFrom = m_game.m_pointBoxFrom;
	gamedata.pointBoxTo   = m_game.m_pointBoxTo;
	gamedata.iSide        = m_game.m_iSide;

	memcpy(&(gamedata.context), &m_SaveGameContext, sizeof(GAME_CONTEXT));
	data.SetData(&gamedata, sizeof(GAME_CONTEXT_DATA));
	SendTheGameDataTo(nPlayerID, (char *)&data, offsetof(GAME_CMD_DATA,data) + sizeof(GAME_CONTEXT_DATA));

	LOG(">> CXQServer::SendGameContext() : m_GameStage = %d , nPlayerID = %d\n",m_game.GetGameStage(),nPlayerID);

	// ����ʷ��¼�����Թ��� Living 2003-10-26
	SendStepList(nPlayerID);

	UpdateTime();	// add by living 2003-11-12	

	return TRUE;

}

BOOL CXQServer::SendStepList(short nPlayerID)
{
	GAME_CMD_DATA cmd_data(-1, SID_MOVE_RECORD);

	int nSize  = m_StepList.GetSize();
	int nTimes = ((nSize - 1) / RECORD_COUNT) + 1;
	int nCount = 0;

	MOVE_RECORD move_record;

	for(int i=0; i<nTimes; i++)
	{
		nCount = nSize - RECORD_COUNT * i;
		nCount = nCount < RECORD_COUNT?nCount:RECORD_COUNT;
		move_record.nStepCount = nCount;
		LOG("����:���͵�%d�μ�¼,����%d��\n", i, move_record.nStepCount);
		for(int k=0; k<nCount; k++)
		{
			move_record.MoveResult[k] = m_StepList.GetData(RECORD_COUNT * i + k);
		}
		memcpy(cmd_data.data, &move_record, sizeof(MOVE_RECORD));
		SendTheGameDataTo(nPlayerID, (char *)&cmd_data, offsetof(GAME_CMD_DATA, data) + sizeof(MOVE_RECORD));
	}
	
	return TRUE;
}

void CXQServer::CleanRegretAndPeace()
{
	if(-1 != m_nRegretSide)
	{
		int nRegID = m_PlayerList.GetPlayerID(m_nRegretSide);
		ShowMsg(nRegID, "�Բ��𣬶Է��Ѿ����壬���Ļ�������������");
		m_nRegretSide = -1;
	}

	if(-1 != m_nPeaceSide)
	{
		int nRegID = m_PlayerList.GetPlayerID(m_nPeaceSide);
		ShowMsg(nRegID, "�Բ��𣬴�ʱ�����ܽ������");
		m_nPeaceSide = -1;
	}
}

BOOL CXQServer::RecvMove(short nPlayerID,int nChair, LPCSTR buf, int nLen)
{
	LOG("CXQServer ���Ҫ���ƶ����� PlayerID:%d Chair:%d \n",
		nPlayerID, nChair);

	//������ݰ���С�Ƿ�Ϸ�
	int nSize = sizeof(MOVE_REQ);
	if(nLen < nSize)
	{
		LOG("����: MOVE_REQ ���ݳ��� %d < %d\n",nLen,nSize);
		return FALSE;
	}

	MOVE_REQ *req = (MOVE_REQ*)buf;
	if(req->wHeaderSize != nSize)
	{
		LOG("����: MOVE_REQ ��ͷ���� %d != %d\n",nLen,req->wHeaderSize);
		return FALSE;
	}

	//����Ƿ��ֵ���λ�õ��û�����Ϣ
	if(!IsActionExpected(nChair, CID_REQ_MOVE))
	{
		LOG("����:��Ӧ���ֵ����û�����");
		return FALSE;
	}

	// ������������ͻ�������������ҷ�����Ϣ
	CleanRegretAndPeace(); 
	
	// ����һ���Ժ����������巽������;ַ�
	m_nRegretSide = -1;
	m_nPeaceSide  = -1;

	
	MOVE_REQ *pStep = (MOVE_REQ*)buf;

	if(pStep->chessSource == EVENT_FLAG)
	{ // ���ܽ����¼���¼
		char str[256];
		_snprintf(str, sizeof(str), "CID_REQ_MOVE : event[%d] comes",pStep->chessTarget);
		LOG("%s\n",str);
		return FALSE;
	}

	if(pStep->cbX >= 11)
		return FALSE;

	if(pStep->cbDestY >= 12)
		return FALSE;

	POINT fp,tp;
	fp.x = pStep->cbX;
	fp.y = pStep->cbY;
	tp.x = pStep->cbDestX;
	tp.y = pStep->cbDestY;

	int from,to;
	from = m_game.GetChessFromPoint(fp);
	to   = m_game.GetChessFromPoint(tp);

	LOG("�û�Ҫ������:(%d,%d) %d->(%d,%d) %d\n",
		fp.x, fp.y, from, tp.x, tp.y, to);

	if(from == 32 || SideOfMan[from] != nChair)
	{
		LOG("Error:from:%d,sideofman[from]:%d,nChair:%d\n", from, SideOfMan[from], nChair);
		return FALSE;
	}

	if(!m_game.CanGo(from,fp,tp))
	{
		LOG("Error:Chess:%d attack %d cannot go from x:%d,y:%d to x:%d,y:%d\n",
			from,to,
			fp.x,fp.y,
			tp.x,tp.y);

		if(m_game.GetCannotGoReason() == Err_FACE_TO_FACE)
		{
			ShowMsg(nPlayerID, "�Բ��𣬸ò����������˧���棬���Բ���ִ��");
		}

		return FALSE;
	}

	LOG("***** Going to go *****\n");

	int nAutoCheckWinLoseResult = 0;
	
	int nGoResult = m_game.Go(from,tp, nAutoCheckWinLoseResult);

	//**************************************************************
	if(Err_LONG_KILL_FORBID == nGoResult)      // 3 ��ʾ����Υ��
	{
		GAME_CMD_DATA test(nChair, SID_DANGER_OVER);
		SendTheGameDataTo(m_PlayerList.GetPlayerID(nChair), (char *)&test, offsetof(GAME_CMD_DATA,data));
		LOG("***** DangerOver *****\n");

		if(!SendGameContext(m_PlayerList.GetPlayerID(nChair), nChair, nChair))
			return FALSE;
		
		return FALSE;
	}
	else if (Err_LONG_CATCH_FORBID == nGoResult) // 4 ��ʾ��׽Υ�� add by brady
	{
		GAME_CMD_DATA test(nChair, SID_LONGCATCH_OVER);
		SendTheGameDataTo(m_PlayerList.GetPlayerID(nChair), (char *)&test, offsetof(GAME_CMD_DATA,data));
		LOG("***** DangerOver *****\n");
		
		if(!SendGameContext(m_PlayerList.GetPlayerID(nChair), nChair, nChair))
			return FALSE;
		
		return FALSE;
	}
	
	//**************************************************************

	LOG("RecvMove() check move vaild\n");

	GAME_CMD_DATA data;
	data.cChair = (char)nChair;
	data.cCmdID = SID_MOVE_RESULT;
	MOVE_RESULT *pRet =(MOVE_RESULT*)data.data;

	pRet->InitData();
	pRet->x = pStep->cbX; 
	pRet->y = pStep->cbY;
	pRet->xTo = pStep->cbDestX; 
	pRet->yTo = pStep->cbDestY; 
	pRet->chess = from;
	pRet->nStepSeq = m_StepList.GetSize() + 1;
	
	// ��¼�߲�
	AddStep((MOVE_RESULT_EX*)pRet);

	// glacier 2009-12-8 note
	//samygong add 2006 4 5
//	m_GuessSvr.AddGameStep();
	//end
	// note end

	// �����巽�Ĳ�ʱ��ʱ���� 04-01-29 ����û�������bug
	CleanStepTime();

	if(!SetNextOrder())
	{ 
		char str[256];
		_snprintf(str, sizeof(str), "CID_REQ_MOVE : m_game.SetNextOrder() error");
		LOG("%s\n",str);
		return FALSE;
	}

	//SetTimeCount();	// add by living


	// �������˷��ʹ˶���
	pRet->cCurOrder = (char)m_nCurOrder;
	WORD size = 0;
	SendTheGameData((char *)&data,offsetof(GAME_CMD_DATA,data) + sizeof(MOVE_RESULT)+size*2);
	LOG("RecvMove():�������˷������Ӷ���\n");


	GAME_BOARD_DATA board;
	board.cCurOrder = m_nCurOrder;
	//��m_game�л�ȡ��������
	memcpy(board.achessman,m_game.m_iChessmanMap,132*sizeof(int));
	memcpy(board.pointChessman,m_game.m_pointChessman,32*sizeof(POINT));
	board.pointBoxFrom = m_game.m_pointBoxFrom;
	board.pointBoxTo   = m_game.m_pointBoxTo;
	board.iSide        = m_game.m_iSide;

	m_GameBoardList.Add(&board);

	if(m_StepList.GetSize() > MAX_GAME_STEPS)
	{ 
		// �Ƿ񳬹�200������
		return SendGameEnd(endStepOver,TRUE);
	}

	if(m_game.GetGameStage() == stagePlaying &&  to != 32)
	{ 
		LOG("check if gameOver:%d!!!,to:%d\n",SideOfMan[to],to);
		
		if(ManToType[to] == RED_K || ManToType[to] == BLACK_K)
		{
			LOG("The GameOver:%d!!!\n",SideOfMan[to]);
			if(!GameOver((SIDE)SideOfMan[to],overFlag))
				goto ERROR_GAME_OVER;
		}
		else if(m_StepList.GetSize() > MAX_GAME_STEPS)
		{ 
			// �Ƿ񳬹�200������
			return SendGameEnd(endStepOver,TRUE);
		}
	}

	if (0 != nAutoCheckWinLoseResult)
	{
		if(!GameOver((SIDE)(0 == nChair ? 1 : 0), overJueSha))
		{
			goto ERROR_GAME_OVER;
		}
//		return SendGameEnd(endGameEnd, TRUE);
	}
	else if (m_game.GetGameStage() == stagePlaying)
	{
		if (m_game.m_nCurNotEatStep >= m_game.m_nMaxNotEatStep)
		{
			CountChessScore(true);			

			return SendGameEnd(endPeace,TRUE);
		}
		else if ((m_game.m_nCurNotEatStep + m_game.m_nTipNotEatStep) == m_game.m_nMaxNotEatStep)
		{
			GAME_CMD_DATA data;
			data.cCmdID			= SID_NOTIFY_MSG;
			data.cChair			= 0;
			data.nDataLen		= 0;
			char* pData = (char*) data.data;
#ifdef WIN32
			_snprintf(pData, MAX_PATH, "��ע�⣬���ٹ�%d���غ�˫����û�г��ӣ�ϵͳ���ж����̺���", m_game.m_nTipNotEatStep / 2);
#else
			snprintf(pData, MAX_PATH, "��ע�⣬���ٹ�%d���غ�˫����û�г��ӣ�ϵͳ���ж����̺���", m_game.m_nTipNotEatStep / 2);
#endif
			SendTheGameData((char *)&data, sizeof(data));
		}
	}
	

	// ��Ϸ�Ѿ��������˳�
	return TRUE;

ERROR_GAME_OVER: // GameOverʱ���ִ���
	char str[256];
	_snprintf(str, sizeof(str), "CID_REQ_MOVE : GameOver() error");
	LOG("%s\n",str);
	return FALSE;

}

BOOL CXQServer::RecvTimerSet(short nPlayerID,int nChair,LPCSTR buf, int nLen)
{
	if (m_nMainState  != STATE_SETTIME)
	{
		return FALSE;
	}
	if (nChair==0&&cansettime[0]==FALSE)
	{
		return FALSE;
	}
	if (nChair==1&&cansettime[1]==FALSE)
	{
		return FALSE;
	}

	if (nChair==0)
	{
		cansettime[0]=FALSE;

	}
	if (nChair==1)
	{
		cansettime[1]=FALSE;
	}

	for(int chair = 0; chair < MAX_TABLE_PLAYER; chair++)
	{
		if(!m_PlayerList.IsValidUser(chair))
			continue;

		short nOtherPlayerID = m_PlayerList.GetPlayerID(chair);
		if(nOtherPlayerID == nPlayerID)
			continue;

		GAME_CMD_DATA data;
		data.cCmdID = SID_TIMERSET;
		data.cChair = -1;
		data.nDataLen = sizeof(BoardTimeSet);
		BoardTimeSet* pData =(BoardTimeSet*) data.data;
		memcpy(pData,buf,sizeof(BoardTimeSet) + 1 );

		if( m_ServerConfig.RoomSetting.nPreestablish == 0 ) //����Ԥ��ʱ�䷿�� 
		{
			if(pData->wMins * 60 + pData->wSecs < 60)
			{
				if (nChair==0)
				{
					cansettime[0]=TRUE;
				}
				if (nChair==1)
				{
					cansettime[1]=TRUE;
				}
				return FALSE;
			}
			
			if(pData->wStepMins * 60 + pData->wStepSecs < 30)
			{
				if (nChair==0)
				{
					cansettime[0]=TRUE;
				}
				if (nChair==1)
				{
					cansettime[1]=TRUE;
				}
				return FALSE;
			}
			
			if(pData->wLastMin * 60 + pData->wLastSec < 30)
			{
				if (nChair==0)
				{
					cansettime[0]=TRUE;
				}
				if (nChair==1)
				{
					cansettime[1]=TRUE;
				}
				return FALSE;
			}
			
			if(pData->wStepMins * 60 + pData->wStepSecs > pData->wMins * 60 + pData->wSecs)
			{
				if (nChair==0)
				{
					cansettime[0]=TRUE;
				}
				if (nChair==1)
				{
					cansettime[1]=TRUE;
				}
				return FALSE;
				
			}

			m_nRoundTime = pData->wMins * 60 + pData->wSecs;
			m_nStepTime  = pData->wStepMins * 60 + pData->wStepSecs;
			m_nLastTime  = pData->wLastMin * 60 + pData->wLastSec;
		
			LOG("sizeof BoardTimeSet = %d m_nRoundTime=%d\n", sizeof(BoardTimeSet), m_nRoundTime);
		}

		// glacier 2009-12-8 add
		// ���ͻ��˷������ĵ׷���գ����ظ���һ�����
		pData->unBaseMoney = 0;
		// add end
		m_nowregret=FALSE;

		SendTheGameDataTo(nOtherPlayerID,(char *)&data,offsetof(GAME_CMD_DATA,data) + sizeof(BoardTimeSet));				
	}	

	return TRUE;
}

//��Ϸ��Ϣ���ݵ���
BOOL CXQServer::OnGameMessage(short nPlayerID, int nChair, void* pData, short nLen)
{
	LOG("CXQServer::OnGameMessage()\n");
	
	int nLengthKeep = nLen;

	if(nLen < 1)
	{
		LOG(">>CXQServer::OnGameMessage() : nLen = %d\n",nLen);
		return FALSE;
	}
	if(!IsValidChair(nChair))
	{
		LOG(">>CXQServer::OnGameMessage() : nChair = %d\n",nChair);
		return FALSE;
	}

	GAME_CMD_DATA* pBuf = (GAME_CMD_DATA* )pData;

	char *buf=(char*)pBuf->data;
	char cmd = pBuf->cCmdID;

	//samygong add
	char* pUI = (char*)pBuf->data;
	//end

	nLen -= 8;

	if(cmd != CID_MANAGER && cmd != CID_REQ_SAVE_GAME)
	{ 
		if(!m_PlayerList.m_player[nChair].IsValidUser())
		{
			LOG(">>CXQServer::OnGameMessage() : invalid User[%d] on Chair[%d],not User[%d]\n",(WORD)m_PlayerList.m_player[nChair].nUserID,nChair,(WORD)nPlayerID);
			return FALSE;
		}
		else if(m_PlayerList.m_player[nChair].nUserID != nPlayerID)
		{
			LOG(">> CXQServer::OnGameMessage() : cbSubCmd = %d,User[%d] on Chair[%d],not User[%d]\n",buf[0],(WORD)m_PlayerList.m_player[nChair].nUserID,nChair,(WORD)nPlayerID);
			return FALSE;
		}
	}
	switch(cmd)
	{
		case CID_TIMERSET:
			{
				LOG("####�յ�timerset��Ϣ��������%d \n", nLengthKeep );
				RecvTimerSet(nPlayerID,nChair,buf, nLengthKeep);
			}
			break;
		case CID_REQ_MOVE:
			{
				RecvMove(nPlayerID,nChair,buf, nLen);
			}
			break;
		case CID_REQ_GIVE_UP:
			{
				RecvGiveUp(nPlayerID,nChair);
			}
			break;
		case CID_REQ_SETPEACE:
			{
				RecvReqSetPeace(nPlayerID,nChair);
			}
			break;
		case CID_ANSWER_PEACE:
			{
				RecvAnswerPeace(nPlayerID,nChair,buf,nLen);
			}
			break;
		case CID_ANSWER_REGRET:
			{
				RecvAnswerRegret(nPlayerID,nChair,buf,nLen);
			}
			break;
		case CID_REQ_REGRET:
			{
				RecvReqRegret(nPlayerID,nChair);
			}
			break;
		case CID_PLAYER_TIME_OUT:			
			{
				RecvPlayerTimeOut(nPlayerID,nChair,buf, nLen);
			}
			break;
		case CID_ENABLE_LOOKON:
			//RecvEnableLookOn(nChair,buf, nLen);
			break;
		case CID_EXIT_AFTER_READY:
			//RecvExitAfterReady(nChair,buf, nLen);
			break;
		case CID_MANAGER:
			break;
		case CID_CONFIRM_TIME: // �û��Ƿ����ʱ������
			{
				OnRecvTimeFonfirm(pBuf, nChair);
			}
			break;
	// glacier 2009-12-8 remedy, ������ʾ�����
	// ע�͵����µ���Ϣ����
	case CID_REQUEST_ADD_BASE_GUESS_MONEY://		240	//����������ӵ׽�
			{
				SHOW_REMOVE_GUESS_TIP;
			}
			break;
		case CID_REQUEST_ADD_BASS_GUESS_MONEY_ANSWER:	//	241 //��һظ��������ӵ׽�
			{
				SHOW_REMOVE_GUESS_TIP;
			}
			break;
		//������ҿ�����ע
		case CID_LOOKON_REQUEST_GUESS_MONEY:	//			242 //�Թ��߾���
			{
				SHOW_REMOVE_GUESS_TIP;
 				// m_GuessSvr.LookerGuessMoney( nPlayerID, lrgm.nUsefulCount, (int*)lrgm.nTypes, (unsigned int*)lrgm.unMoney );
			}
			break;
        case ID_COMMLOGIC:
            if (m_pSoCL)
            {
                m_pSoCL->OnSoGameMsg(nPlayerID, nChair, cmd, pData, nLengthKeep);
            }
            break;
		case CID_REQ_CHANGE_EFFECT:
			{
				RecvReqChangeEffect(nPlayerID,nChair,buf, nLengthKeep);
			}
			break;
		case ID_PRIVILEGE_SET:
			{
				RecvPrivliegeSet(nPlayerID, nChair, buf, nLengthKeep);
			}
			break;
		case CID_SUPPORT_VIP_SET_TIME_FIRST:
			{
				RecvSupportVipSetTimeFirst(nPlayerID, nChair, buf, nLengthKeep);
			}
			break;
		default:
			LOG("CXQServer::OnGameMessage() : unknown command = %d\n",buf[0]);
			break;
	}
	return TRUE;
}

// ����Ͷ��
BOOL CXQServer::RecvGiveUp(short nPlayerID,int nChair)
{
	if(!IsActionExpected(nChair,CID_REQ_GIVE_UP))
		return FALSE;
	char strError[256];
	memset(strError,0x00,256);
	if(m_StepList.GetSize() < MIN_GIVEUP_STEP)
		strncpy(strError, "���ڲ���Ͷ����Ϊ��ֹ���ף�20��֮�ڲ���Ͷ��", 255);
	if(strlen(strError))
	{
		GAME_CMD_DATA data((char)nChair,SID_ANSWER_GIVE_UP);
		data.SetData(strError,strlen(strError));
		//SendTheGameDataTo(m_PlayerList.GetPlayerID(nChair),data.GetBuf(),data.GetDataLen());
		SendTheGameDataTo(m_PlayerList.GetPlayerID(nChair),(char *)&data,offsetof(GAME_CMD_DATA,data));

		LOG("=========RecvGiveup(%d,%d),Error:%s \n",nPlayerID,nChair,strError);
		return TRUE;
	}

	//AddEvent(nChair,EVENT_GIVE_UP,0);

	GameOver((SIDE)nChair,overGiveUp);

	LOG("=========RecvGiveup(%d,%d),GameOver:%d \n",nPlayerID,nChair,nChair);

	return TRUE;
}

//######################################################################################
// �������

BOOL CXQServer::RecvReqRegret(short nPlayerID, int nChair)
{
	LOG("������� PlayerID=%d\n", nPlayerID);

	if(!IsActionExpected(nChair, CID_REQ_REGRET)) 
	{
		ShowMsg(nPlayerID, "�Բ��𣬶Է��Ѿ����壬���Ļ�������������");
		return FALSE;
	}

	if(m_StepList.GetSize() < 1)
		return FALSE;
	
	CPlayerInfo* pPlayer = m_PlayerList.GetPlayerInfo(nChair);
	if(pPlayer == NULL) return FALSE;

	if(pPlayer->GetRegretTimes() >= MAX_REGRET_TIMES)
	{
		ShowMsg(pPlayer->nUserID, "�Բ���һ��֮��ֻ������������");
		return FALSE;
	}

	//add by brady ��һ��Aʣ��ʱ�䲻��30��ʱ������һ��B������壬ϵͳֱ�Ӿܾ�����Ӱ��
	if(m_nCurOrder == 0)
	{
		if((m_nStepTime - m_tSeat0Step.GetTickCount()) < REGRET_TIME_LIMIT)
		{
			LOG("Seat 0 ��ʱ����30��Seat 1�������������");
			ShowMsg(nPlayerID, "�Է�ʱ�伴���þ�����ʱ�����������Ҫ��");	
			return FALSE;
		}
	}
	else
	{
		if((m_nStepTime - m_tSeat1Step.GetTickCount()) < REGRET_TIME_LIMIT)
		{
			LOG("Seat1��ʱ����30��Seat0�������������");
			ShowMsg(nPlayerID, "�Է�ʱ�伴���þ�����ʱ�����������Ҫ��");	
			return FALSE;
		}

	}
	//add end

	pPlayer->AddRegretTimes();


	// 2004-11-09
	// ��¼�µ�ǰ�����һ��
	m_nRegretSide = nChair;

	m_regret.ReStart();
	m_nowregret=TRUE;
	

	GAME_CMD_DATA data(nChair, SID_REQ_REGRET);
	for(int chair = 0; chair < MAX_TABLE_PLAYER; chair++)
	{ 
		// ��������Ϸ��ҷ������Ϣ
		if(!m_PlayerList.IsValidUser(chair))
			continue;

		short nOtherPlayerID = m_PlayerList.GetPlayerID(chair);

		if(nOtherPlayerID == nPlayerID)
			continue;


		m_otherchairex=chair;
		m_otherplayerex=nOtherPlayerID;

		SendTheGameDataTo(nOtherPlayerID,(char *)&data,offsetof(GAME_CMD_DATA,data));
	}
	return TRUE;
}

//######################################################################################
// �����������

BOOL CXQServer::RecvReqSetPeace(short nPlayerID,int nChair)
{
	if(!IsActionExpected(nChair,CID_REQ_SETPEACE))
	{
		ShowMsg(nPlayerID, "�Բ��𣬴�ʱ�������������");
		return FALSE;
	}

	if(m_PlayerList.m_bWaitForAnswerPeace)
	{
		LOG(">> CXQServer::RecvReqSetPeace() : is waiting already\n");
		return FALSE;
	}

	m_requesttpeace.ReStart();
	
	m_PlayerList.SetWaitPeace(TRUE);
	m_PlayerList.SetAgreePeace(nChair);
	
	// 2004-11-09
	// ��¼�µ�ǰ����;ֵ�һ��
	m_nPeaceSide = nChair;

	GAME_CMD_DATA data(nChair,SID_REQ_SETPEACE);
	for(int chair = 0; chair < MAX_TABLE_PLAYER; chair++)
	{ // ��������Ϸ��ҷ������Ϣ
		if(!m_PlayerList.IsValidUser(chair))
			continue;
		short nOtherPlayerID = m_PlayerList.GetPlayerID(chair);
		if(nOtherPlayerID == nPlayerID)
			continue;
		//SendTheGameDataTo(nOtherPlayerID,data.GetBuf(),data.GetDataLen());
		SendTheGameDataTo(nOtherPlayerID,(char *)&data,offsetof(GAME_CMD_DATA,data));
		m_otherchair=chair;
		m_otherplayer=nOtherPlayerID;
	}
	return TRUE;
}

//######################################################################################
// �յ�һ������ͻ���Ļش�

BOOL CXQServer::RecvAnswerRegret(short nPlayerID, int nChair, LPCSTR buf, int nLen)
{
	LOG("�յ��Ի���Ļش�(RecvAnswerRegret)\n");
	
	if(!EnsureGamePlaying())
		return FALSE;

	if(nLen < 4)
	{
		LOG("�������� nLen = %d\n", nLen);
		return FALSE;
	}

	if(m_StepList.GetSize()<1)
		return FALSE;


	// 2004-11-09
	// �����Ӧ�������ʱ���յ�����Ӧ��,��ܾ�
	if( (-1 == m_nRegretSide) || (m_nCurOrder == m_nRegretSide) )
	{
		m_nowregret=FALSE;
		ShowMsg(nPlayerID, "�Բ��𣬶Է��Ѿ�ȡ����������");	
		return FALSE;
	}
	m_nRegretSide = -1;
	
	m_nowregret=FALSE;


	BOOL bAgree = *(BOOL*)buf;

	if(bAgree)
	{
		LOG("ͬ�����\n");
		
		// Version 2.6 Add - Begin
		m_nRegretSide = -1;
		m_nPeaceSide  = -1;
		CleanStepTime();
		SetNextOrder();
		// Version 2.6 Add - End

		GAME_BOARD_DATA board = m_GameBoardList.GetUndoData();
		UpdateBoardData(board);
		SendBoardData(board);
		m_StepList.Regret();
		m_game.Regret();

		LOG("���ͻ��˷��ͻ���Ӧ����Ϣ\n");
		SendAllRegret(bAgree);
	}
	else
	{
		// �����ͬ�����, ֪ͨ����
		for(int i = 0; i < MAX_TABLE_PLAYER; i++)
		{
			if(i != nChair)
			{
				int l_nPlayerID = m_PlayerList.GetPlayerID(i);
				SendAllRegret(FALSE, l_nPlayerID);
			}
		}
	}

	return TRUE;
}

void CXQServer::SendAllRegret(BOOL bAgree, int nPlayerID)
{
	GAME_CMD_DATA data;
	data.cCmdID   = SID_REGRET_STEP;
	data.cChair   = -1;
	data.nDataLen = 1;
	data.data[0]  = bAgree;
				
	if(-1 == nPlayerID)
	{
		SendTheGameData((char *)&data, 
			offsetof(GAME_CMD_DATA,data) + 5);
	}
	else
	{
		SendTheGameDataTo(nPlayerID, (char *)&data, 
			offsetof(GAME_CMD_DATA,data) + 5);
	}
}

//######################################################################################
// �ѵ�ǰ���������ݸ���

void CXQServer::UpdateBoardData(GAME_BOARD_DATA& bdBoardData)
{
	LOG("���µ�ǰ����������UpdateBoardData\n");
	m_nCurOrder = bdBoardData.cCurOrder;
	memcpy(m_game.m_iChessmanMap, bdBoardData.achessman, 132*sizeof(int));
	memcpy(m_game.m_pointChessman, bdBoardData.pointChessman, 32*sizeof(POINT));
	m_game.m_pointBoxFrom = bdBoardData.pointBoxFrom;
	m_game.m_pointBoxTo   = bdBoardData.pointBoxTo;
	m_game.m_iSide        = bdBoardData.iSide;
}

//######################################################################################
// ֻ�л�����ܵ����������
void CXQServer::SendBoardData(GAME_BOARD_DATA& bdBoardData)
{
	LOG("�������˷�����������\n");
	GAME_CMD_DATA data(-1,SID_GAME_BOARD);
	data.SetData(&bdBoardData, sizeof(GAME_BOARD_DATA));
	SendTheGameData((char *)&data, offsetof(GAME_CMD_DATA,data) + sizeof(GAME_BOARD_DATA));
}

//######################################################################################

void CXQServer::SendCommandToAll(int nCmd)
{
	GAME_CMD_DATA data(-1, nCmd);
	SendTheGameData((char *)&data, offsetof(GAME_CMD_DATA,data));
}

BOOL CXQServer::IsLessToIgnore()
{
	int nStepCount = m_StepList.GetSize();
	return nStepCount < IGNORE_STEP;
}

//######################################################################################
// �յ�һ�����������Ļش�

BOOL CXQServer::RecvAnswerPeace(short nPlayerID, int nChair,LPCSTR buf, int nLen)
{
	LOG(">> CXQServer::RecvAnswerPeace() : nLen = %d",nLen);

	if(m_game.GetGameStage() != stagePlaying)
		return FALSE;

	if(nLen < 4)
	{
		return FALSE;
	}

	if(!m_PlayerList.m_bWaitForAnswerPeace)	// �Ѿ����˲�ͬ������ˣ�������ҵ�Ӧ�����
		return TRUE;


	// 2004-11-09
	// �����Ӧ�������ʱ���յ��;�Ӧ��,��ܾ�
	if( (-1 == m_nPeaceSide) || (m_nCurOrder != m_nPeaceSide) )
	{
		ShowMsg(nPlayerID, "�Բ��𣬶Է��Ѿ�ȡ���;�����");
		return FALSE;
	}
	m_nPeaceSide = -1;

	
	BOOL bAgree = *(BOOL*)buf;

	if(bAgree)
	{
		m_PlayerList.SetAgreePeace(nChair);
	
		if(m_PlayerList.GetCanSetPeace())
		{
			if(!IsLessToIgnore())
			{
				CountChessScore(true);			
			}

			SendGameEnd(endPeace,TRUE);
		}
	}
	else
	{
		m_PlayerList.SetWaitPeace(FALSE);
		// ���˲�ͬ�����
		GAME_CMD_DATA data(nChair,SID_DENY_PEACE);
		// �������˷��;ܾ���Ϣ
		SendTheGameData((char *)&data,offsetof(GAME_CMD_DATA,data));
	}
	
	return TRUE;
}

// �û���ʱ
BOOL CXQServer::RecvPlayerTimeOut(short nPlayerID, int nChair, LPCSTR buf, int nLen)
{
	LOG("===========recv timeout from %d nChair===== \n",nChair);
	if(!IsActionExpected(nChair,CID_PLAYER_TIME_OUT))
		return FALSE;

	m_PlayerList.m_player[nChair].nTimeOutCount++;
	int nCount = m_PlayerList.m_player[nChair].nTimeOutCount;

	if(nCount >= MAX_TIME_OUT_COUNT)
	{		
		GameOver((SIDE)nChair,overTimeOut);
		return TRUE;
	}

	if(!SetNextOrder())
		return FALSE;

	// ֪ͨ������
	GAME_CMD_DATA data(nChair,SID_PLAYER_TIME_OUT);
	NOTIFY_TIME_OUT t(m_nCurOrder,nCount);
	data.SetData(&t,sizeof(NOTIFY_TIME_OUT));
	//SendTheGameData(data.GetBuf(),data.GetDataLen());
	SendTheGameData((char *)&data,offsetof(GAME_CMD_DATA,data) + sizeof(NOTIFY_TIME_OUT));

	return TRUE;
}

// �û��ı��Թ�״̬
BOOL CXQServer::RecvEnableLookOn(int nChair, LPCSTR buf, int nLen)
{
	if(nLen != sizeof(ENABLE_LOOKON))
	{
		LOG(">> CXQServer::RecvEnableLookOn() : nLen = %d,%d wanted\n",nLen,sizeof(ENABLE_LOOKON));
		return FALSE;
	}
	return TRUE;
}

// ���ָ������ĳ���Թ�
BOOL CXQServer::RecvPostEnableLookOn(int nChair, DWORD dwDestUserID, LPCSTR buf, int nLen)
{
	if(nLen != sizeof(ENABLE_LOOKON))
	{
		LOG(">> CXQServer::RecvPostEnableLookOn() : nLen = %d,%d wanted\n",nLen,sizeof(ENABLE_LOOKON));
		return FALSE;
	}
	return TRUE;
}

//������Ϸ�������ݸ�ָ�����
BOOL CXQServer::SendGameSaveData(short nPlayerID,const char* pcGameData, short nDataLen)
{

	int nSize = 1000;
	
	char cCount = 0;
	while(nDataLen > nSize)	//������ݴ���1000����ְ�����
	{
		GAME_CMD_DATA data;
		data.cCmdID = SID_ANSWER_SAVE_GAME;
		data.cChair = cCount;
		data.nDataLen = nSize;			

		memcpy(data.data,pcGameData,nSize);

		SendTheGameDataTo(nPlayerID,(char *)&data,offsetof(GAME_CMD_DATA,data)+nSize);

		nDataLen -= nSize;
		cCount ++;
		pcGameData += nSize*cCount;

		LOG("\n===SendGameSaveData to player:%d by index:%d===\n",nPlayerID,cCount);
	}

	if(nDataLen > 0)
	{
		GAME_CMD_DATA data;
		data.cCmdID = SID_ANSWER_SAVE_GAME;
		data.cChair = (char)0xff;  //���һ������0xff��־
		data.nDataLen = nDataLen;

		memcpy(data.data,pcGameData,nDataLen);

		SendTheGameDataTo(nPlayerID,(char *)&data,offsetof(GAME_CMD_DATA,data)+nDataLen);

		LOG("\n===SendGameSaveData to player:%d by index:%d===\n",nPlayerID,0xff);
	}

	return TRUE;
}

//�ۿ�����client���Ѿ��򿪲�������Ϸ��
int CXQServer::OnViewerMessage(short nPlayerID, int nChair, void * pcGameData, short nDataLen)
{
	LOG("CXQServer::OnViewerMessage nPlayerID=%d nChair=%d\n", nPlayerID, nChair);
	printf("CXQServer::OnViewerMessage(\n");

	if(nDataLen < 1)
	{
		LOG(">>CXQServer::OnViewerMessage() : nLen = %d\n",nDataLen);
		return FALSE;
	}
	if(!IsValidChair(nChair))
	{
		LOG(">>CXQServer::OnViewerMessage() : nChair = %d\n",nChair);
		return FALSE;
	}

	GAME_CMD_DATA* pBuf = (GAME_CMD_DATA* )pcGameData;

	char *buf=(char*)pBuf->data;
	char cmd = pBuf->cCmdID;

//	printf("cmd is %d when guess money is %d, datalen is %d", cmd, CID_LOOKON_REQUEST_GUESS_MONEY, nDataLen);

	//samygong add
	char* pUI = (char*)pBuf->data;
	//end
	
	int nRes = 1;

	switch(cmd)
	{
	case CID_LOOKON_REQUEST_GUESS_MONEY:	//			242 //�Թ��߾���
		{
			// glacier 2009-12-8 remedy 
			// ȡ�����²�������
			SHOW_REMOVE_GUESS_TIP;
// 			LOOKON_REQUEST_GUESS_MONEY lrgm;
// 			lrgm.Decode(pUI);
// 			if( 0!=lrgm.CheckData(eGMBegin, eGMOverflow, 2000000000) ) // 20��
// 			{
// 				printf("ERROR Guess Data!");
// 				nRes = 0;
// 				break;
// 			}
// 			m_GuessSvr.LookerGuessMoney( nPlayerID, lrgm.nUsefulCount, (int*)lrgm.nTypes, (unsigned int*)lrgm.unMoney );
			// remedy end
		}
		break;
    case ID_COMMLOGIC:
        if (m_pSoCL)
        {
            m_pSoCL->OnSoGameMsg(nPlayerID, nChair, cmd, pcGameData, nDataLen);
        }
        break;
	default:
		nRes = SendGameContext(nPlayerID,nChair,nChair);
	}

	return nRes;
}

int CXQServer::GetLastWinLoss(int *piTotalPlayer, short *pnPlayers, short *pnWinLossStatus)	
{
	*piTotalPlayer = 2;

	for(int i=0;i<2;i++)
	{
		pnPlayers[i] = m_score[i].nUserID;		

		if(m_score[i].Score.dwWinCount == 1)
		{
			pnWinLossStatus[i]	= 0;
		}
		else if(m_score[i].Score.dwLostCount == 1)
		{
			pnWinLossStatus[i]	= 1;
		}
		else if(m_score[i].Score.dwDogfall == 1)
		{
			pnWinLossStatus[i]	= 2;
		}
	}
	return 0;
}

int CXQServer::RefuseEnter(int nPlayerID, LPCSTR szMsg)
{
	GAME_CMD_DATA data;
	
	data.cCmdID = SID_FORCE_QUIT;
	data.cChair = -1;
	
	int nLen = strlen(szMsg);
	data.nDataLen = nLen + 1;

	strncpy(data.data, szMsg, 1199);

	SendTheGameDataTo(nPlayerID, (char *)&data, offsetof(GAME_CMD_DATA, data) + nLen + 1);
				
	return 1;
}

int CXQServer::ShowMsg(int nPlayerID, LPCSTR szMsg)
{
	GAME_CMD_DATA data;
	data.cCmdID = SID_SHOW_MSG;
	data.cChair = -1;
	int nLen = strlen(szMsg);
	data.nDataLen = nLen + 1;
	strncpy(data.data, szMsg, 1199);
	SendTheGameDataTo(nPlayerID, (char *)&data, 
		offsetof(GAME_CMD_DATA, data) + nLen + 1);
	return 1;
}

int CXQServer::ShowCUQGMsg(int nPlayerID, LPCSTR szMsg)
{
	GAME_CMD_DATA data;
	data.cCmdID = SID_SHOW_CUQG_MSG;
	data.cChair = -1;
	int nLen = strlen(szMsg);
	data.nDataLen = nLen + 1;
	strncpy(data.data, szMsg, 1199);
	SendTheGameDataTo(nPlayerID, (char *)&data, offsetof(GAME_CMD_DATA, data) + nLen + 1);
	return 1;
}


int CXQServer::OnLockMoney(short nPlayerID, short nResultID, char *szErrMsg)
{
	// glacier 2009-12-8 note
	// �������ע����û�б�Ҫ���Թ��ߵ����������ж���
	//samygong add
// 	if( -1==m_PlayerList.FindPlayer(nPlayerID) || m_ServerConfig.RoomSetting.nIsGambleRoom==0 )
// 	{
// 		m_GuessSvr.OnLockUserMoney(nPlayerID, nResultID);
// 		return 1;
// 	}
	//end
	// note end
	
	// ����Ϸ�ҳ���������Ϸ��
	if(m_ServerConfig.RoomSetting.nIsGambleRoom == 0)
	{
		// �������ϰ����
		return 0;
	}

	//�ȼ����Ϸ�ҹ�����
	if(EnsureMoney(nPlayerID) == 0)
	{
		return 0;
	}
		
	if(nResultID != 0)	//ʧ��
	{
		ShowMsg(nPlayerID, "������Ϸ��ʧ�ܣ���ȷ����û�������ط�������Ϸ��");
		LOG("Lock money fail in OnLockMoney\n");
		return 0;
	}
	
	LOG("Lock money success in OnLockMoney\n");
	UserReady(nPlayerID);

	return 1;
}

int CXQServer::UserReady(short nPlayerID)
{
	LOG("��� PlayerID=%d ��ʼ\n",nPlayerID);

	if(!m_PlayerList.SetPlayerStage(nPlayerID,stageReady))
	{
		LOG(">>CXQServer::OnGameUserReady(%d) : SetPlayerStage stageReady\n",nPlayerID);
		return FALSE;
	}

	// �������״̬����
	SendPlayerStages();
	
	GAME_CMD_DATA data;
	data.cCmdID = SID_GAME_USER_READY;
	data.cChair = -1;
	data.nDataLen = sizeof(NOTIFY_GAME_READY);
	NOTIFY_GAME_READY* gameready =(NOTIFY_GAME_READY*) data.data;
	gameready->nChair = m_PlayerList.FindPlayer(nPlayerID);
	
	SendTheGameData((char *)&data,offsetof(GAME_CMD_DATA,data) + sizeof(NOTIFY_GAME_READY));
	
	
	int nPlayerNum = 0;
	for(int chair = 0; chair < MAX_TABLE_PLAYER; chair++)
	{
		if(m_PlayerList.m_player[chair].IsValidUser())
			nPlayerNum++;
	}
	
	//�����Ϸ�Ƿ���Կ�ʼ�����������֪ͨmain server��ʼ
	BOOL bStart = FALSE;
	LOG("CXQServer::OnGameUserReady(),player num is %d\n",nPlayerNum);
	if(nPlayerNum == 2)
	{
		if( m_PlayerList.m_player[0].stage == stageReady && 
			m_PlayerList.m_player[1].stage == stageReady  )
			bStart = TRUE;
		else
		{
			LOG("CXQServer::OnGameUserReady(),%d,%d\n",
				m_PlayerList.m_player[0].stage,
				m_PlayerList.m_player[1].stage
				);
		}
	}
	
	if(bStart)
	{
		/* Add start Living 2004-02-10 */
		m_nMainState   = STATE_SETTIME;
		/* Add end */
		cansettime[0]=TRUE;
		cansettime[1]=TRUE;
		
		GameBegin();
		m_pMainServer->SetGameStart();
		CleanAllTimer();

		SendEffectSetting(-1);

		// glacier 2009-12-8 note
		/*
		//samygong add 2007 4 5 //����ģʽ��ʼ
		m_GuessSvr.SetGameBegin();
		if( m_ServerConfig.RoomSetting.nIsGambleRoom == 0 )
		{
			m_GuessSvr.SetUnLockPlayerMoneyAfterGuess(TRUE);
		}
		else
		{
			m_GuessSvr.SetUnLockPlayerMoneyAfterGuess(FALSE);
		}
		//end
		*/

		/* ���� ��ʼ Living 2004-2-6 */
		
		if((game_room_notimelimit == m_ServerConfig.RoomSetting.eRoomStyle)
            || (m_ServerConfig.RoomSetting.nPreestablish == 1)) // ����Ƿ�Ԥ��ʱ��ķ���
		{
			// glacier 2009-12-8 note
			LOG("�÷�����Ԥ�跿��\n");
// 			m_GuessSvr.SetBaseMoney( m_GuessSvr.GetMinBaseMoney() );
// 			m_GuessSvr.CutPlayerBaseMoney();
			SendTimeSet();
			// note end
		}
		else
		{
			LOG("����Ԥ�跿��\n");
			SendCommandToAll(SID_SET_TIME);
		}
		
		/* ���� ���� Living 2004-2-6 */
		
	}
	
	return TRUE;
}

//samygong add
void CXQServer::SendGameCmdTo(short nPlayerID, char CCmd)
{
	if( -1==nPlayerID )
	{
		SendCommandToAll(CCmd);
	}
	else
	{
		GAME_CMD_DATA data(-1, CCmd);
		SendTheGameDataTo(nPlayerID, (char *)&data, offsetof(GAME_CMD_DATA,data));
	}
}
//end

int CXQServer::UnlockAllMoney()
{
	// �������˵���Ϸ�ҽ���

	// ����ǲ��Է��䣬�򷵻�
	if(m_ServerConfig.RoomSetting.nIsGambleRoom == 0)
		return TRUE;

	char szError[200];
	for(int chair = 0; chair < MAX_TABLE_PLAYER; chair++)
	{
		int nPlayerID = m_PlayerList.GetPlayerID(chair);
		m_pMainServer->UnlockMoney(nPlayerID, szError);
		LOG("UnlockAllMoney nPlayerID=%d chair=%d.\n", nPlayerID, chair);
		LOG("%s\n", szError);
	}
	
	return TRUE;
}

int CXQServer::SetMoneyScore(int nPlayerID, USER_SCORE* score,unsigned int uin,BOOL bTaoPao)
{

	// �趨���ֺ���Ϸ��

	LOG("\n\n");
	LOG("SetMoneyScore\n");
	LOG("PlayerID:%d\n", nPlayerID);
	LOG("Win:%ld  Lost:%ld  Escape:%ld DogFall:%ld\n", score->dwWinCount, score->dwLostCount, score->dwEscapeCount, score->dwDogfall);
	LOG("Score:%ld  Money:%ld\n", score->lUserScore, score->lMoney);
	LOG("\n\n");
	
// 	TCHAR szTemp[MAX_PATH] = {0};
// 	_snprintf(szTemp, MAX_PATH-1, "Chat---SetMoneyScore::PlayerID:%d--Score:%d--Money:%d", nPlayerID, score->lUserScore, score->lMoney);
// 	OutputDebugString(szTemp);
    if (game_room_notimelimit == m_ServerConfig.RoomSetting.eRoomStyle)
    {
        // ��ʱ�����Ʒ��䲻�Ƿ�����ʤ��ƽ��
        return FALSE;
    }

	if(abs(score->dwWinCount) > 1 || abs(score->dwLostCount) > 1 || 
	   abs(score->dwEscapeCount) > 1 || abs(score->dwDogfall) >1)
	{
	   return FALSE;
	}

	// glacier 2009-12-8 note
	// ����������ǰ����Ϸ���߼�
	//samygong add
// 	if( score->lMoney!=0 )
// 	{
// 		//���п���Ϸ�ҵĲ������ŵ�GuessSvr����ȥ
// 		return 0;
// 	}
	// end

	// ������, ��Ҫ��ˮ
	if(score->lMoney > 0)
	{
		float fTaxRate = m_ServerConfig.RoomSetting.nGambleTax;
		if(fTaxRate > 0 && fTaxRate < 100)
		{
			float fMoney = score->lMoney;
			float fMoneyGet = fMoney * fTaxRate / 100;
			fMoney = (fMoney * (100 - fTaxRate)) / 100;
			
			USER_SCORE us;
			memcpy(&us, score, sizeof(USER_SCORE));
			us.lMoney = (int)fMoney;
			us.lSharedMoney = fMoneyGet;
			us.lBillType = 2001;
			SetGameScoreEx(nPlayerID, uin, sizeof(USER_SCORE), &us);

			LOG("GambleTax is %d%% : %d -> %d\n", m_ServerConfig.RoomSetting.nGambleTax,
				score->lMoney, us.lMoney);

			score->lMoney = us.lMoney;
		}
	}
	else
	{
		if (bTaoPao)
		{
			// ��������ܣ���ҵ�lMoney�϶���Ϊ0�����Ǹ��� -- �˵�����
			score->lSharedMoney = m_ServerConfig.RoomSetting.nEscapeChip;
			score->lBillType = 2002;
		}
		SetGameScoreEx(nPlayerID,uin, sizeof(USER_SCORE), score);
	}
	
	return TRUE;
}


void CXQServer::OnRecvTimeFonfirm(GAME_CMD_DATA* pCmd, int nChair)
{
	LOG("����ȷ��ʱ������\n");
	if (m_nMainState  != STATE_SETTIME)
	{
		return;
	}

	char* pResult = pCmd->data;

	if(*pResult)	
	{
		CPlayerInfo* pPlayer = m_PlayerList.GetPlayerInfo(nChair);
		if( pPlayer )
		{
			// glacier 2009-12-8 note
			// ����һ��ҵ���Ϸ���������жϣ���ƥ�����õĵ׷�
// 			int nMoney = 0;
// 			m_pMainServer->GetMoney(pPlayer->nUserID, &nMoney);
// 			if( nMoney<0 || nMoney<m_GuessSvr.GetBaseMoney() )
// 			{
// 				m_pMainServer->KickUserFromGame(pPlayer->nUserID);
// 				LOG("�����Ϸ�Ҳ���۵׽�,�����������Ͽͻ��˵Ĺ�ϵ!");
// 				return;
// 			}
			// note end
		}
		else
		{
			if( m_pstLogFile )
			{
				m_pstLogFile->ErrLog("�ظ�����ʱ�� ���Ҳ������!!!!\n");
			}
		}
		OnTimeSetFinished();

		// glacier 2009-12-8 note
		// glacier -- �۳�����Ѻ͵׷֣���������Ӧ�ö���0��
//		m_GuessSvr.CutPlayerBaseMoney();
		// glacier -- ��ͻ��˷��;��»������ݣ�����Ӧ�ö���0��
//		m_GuessSvr.SendBaseGuessMoney();
		// note end
	}

	GAME_CMD_DATA data(nChair, SID_CONFIRM_TIME);
	char *buf=(char*)pCmd->data;
	data.SetData(buf, 1);
	SendTheGameDataExcept(m_PlayerList.GetPlayerID(nChair), (char *)&data, offsetof(GAME_CMD_DATA,data) + 10);
	
	//SendTheGameData((LPCSTR)&data, offsetof(GAME_CMD_DATA,data) + 10);
}

void CXQServer::SetTimeCount()
{
	LOG("SetTimeCount\n");
	PauseAllTimer();

	if(m_nCurOrder == 0)
	{
		if(!m_bSeat0Over)
			m_nCountCur = 0;
		else
			m_nCountCur = 1;
	}
	else
	{
		if(!m_bSeat1Over)
			m_nCountCur = 2;
		else
			m_nCountCur = 3;
	}

	switch(m_nCountCur) 
	{
	case 0:
		m_tSeat0Total.Resume();
		m_tSeat0Step.Resume();
		break;
	case 1:
		m_tSeat0Last.Resume();
		break;
	case 2:
		m_tSeat1Total.Resume();
		m_tSeat1Step.Resume();
		break;
	case 3:
		m_tSeat1Last.Resume();
		break;
	default:
		LOG("����:SetTimeCount ����� CurOrder=%d", m_nCurOrder);
		break;
	}
	UpdateTime();
}

void CXQServer::ResumeTimeCount()
{
	LOG("���߻ָ���ָ���ʱ ResumeTimeCount\n");
	SetAllTimerEnable(TRUE);
	UpdateTime();
}


//######################################################################################
// �������ļ���������,�����������趨��־�ļ�
void CXQServer::ReadConFile(LPCTSTR lpszConFile, int nTableID)
{
	m_ServerConfig.ReadCfgFile(lpszConFile, m_pSoCL);

	// glacier 2009-21-8 note
//	m_GuessSvr.ReadCfgFile(lpszConFile);
	// note end

	m_pstLogFile = &m_stLogFile;
	m_pstLogFile->SetTableID(nTableID);
	m_pstLogFile->SetLogFlag(m_ServerConfig.GetLogFlag());
	m_pstLogFile->SetErrLogFlag(m_ServerConfig.GetErrLogFlag());

	m_pstLogFile->SetLogPath(m_ServerConfig.GetLogPath());

	m_nReadTime ++;
	
	if(m_nReadTime == 0)
	{
		char szBuff[128];
		memset(szBuff, 0, 128);
		_snprintf(szBuff, sizeof(szBuff), "%d Build in %s %s\n", SERVER_VERSION, __DATE__, __TIME__);
		printf(szBuff);
		m_pstLogFile->LogFile("../version.log", szBuff);
	}
}
//######################################################################################


BOOL CXQServer::IsGamePlayer(int nPlayerID)
{
	BOOL bIsPlayer = (m_PlayerList.FindPlayer(nPlayerID) >= 0);

	if(bIsPlayer)
		LOG("PlayerID:%d ����Ϸ���\n", nPlayerID);
	else
		LOG("PlayerID:%d ������Ϸ���\n", nPlayerID);

	return bIsPlayer;
}

BOOL CXQServer::IsGamePlaying()
{
	return (m_game.GetGameStage() == stagePlaying);
}

BOOL CXQServer::EnsureGamePlaying()
{
	if(m_game.GetGameStage() == stagePlaying)
		return TRUE;
	else
	{
		LOG("����:��Ϸ���ڽ�����!\n");
		return FALSE;
	}
}

void CXQServer::UserEscape(int nPlayerID)
{
	int nChair		= m_PlayerList.FindPlayer(nPlayerID);
	int nStepCount	= m_StepList.GetSize();

	LOG("CXQServer::UserEscape nChair=%d, nStepCount=%d\n", nChair, nStepCount);

	if(nChair < 0) return;
	
	if(nStepCount <= 1
		&& !IsRankEvaluationRoom()
		&& 0 == m_ServerConfig.RoomSetting.nTGA)
	{
		SendGameEnd(endDismiss,TRUE);
		LOG("�������ڵ���1,���۷�\n");
	}
	else
	{
		if(m_score[nChair].IsNotSet())
		{ 
			int nLeaveSide = (nChair + 1) % 2 ; // ���µ�һ��
			CountChessScore(false, nLeaveSide, TRUE);
			m_score[nChair].overType = overEscape;
			
			{
				// ������ͨ��Ӯ�۷�
				unsigned int uin = 0;
				CPlayerInfo *p =  m_PlayerList.GetPlayerInfo(0);
				if (p != NULL)
				{
					uin = p->m_nUIN;
				}
				SetMoneyScore(m_score[0].nUserID, &m_score[0].Score,uin,TRUE);
				p =  m_PlayerList.GetPlayerInfo(1);
				if (p != NULL)
				{
					uin = p->m_nUIN;
				}
				SetMoneyScore(m_score[1].nUserID, &m_score[1].Score,uin,TRUE);
			}
			
			LOG("�û�chair:%d���ܿ۷�\n", nChair);
		}
		
		{
			LOG("�ȼӷ�Ҳ�۷�\n");
			GameOver((SIDE)nChair,overEscape);
		}
	}
	UnlockAllMoney();
}

BOOL CXQServer::UnlockPlayerMoney(int nPlayerID)
{
	char szError[200];
	return (0 == m_pMainServer->UnlockMoney(nPlayerID, szError));
}

BOOL CXQServer::IsTestRoom()
{
	if(m_ServerConfig.RoomSetting.nIsGambleRoom == 0)
	{
		LOG("����������ϰ����,��������Ϸ��\n");
		return TRUE;
	}
	else
	{
		LOG("�����䲻����ϰ����,������Ϸ��\n");
		return FALSE;
	}
}

void CXQServer::ShowWelcomeMsg(int nPlayerID)
{
	char buf[256];
	memset(buf, 0, 256);
				
	_snprintf(buf, sizeof(buf),
			"��ӭ����������Ϸ�ҳ���\n"
//			"�ڱ������н��е���Ϸ��ÿ��һ�ֻᱻ��%d��Ϸ�ң�ÿӮһ�ֻ��%d��Ϸ�ҡ�\r���ܽ�����%d��Ϸ�ҡ�"
			"Ϊ��������Ϸ�Ұ�ȫ��ÿ����Ϸ��ʼǰ������������Ϸ�ң�\n"
			"����������ͬʱ�������ط�ʹ����Ϸ�ң�ֱ����Ϸ������"
//			,m_ServerConfig.RoomSetting.nWinChip, 
//			m_ServerConfig.RoomSetting.nWinChip, 
//			m_ServerConfig.RoomSetting.nEscapeChip
	);
	ShowMsg(nPlayerID, buf);
}

//###################################################################################
// ��ʼ��Ϸ��ʱ,��Ϸ�ոտ�ʼʱ����
void CXQServer::StarGameTime()
{
	m_bTimeCountting = TRUE;
	m_tSeat0Total.Clean();
	m_tSeat0Step.Clean();
	m_tSeat1Total.Clean();
	m_tSeat1Step.Clean();
	m_tSeat0Last.Clean();
	m_tSeat1Last.Clean();

	m_bSeat0Over = FALSE;
	m_bSeat1Over = FALSE;

	m_bStopCounting = FALSE;
	m_nCountCur = m_nCurOrder * 2;
	
	if(m_nCurOrder == 0)
	{
		LOG("StartGameTime λ��%d����ҿ�ʼ�����ʱ�Ͳ�ʱ\n", m_nCurOrder);
		m_tSeat0Total.Resume();
		m_tSeat0Step.Resume();
	}
	else if(m_nCurOrder == 1)
	{
		LOG("StartGameTime λ��%d����ҿ�ʼ�����ʱ�Ͳ�ʱ\n", m_nCurOrder);
		m_tSeat1Total.Resume();
		m_tSeat1Step.Resume();
	}
	else
	{
		LOG("����:StartGameTime, ��ǰλ��(%d)����ȷ,Ӧ����0��1\n", m_nCurOrder);
	}

	UpdateTime();
}
//###################################################################################


//###################################################################################
// ͬ���ͻ��˵�ʱ��
void CXQServer::UpdateTime()
{
	if (m_nMainState != STATE_PLAYING) 
	{
		return;
	}

	TimeUpdate tu;
	memset(&tu, 0, sizeof(TimeUpdate));
	
	tu.nTotal0 = m_tSeat0Total.GetTickCount();
	tu.nTotal1 = m_tSeat1Total.GetTickCount();
	
	tu.nSeat0  = m_tSeat0Step.GetTickCount();
	tu.nSeat1  = m_tSeat1Step.GetTickCount();

	tu.nLast0  = m_tSeat0Last.GetTickCount();
	tu.nLast1  = m_tSeat1Last.GetTickCount();
	
	tu.nRoundTime = m_nRoundTime;
	tu.nStepTime  = m_nStepTime;
	tu.nLastTime  = m_nLastTime;

	
	if(m_bStopCounting)
		tu.nCountCur = -1;
	else
		tu.nCountCur = m_nCountCur;
	
	GAME_CMD_DATA data(0, SID_UPDATE_TIME);
	data.SetData(&tu, sizeof(TimeUpdate));
	
	SendTheGameData((char *)&data, offsetof(GAME_CMD_DATA,data) + sizeof(TimeUpdate));
	
	LOG("����ʱ��������� UpdateTime().Total0:%d Step0:%d Total1:%d Step1:%d nLast0:%d nLast1:%d nRoundTime:%d nStepTime:%d nLastTime:%d\n",
		tu.nTotal0, tu.nSeat0, tu.nTotal1, tu.nSeat1, tu.nLast0, tu.nLast1, tu.nRoundTime, tu.nStepTime, tu.nLastTime);
	LOG("�����%d\n", tu.nCountCur);
}
//###################################################################################

//###################################################################################
// ��ͣ���м�ʱ
void CXQServer::PauseAllTimer()
{
	LOG("��ͣ����Timer\n");
	m_tSeat0Total.Pause();
	m_tSeat0Step.Pause();
	m_tSeat1Total.Pause();
	m_tSeat1Step.Pause();
	m_tSeat0Last.Pause();
	m_tSeat1Last.Pause();
}
//###################################################################################

void CXQServer::CleanAllTimer()
{
	LOG("�������Timer\n");
	m_tSeat0Total.Clean();
	m_tSeat0Step.Clean();
	m_tSeat1Total.Clean();
	m_tSeat1Step.Clean();
	m_tSeat0Last.Clean();
	m_tSeat1Last.Clean();
}

void CXQServer::SendVersion(int nPlayerID)
{
	// glacier 2009-12-9 note
// 	char szVersion[200] = {0};
// 	strcpy(szVersion, "�������˰汾��:");
// 	strcat(szVersion, SERVER_VERSION);
// 	strcat(szVersion, "\n��ӭ����QQ������̳��http://xiangqi.bbs.qq.com/\n");
// 	ShowCUQGMsg(nPlayerID, szVersion);
	// note end
}

void CXQServer::SetEnterTimer()
{
	if(!IsGamePlaying())
	{
		m_nRoundTime = 0;
		m_nStepTime  = 0;
		
		CleanAllTimer();
		m_nCurOrder = -1;
		UpdateTime();
	}
}

int CXQServer::ReloadCfg(const char* pConfigFile)
{
	ReadConFile(pConfigFile, m_pMainServer->GetGameTableID());
	return TRUE;
}

void CXQServer::CleanStepTime()
{
	LOG("CXQServer::CleanStepTime\n");
	switch(m_nCountCur) 
	{
	case 0:
		LOG("�����λ0�Ĳ�ʱ");
		m_tSeat0Step.Clean();
		break;
	case 1:
		LOG("�����λ0�Ķ���");
		m_tSeat0Last.Clean();
		break;
	case 2:
		LOG("�����λ1�Ĳ�ʱ");
		m_tSeat1Step.Clean();
		break;
	case 3:
		LOG("�����λ1�Ķ���");
		m_tSeat1Last.Clean();
		break;
	}
}

//################################################################################
// Ҫ��ͻ��˰���ָ��ʱ�����ÿ�ʼ׼�� 2004-2-6

void CXQServer::SendTimeSet()
{
	LOG("�������ļ��ж�ȡʱ������\n");
	
	GAME_CMD_DATA data;
	data.cCmdID			= SID_GET_READY_BY_TIME;
	data.cChair			= -1;
	data.nDataLen		= sizeof(BoardTimeSet);
	BoardTimeSet* pData = (BoardTimeSet*) data.data;
	memset(pData, 0, sizeof(BoardTimeSet));
	
	m_nRoundTime = m_ServerConfig.RoomSetting.nRoundTime;
	m_nStepTime  = m_ServerConfig.RoomSetting.nStepTime;
	m_nLastTime  = m_ServerConfig.RoomSetting.nLastTime;

	// ����Ѳ�ʱ�Ͷ����趨Ϊ����,��ʾ������
	if(m_nStepTime < 0) m_nStepTime = m_nRoundTime + 1;
	if(m_nLastTime < 0 ) m_nLastTime = 0;

	pData->wMins     = m_nRoundTime / 60;
	pData->wSecs     = m_nRoundTime % 60;
	pData->wStepMins = m_nStepTime / 60;
	pData->wStepSecs = m_nStepTime % 60;
	pData->wLastMin  = m_nLastTime / 60;
	pData->wLastSec  = m_nLastTime % 60;

	// glacier 2009-12-8 remedy
	// pData->unBaseMoney = m_GuessSvr.GetBaseMoney();
	pData->unBaseMoney = 0;
	// remedy end

	SendTheGameData((char *)&data, offsetof(GAME_CMD_DATA, data) + sizeof(BoardTimeSet));

	OnTimeSetFinished();
}

//################################################################################
// Ԥ�������ʱ������ 2004-2-6

void CXQServer::OnTimeSetFinished()
{
	m_nMainState = STATE_PLAYING;
	
	StarGameTime(); // ͬ��ʱ�����ã���ʼ��ʱ
	m_bSetTimeState = FALSE;
}

//################################################################################


//*********************************************************************
// ����������ֵĺ��� Living 2004-10-12
//
// ����˵�� : bDogFall		�Ƿ�;�
//            nWinnerSeat	����Ǻ;�,�������ָ��ʤ�����ڵ�Seat(0/1)
//*********************************************************************

void CXQServer::CountChessScore(bool bDogFall, int nWinnerSeat, BOOL bEscape)
{
	CPlayerInfo* pPlayer0 = m_PlayerList.GetPlayerInfo(0);
	CPlayerInfo* pPlayer1 = m_PlayerList.GetPlayerInfo(1);

	int nChair0Score = GetPlayerScoreByChair(0);
	int nChair1Score = GetPlayerScoreByChair(1);
	
	// ����CountScore��nWinner����
	// nWinner �� 1 2 �ֱ�� nWinnerSeat 0 1 ��Ӧ
	// nWinner = 0 ���ʾ�;�

	int nChair0Add = 0;
	int nChair1Add = 0;

	// ���ݹ�����м���, ����� nChair0Add �� nChair1Add �ֱ���
	// chair0 �� chair1 ��Ҫ���ϵķ���(����Ϊ����)

	CScaleScore ss;
	ss.SetOrgScore(nChair0Score, nChair1Score);
	ss.SetFirstHand(m_nRedSide);

	if(bEscape)
	{
		int nEscaper = (nWinnerSeat == 0) ? 1 : 0;
		ss.PlayEscape(nEscaper);
	}
	else if(bDogFall)
	{
		ss.PlayDogfall();
	}
	else if(0 == nWinnerSeat||1 == nWinnerSeat)
	{
		ss.PlayWin(nWinnerSeat);
	}

	nChair0Add = ss.GetScore(0);
	nChair1Add = ss.GetScore(1);

	// ����ʤ����Ϸ�Һ͸�����Ϸ��
	int nWinMoney = 0;
	int nLostMoney = 0;
	
	if(0 != m_ServerConfig.RoomSetting.nIsGambleRoom)
	{
		nWinMoney  = bEscape ? 0 : m_ServerConfig.RoomSetting.nWinChip;
		nLostMoney = bEscape ? - m_ServerConfig.RoomSetting.nEscapeChip
						: -m_ServerConfig.RoomSetting.nWinChip;
	}

	// ����ÿ����ҵķ�������Ϸ��
	int nM0 = 0, nM1 = 0;

	if(bEscape && 0 == nWinnerSeat)
	{
		m_score[0].SetWin(nChair0Add, nWinMoney);
		m_score[1].SetEscape(nChair1Add, nLostMoney);
		nM0 = nWinMoney; nM1 = nLostMoney;
	}
	else if(bEscape && 1 == nWinnerSeat)
	{
		m_score[0].SetEscape(nChair0Add, nLostMoney);
		m_score[1].SetWin(nChair1Add, nWinMoney);
		nM1 = nWinMoney; nM0 = nLostMoney;
	}
	else if(bDogFall)
	{
		m_score[0].SetPeace(nChair0Add, 0);
		m_score[1].SetPeace(nChair1Add, 0);
		nM0 = 0; nM1 = 0;
	}
	else if( (!bEscape) && 0 == nWinnerSeat)
	{
		m_score[0].SetWin(nChair0Add, nWinMoney);
		m_score[1].SetFail(nChair1Add, nLostMoney);
		nM0 = nWinMoney; nM1 = nLostMoney;
	}
	else if( (!bEscape) && 1 == nWinnerSeat)
	{
		m_score[0].SetFail(nChair0Add, nLostMoney);
		m_score[1].SetWin(nChair1Add, nWinMoney);
		nM1 = nWinMoney; nM0 = nLostMoney;
	}


	LOG("============================================\n");
	LOG("| ��ֽ������з������� CountChessScore\n");
	if(bEscape)
	{
		LOG("| �û����ܵ�����Ϸ����, ������:%u\n",
			nWinnerSeat == 0 ? pPlayer1->m_nUIN : pPlayer0->m_nUIN);
	}else if(bDogFall)
	{
		LOG("| ����Ϊ�;�\n");
	}else
	{
		LOG("| ʤ��Ϊ : ��λ %d\n", nWinnerSeat);
	}
	LOG("| ��λ0:UIN=%u ԭ������=%d ���ֵ÷�=%d ��Ϸ��=%d\n", 
		pPlayer0->m_nUIN, nChair0Score, nChair0Add, nM0);
	LOG("| ��λ1:UIN=%u ԭ������=%d ���ֵ÷�=%d ��Ϸ��=%d\n", 
		pPlayer1->m_nUIN, nChair1Score, nChair1Add, nM1);
	LOG("============================================\n");
}

int CXQServer::GetPlayerScoreByChair(int nChair)
{
	int				nPlayerID	= -1;
	CPlayerInfo*	pPlayerInfo = NULL;
		
	pPlayerInfo = m_PlayerList.GetPlayerInfo(nChair);

	if(!pPlayerInfo)
		return 0;
	
	nPlayerID = pPlayerInfo->nUserID;

	USER_SCORE score;
	memset(&score, 0, sizeof(USER_SCORE));
	m_pMainServer->GetPlayerScore(nPlayerID, (int*)&score);

	return score.lUserScore;
}

// ����û��Ƿ��һ�ν���
BOOL CXQServer::IsNewUser(short sPlayerID,unsigned int puin)
{
	int  nInitFlag  = 1;
	int  nFlagLen   = 1;
	BOOL bIsNewUser = FALSE;
	
	
	
	if(m_pMainServer->GetGameDBCID
		(sPlayerID, 0, &nInitFlag, nFlagLen)==0)
	{
		ERRLOG("m_pMainServer->GetGameDBCID::Return False__sPlayerID=%d,sPlayerUin=%u",sPlayerID,puin);
	}
	
	LOG("DBCID = %d\n", nInitFlag);
	
	if(0 == nInitFlag){
		bIsNewUser = TRUE;
	}else{
		bIsNewUser = FALSE;
	}
	
	return bIsNewUser;
}

BOOL CXQServer::WriteInitScore(short sPlayerID)
{
	BOOL bSuccSet = FALSE;

	USER_SCORE stUserScore;
	memset(&stUserScore, 0, sizeof(USER_SCORE));
	m_pMainServer->GetPlayerScore(sPlayerID, (int*)&stUserScore);

	LOG("ԭ������Ϊ:%d\n", stUserScore.lUserScore);

	long lUserOldScore = stUserScore.lUserScore;
	// ���ϴ˷�����, ���ֱ�Ϊ INIT_USER_SCORE

	// ���÷���Ϊ1300��
	memset(&stUserScore, 0, sizeof(USER_SCORE));
	stUserScore.lUserScore = INIT_USER_SCORE;

	// ���� SetGameScore ��, stUserScore �оͰ��������»���
	m_pMainServer->SetGameScore(sPlayerID, sizeof(USER_SCORE), 
		&stUserScore);

	m_pMainServer->GetPlayerScore(sPlayerID, (int*)&stUserScore);
	
	if((stUserScore.lUserScore - lUserOldScore) > INIT_USER_SCORE)
	{
		// ������ʹ����˫�����ֿ�, ���³�ʼ��������
		// �����ʼ��������, �ټ�ȥ���ߵķ���

		LOG("�û�����ʹ����˫�����ֿ�, ���ֱ�Ϊ%d\n", stUserScore.lUserScore);
		memset(&stUserScore, 0, sizeof(USER_SCORE));
		stUserScore.lUserScore = -INIT_USER_SCORE;
		m_pMainServer->SetGameScore(sPlayerID, sizeof(USER_SCORE), 
			&stUserScore);

		m_pMainServer->GetPlayerScore(sPlayerID, (int*)&stUserScore);
	}

	LOG("�������ú�Ϊ:%d\n", stUserScore.lUserScore);

	// ������Ƿ����óɹ���
	if((stUserScore.lUserScore - lUserOldScore) == INIT_USER_SCORE)
	{
		bSuccSet = TRUE;
	}

	return bSuccSet;
}

BOOL CXQServer::SetAsOldUser(short sPlayerID,unsigned int nUIN)
{
	int nEnterd = 1;

	LOG("�Ѹ��û�����Ϊ���û�\n");

	m_pMainServer->SetGameDBCID
		(sPlayerID, nUIN, mod_set, TRUE, 
		0, &nEnterd, sizeof(int));

	return TRUE;
}

void CXQServer::InitPlayerScore(TABLE_USER_INFO* pUser)
{
	short        sPlayerID = pUser->m_nPlayerID;
	unsigned int nUIN      = pUser->m_iUin;

	LOG("���ڼ�� PlayerID:%d UIN:%u ������\n",
		sPlayerID, nUIN);

	if(IsNewUser(sPlayerID,nUIN))
	{
		if(WriteInitScore(sPlayerID))
		{
			if(SetAsOldUser(sPlayerID, nUIN))
			{
				ShowMsg(sPlayerID, 
					"���ã���������һ�ν���QQ�й����壬"
					"���ĳ�ʼ����Ϊ1300�֡�");
			}
		}
	}
}

// 2.3 ����, �������û����͵�ǰ��ҵ�״̬

void CXQServer::SendPlayerStages()
{
	GAME_CMD_DATA data;
	data.cCmdID			= SID_PLAYER_STAGE;
	data.cChair			= -1;
	data.nDataLen		= sizeof(PlayerStageSet);
	PlayerStageSet* pData = (PlayerStageSet*) data.data;
	memset(pData, 0, sizeof(PlayerStageSet));
	
	pData->nChair0Stage = m_PlayerList.m_player[0].stage;
	pData->nChair1Stage = m_PlayerList.m_player[1].stage;

	SendTheGameData((char *)&data, 
		offsetof(GAME_CMD_DATA, data) + sizeof(PlayerStageSet));
}

// �������û����͵�ǰ��ҵ��Ѿ�����Ĵ���
void CXQServer::SendPlayerRegretTimes()
{
	GAME_CMD_DATA data;
	data.cCmdID			= SID_NOTIFY_REGRET_TIMES;
	data.cChair			= -1;
	data.nDataLen		= sizeof(PlayerRegretTimes);
	PlayerRegretTimes* pData = (PlayerRegretTimes*) data.data;
	memset(pData, 0, sizeof(PlayerRegretTimes));
	
	pData->nChair0Times = m_PlayerList.m_player[0].GetRegretTimes();
	pData->nChair1Times = m_PlayerList.m_player[1].GetRegretTimes();
	LOG("in SendPlayerRegretTimes.times0=%d,times1=%d\n", pData->nChair0Times, pData->nChair1Times);

	SendTheGameData((char *)&data, 
		offsetof(GAME_CMD_DATA, data) + sizeof(PlayerRegretTimes));
}

void CXQServer::KickOfflineUsers()
{
	LOG("KickOfflineUsers\n");

	for(int i=0; i<2; i++)
	{
		if(m_PlayerList.m_player[i].bIsOffline)
		{
			m_pMainServer->KickUserFromGame(m_PlayerList.m_player[i].nUserID);
			LOG("%u is offline\n", m_PlayerList.m_player[i].m_nUIN);
		}
	}
}

int CXQServer::SetGameScoreEx(short nPlayerID, unsigned int iUin, short nScoreBufLen, void * pScoreBuf)
{
	if (!IsRankEvaluationRoom())
	{
		if(m_ServerConfig.m_bIsFriendVS == false)
			return m_pMainServer->SetGameScoreEx(nPlayerID, iUin, nScoreBufLen, pScoreBuf);
		else
			return 0;
	}
	return 0;
}

int CXQServer::SetGameScore(short nPlayerID, short nScoreBufLen, void * pScoreBuf)
{
	if (!IsRankEvaluationRoom())
	{
		return m_pMainServer->SetGameScore(nPlayerID, nScoreBufLen, pScoreBuf);
	}
	return 0;
}

void CXQServer::SendLuxuryVipInfo(int nPlayerID)
{
	GAME_CMD_DATA data;
	data.cCmdID			= SID_NOTIFY_LUXURYVIP_INFO;
	data.cChair			= -1;
	data.nDataLen		= sizeof(MSG_NOTIFY_LUXURYVIP_INFO);
	MSG_NOTIFY_LUXURYVIP_INFO* pData = (MSG_NOTIFY_LUXURYVIP_INFO*)data.data;
	memset(pData, 0, sizeof(MSG_NOTIFY_LUXURYVIP_INFO));
	pData->nEnterTime = time(NULL);
	pData->nUrlCount = m_ServerConfig.m_nLuxuryVipInfoURLsCount;
	for(int i = 0; i < m_ServerConfig.m_nLuxuryVipInfoURLsCount; i++)
	{
		strncpy(pData->szUrls[i], m_ServerConfig.m_szLuxuryVipInfoURLs[i], sizeof(pData->szUrls[i]) - 1);
	}

	SendTheGameDataTo(nPlayerID, (char *)&data, offsetof(GAME_CMD_DATA, data) + sizeof(MSG_NOTIFY_LUXURYVIP_INFO));
}

#define  MAX_FILE_LEN     512
//pSaveFileName ֻ���� path/fileName��������path
BOOL CXQServer::CreatePath(char* pPath)
{
	printf("CreatePath : %s\n", pPath);
	if ((NULL == pPath)
		|| (strlen(pPath) <= 0))
	{
		return FALSE;
	}
	
	//add by brady ȥ���ļ���
	
	char szPath[MAX_FILE_LEN] = {0};
	strncpy(szPath, pPath, MAX_FILE_LEN);
	
	int iTempLen = strlen(szPath);
	char* pFileName = NULL;
	char* p1 = szPath;
	char* pEnd = szPath + (iTempLen - 1);
	while(1)
	{
		p1 = strchr(p1, '/');
		
		if (p1 != NULL)
		{
			pFileName = p1;
		}
		
		if ((NULL == p1)
			|| (p1 == pEnd))
		{
			break;
		}
		
		++p1;
	}
	
	if (NULL == pFileName)
	{
		return FALSE;
	}
	
	*pFileName = 0;
	if ((0 == strncmp("..", szPath, MAX_FILE_LEN)) 
		|| (0 == strncmp(".", szPath, MAX_FILE_LEN)))
	{
		return FALSE;
	}
	
	//add end
	
	if('/' == szPath[iTempLen - 1])
	{
        szPath[iTempLen - 1] = 0;
	}
	char *pTemp = szPath;
	char *pTemp1;
	char chTemp;
	while(1)
	{
		pTemp1 = strchr(pTemp, '/');
		if(0 == pTemp1)
		{
#ifdef WIN32
			mkdir(szPath);
#else
			mkdir(szPath, 0777);
#endif
			break;
		}
		if(0 == *(pTemp1 + 1))
		{
			break;
		}
		
		chTemp = *(pTemp1 + 1);
		*(pTemp1 + 1) = 0;
		if (0 != strcmp("../", szPath) && 0 != strcmp("./", szPath))
		{
#ifdef WIN32
			mkdir(szPath);
#else
			mkdir(szPath, 0777);
#endif
		}
		*(pTemp1 + 1) = chTemp;
		pTemp = pTemp1 + 1;
	}
	
	return TRUE;
}

#define ADD_INT_TO_SAVE(nValue)\
	memset(sTemp, 0, sizeof(sTemp));\
	_snprintf(sTemp, sizeof(sTemp)-1, "%d ", nValue);\
	strncat(szSaveGameBuf, sTemp, sizeof(szSaveGameBuf)-1)

#define FUPAN_SUFFIX_NAME ".che"

BOOL CXQServer::SaveRoundRecord()
{
	printf("CXQServer::SaveRoundRecord\n");
	if (!m_pMainServer)
	{
		return FALSE;
	}

	char szSaveFileName[MAX_FILE_LEN] = {0};
	short shMaxLen = MAX_FILE_LEN - 1;

#ifndef WIN32
	if (!m_pMainServer->IsNeedSaveGameDataToLocal())
	{
		printf("IsNeedSaveGameDataToLocal FALSE\n");
		return FALSE;
	}
	
	//����ֵ��0��������-1��pPathΪ�գ�-2�����Ȳ�����
	if ((0 != m_pMainServer->GetSavePlayPath(szSaveFileName, shMaxLen))
		|| (shMaxLen <= 0)
		|| (strlen(szSaveFileName) <= 0))
	{
		printf("GetSavePlayPath FALSE\n");
		return FALSE;
	}
	
	if ((strlen(szSaveFileName) + strlen(FUPAN_SUFFIX_NAME)) > (MAX_FILE_LEN - 1))
	{
		printf("SaveFileName too long\n");
		return FALSE;
	}
	
	strncat(szSaveFileName, FUPAN_SUFFIX_NAME, sizeof(szSaveFileName)-1);
#else
	_snprintf(szSaveFileName, sizeof(szSaveFileName), "D:\\������So�Ĵ���.che");
#endif

	printf("SaveFileName : %s\n", szSaveFileName);
	FILE* fp = fopen(szSaveFileName, "wb");
	/*���ļ�ʧ�ܣ��򴴽�Ŀ¼����ֹ����ΪĿ¼�����ڶ�ʹ���ļ�ʧ�ܡ�*/
	if((fp==NULL)
		&& CreatePath(szSaveFileName))
	{	
		fp = fopen(szSaveFileName, "wb");
		if (NULL == fp)
		{
			printf("fopen failed!\n");
			return FALSE;
		}
	}
	
	char szSaveGameBuf[MAX_RECV_LEN] = {0};
	int nVer  = 1;
	int nSize = m_StepList.GetSize();
	char sTemp[16];

	ADD_INT_TO_SAVE(nVer);
	ADD_INT_TO_SAVE(nSize);
	
	int i;
	MOVE_RESULT_EX moveResultEx;
	int nRoundSide;
	for(i = 0; i < nSize; ++i)
	{
		moveResultEx = m_StepList.GetData(i);
		// �ߵ��ĸ�����
		ADD_INT_TO_SAVE(moveResultEx.chess);
		// ��һ���ĳ���
		ADD_INT_TO_SAVE(32/*ccNULL*/);
		// �ı��ߵ���
		if(moveResultEx.chess <= 15/*ccABing5*/)
		{
			nRoundSide = 0/*rsASide*/;
		}
		else
		{
			nRoundSide = 1/*rsBSide*/;
		}
		ADD_INT_TO_SAVE(nRoundSide);
		// ����λ��
		ADD_INT_TO_SAVE(moveResultEx.y-1);
		ADD_INT_TO_SAVE(moveResultEx.x-1);
		// �յ��λ��
		ADD_INT_TO_SAVE(moveResultEx.yTo-1);
		ADD_INT_TO_SAVE(moveResultEx.xTo-1);
		// �ƶ�����ɵľ���
		ADD_INT_TO_SAVE(0);
		// �ڼ�����1��ʼ
		ADD_INT_TO_SAVE(i+1);
		// �����ִ��ĳ���
		ADD_INT_TO_SAVE(0);
	}
	fwrite(szSaveGameBuf, 1, strlen(szSaveGameBuf), fp);
	fclose(fp);
	return TRUE;
}

#define MAX_SYNCDATA_LEN	2048

#define RECODE_MSG(msg)\
	nMsgLen = msg.nDataLen + offsetof(GAME_CMD_DATA, data);\
	shDataLen += nMsgLen;\
	if (shDataLen > MAX_SYNCDATA_LEN)\
	{\
		ERRLOG("SyncData is too large more than %d!!!\n", MAX_SYNCDATA_LEN);\
		return 0;\
	}\
	memcpy(pDataPos, &msg, nMsgLen);\
	pDataPos += nMsgLen

int CXQServer::SendTheLookOnSyncGameData()
{
	printf("SendTheLookOnSyncGameData\n");
	if (!m_ServerConfig.RoomSetting.bSupportCapacityLookOn)
	{
		return 0;
	}
	printf("SendTheLookOnSyncGameData2\n");
	short shDataLen = 0;
	char acSyncData[MAX_SYNCDATA_LEN] = {0};
	int nCurrentLen = 0;
	int nMsgLen;
	char * pDataPos = acSyncData;

//	void CXQServer::SendPlayerStages()
	{
		GAME_CMD_DATA data;
		data.cCmdID			= SID_PLAYER_STAGE;
		data.cChair			= -1;
		data.nDataLen		= sizeof(PlayerStageSet);
		PlayerStageSet* pData = (PlayerStageSet*) data.data;
		memset(pData, 0, sizeof(PlayerStageSet));
		
		pData->nChair0Stage = m_PlayerList.m_player[0].stage;
		pData->nChair1Stage = m_PlayerList.m_player[1].stage;
		
		RECODE_MSG(data);
// 		SendTheGameData((char *)&data, 
// 			offsetof(GAME_CMD_DATA, data) + sizeof(PlayerStageSet));
	}

//	BOOL CXQServer::SendGameContext(short nPlayerID, int nChair, int nChairToShowChess)
	{
		GAME_CMD_DATA data(-1,SID_GAME_CONTEXT);
		
		GAME_CONTEXT_DATA gamedata;
		gamedata.cCurOrder = m_nCurOrder;
		
		//��m_game�л�ȡ��������
		memcpy(gamedata.achessman, m_game.m_iChessmanMap, 132*sizeof(int));
		memcpy(gamedata.pointChessman, m_game.m_pointChessman, 32*sizeof(POINT));
		gamedata.pointBoxFrom = m_game.m_pointBoxFrom;
		gamedata.pointBoxTo   = m_game.m_pointBoxTo;
		gamedata.iSide        = m_game.m_iSide;
		
		memcpy(&(gamedata.context), &m_SaveGameContext, sizeof(GAME_CONTEXT));
		data.SetData(&gamedata, sizeof(GAME_CONTEXT_DATA));
		RECODE_MSG(data);
//		SendTheGameDataTo(nPlayerID, (char *)&data, offsetof(GAME_CMD_DATA,data) + sizeof(GAME_CONTEXT_DATA));

//		BOOL CXQServer::SendStepList(short nPlayerID)
		{
			GAME_CMD_DATA cmd_data(-1, SID_MOVE_RECORD);
			
			int nSize  = m_StepList.GetSize();
			int nTimes = ((nSize - 1) / RECORD_COUNT) + 1;
			int nCount = 0;
			
			MOVE_RECORD move_record;
			
			for(int i=0; i<nTimes; i++)
			{
				nCount = nSize - RECORD_COUNT * i;
				nCount = nCount < RECORD_COUNT?nCount:RECORD_COUNT;
				move_record.nStepCount = nCount;
				LOG("����:���͵�%d�μ�¼,����%d��\n", i, move_record.nStepCount);
				for(int k=0; k<nCount; k++)
				{
					move_record.MoveResult[k] = m_StepList.GetData(RECORD_COUNT * i + k);
				}
				cmd_data.SetData(&move_record, sizeof(MOVE_RECORD));
				RECODE_MSG(cmd_data);
//				memcpy(cmd_data.data, &move_record, sizeof(MOVE_RECORD));
//				SendTheGameDataTo(nPlayerID, (char *)&cmd_data, offsetof(GAME_CMD_DATA, data) + sizeof(MOVE_RECORD));
			}
		}
		
//		void CXQServer::UpdateTime()
		{
			TimeUpdate tu;
			memset(&tu, 0, sizeof(TimeUpdate));
			
			tu.nTotal0 = m_tSeat0Total.GetTickCount();
			tu.nTotal1 = m_tSeat1Total.GetTickCount();
			
			tu.nSeat0  = m_tSeat0Step.GetTickCount();
			tu.nSeat1  = m_tSeat1Step.GetTickCount();
			
			tu.nLast0  = m_tSeat0Last.GetTickCount();
			tu.nLast1  = m_tSeat1Last.GetTickCount();
			
			tu.nRoundTime = m_nRoundTime;
			tu.nStepTime  = m_nStepTime;
			tu.nLastTime  = m_nLastTime;
			
			
			if(m_bStopCounting)
				tu.nCountCur = -1;
			else
				tu.nCountCur = m_nCountCur;
			
			GAME_CMD_DATA data(0, SID_UPDATE_TIME);
			data.SetData(&tu, sizeof(TimeUpdate));
			
			RECODE_MSG(data);
//			SendTheGameData((char *)&data, offsetof(GAME_CMD_DATA,data) + sizeof(TimeUpdate));
		}
	}

	//////////////////////////////////////////////////////////////////////////
	{
		GAME_CMD_DATA data;
		data.cCmdID = SID_ROOM_TYPE;
		data.cChair = -1;
		data.nDataLen = sizeof(GAME_ROOM_TYPE);
		GAME_ROOM_TYPE *pRoomType = (GAME_ROOM_TYPE*)data.data;
		
		if (IsTestRoom())
		{
			pRoomType->bTestRoom = true;
		}
		else
		{
			pRoomType->bTestRoom = false;
		}
		RECODE_MSG(data);
		// 	SendTheGameData((char *)&data, 
		// 		offsetof(GAME_CMD_DATA,data) + sizeof(GAME_ROOM_TYPE));
	}

	short shSeatID[MAX_TABLE_PLAYER];
	shSeatID[0] = 0;
	shSeatID[1] = 1;
	printf("SendLookOnGameData %d\n", shDataLen);
 	return m_pMainServer->SendLookOnGameData(shSeatID, MAX_TABLE_PLAYER, 0, shDataLen, acSyncData);
}

int CXQServer::SendTheGameData(char * pcGameData, short nDataLen, unsigned int uiFlag )
{
	if (m_ServerConfig.RoomSetting.bSupportCapacityLookOn)
	{
		short shSeatID[MAX_TABLE_PLAYER] = {0};
		short shSeatCount = 0;
		for (int i=0; i<MAX_TABLE_PLAYER; ++i)
		{
			if (INVALID_USER_ID != m_PlayerList.m_player[i].nUserID)
			{
				shSeatID[shSeatCount++] = i;
			}
		}
		if (shSeatCount > 0)
		{
			m_pMainServer->SendLookOnGameData(shSeatID, shSeatCount, 1, nDataLen, pcGameData, uiFlag);
		}
	}
	return m_pMainServer->SendGameData(pcGameData , nDataLen , uiFlag);
}

int  CXQServer::SendTheGameDataTo(short nPlayerID,char* pcGameData, short nDataLen, unsigned int uiFlag )
{
	if (m_ServerConfig.RoomSetting.bSupportCapacityLookOn)
	{
		short shSeatID;
		for (int i=0; i<MAX_TABLE_PLAYER; ++i)
		{
			if (nPlayerID == m_PlayerList.m_player[i].nUserID)
			{
				shSeatID = i;
				m_pMainServer->SendLookOnGameData(&shSeatID, 1, 1, nDataLen, pcGameData, uiFlag);
				break;
			}
		}
	}
	return m_pMainServer->SendGameDataTo(nPlayerID , pcGameData , nDataLen , uiFlag);
}

int  CXQServer::SendTheGameDataExcept(short nPlayerID,char* pcGameData, short nDataLen, unsigned int uiFlag)
{
	if (m_ServerConfig.RoomSetting.bSupportCapacityLookOn)
	{
		short shSeatID[MAX_TABLE_PLAYER] = {0};
		short shSeatCount = 0;
		for (int i=0; i<MAX_TABLE_PLAYER; ++i)
		{
			if (INVALID_USER_ID != m_PlayerList.m_player[i].nUserID 
				&& nPlayerID != m_PlayerList.m_player[i].nUserID)
			{
				shSeatID[shSeatCount++] = i;
			}
		}
		if (shSeatCount > 0)
		{
			m_pMainServer->SendLookOnGameData(shSeatID, shSeatCount, 1, nDataLen, pcGameData, uiFlag);
		}
	}
	return m_pMainServer->SendGameDataExcept(nPlayerID , pcGameData , nDataLen , uiFlag);
}

int CXQServer::SendTheGameDataToSeat(short nSeatID, char* pcGameData, short nDataLen, unsigned int uiFlag )
{
	if (m_ServerConfig.RoomSetting.bSupportCapacityLookOn)
	{
		short shSeatID = nSeatID;
		m_pMainServer->SendLookOnGameData(&shSeatID, 1, 1, nDataLen, pcGameData, uiFlag);
	}
	return m_pMainServer->SendGameDataToSeat(nSeatID , pcGameData , nDataLen , uiFlag);
}

int CXQServer::SendTheGameDataExceptSeat(short nSeatID, char* pcGameData, short nDataLen, unsigned int uiFlag)
{
	if (m_ServerConfig.RoomSetting.bSupportCapacityLookOn)
	{
		short shSeatID[MAX_TABLE_PLAYER] = {0};
		short shSeatCount = 0;
		for (int i=0; i<MAX_TABLE_PLAYER; ++i)
		{
			if (INVALID_USER_ID != m_PlayerList.m_player[i].nUserID 
				&& nSeatID != i)
			{
				shSeatID[shSeatCount++] = i;
			}
		}
		if (shSeatCount > 0)
		{
			m_pMainServer->SendLookOnGameData(shSeatID, shSeatCount, 1, nDataLen, pcGameData, uiFlag);
		}
	}
	return m_pMainServer->SendGameDataExceptSeat(nSeatID , pcGameData , nDataLen , uiFlag);
}

int CXQServer::SendTheGameDataToLookOnUsers(int nChair,char* pcGameData, short nDataLen, unsigned int uiFlag)
{
	if (m_ServerConfig.RoomSetting.bSupportCapacityLookOn)
	{
		short shSeatID = nChair;
		m_pMainServer->SendLookOnGameData(&shSeatID, 1, 1, nDataLen, pcGameData, uiFlag);
	}
	return m_pMainServer->SendGameDataToLookOnUsers(nChair , pcGameData , nDataLen , uiFlag);
}

ENM_CL_RET CXQServer::SoPackGameMsgHeader( BYTE *pMsg, UINT unGameMsgID, UINT unMsgLen )
{
    static int nHeadLen = offsetof(GAME_CMD_DATA, data);
    if ((NULL == pMsg) || (unMsgLen < nHeadLen))
    {
        return clret_wrong_para;
    }
    GAME_CMD_DATA *pGameMsg = (GAME_CMD_DATA*)pMsg;
    pGameMsg->cCmdID = unGameMsgID;
    pGameMsg->cChair = -1;
    pGameMsg->nDataLen = unMsgLen - nHeadLen;
    return clret_succ;
}

ENM_CL_RET CXQServer::OnCLCallComm( CL_SO_PARAM &kPara, void *pRet, int nRetLen )
{
    ENM_CL_RET eRet = clret_unhandled;
    switch (kPara.unSubParamID)
    {
    case so_common_cl2g_getuserinfo_byid:
        {
            PREPAR_INPARA(kPara, TSOPARA_COMMON_CL2G_GETUSERINFO_BYID);
            PREPAR_OUTPARA(pRet, nRetLen, TABLE_USER_INFO);
            CPlayerInfo *pPlayerInfo = m_PlayerList.GetPlayerByPlayerID(kInPara.sPlayerID);
            if (NULL == pPlayerInfo)
            {
                return clret_fail;
            }
            pPlayerInfo->FillTableUserInfo(kOutPara);
            eRet = clret_succ;
        }
        break;
    case so_common_cl2g_getuserinfo_bychair:
        {
            PREPAR_INPARA(kPara, TSOPARA_COMMON_CL2G_GETUSERINFO_BYCHAIR);
            PREPAR_OUTPARA(pRet, nRetLen, TABLE_USER_INFO);
            CPlayerInfo *pPlayerInfo = m_PlayerList.GetPlayerInfo(kInPara.cChair);
            if (NULL == pPlayerInfo)
            {
                return clret_fail;
            }
            pPlayerInfo->FillTableUserInfo(kOutPara);
            eRet = clret_succ;
        }
        break;
    default:
        break;
    }

    return eRet;
}

ENM_CL_RET CXQServer::OnCLCallLogicBlueVip( CL_SO_PARAM &kPara, void *pRet, int nRetLen )
{
    return clret_unhandled;
}

ENM_CL_RET MY_NAMESPACE::CXQServer::SoCommLogicCallGame( CL_SO_PARAM &kPara, void *pRet /*= NULL*/, int nRetLen /*= 0*/ )
{
    switch (kPara.byParamID)
    {
    case SOCLPID_COMMON:
        return OnCLCallComm(kPara, pRet, nRetLen);
    case SOCLPID_BLUEVIP:
        return OnCLCallLogicBlueVip(kPara, pRet, nRetLen);
    }
    return clret_unhandled;
}

BOOL CXQServer::RecvReqChangeEffect(short nPlayerID, int nChair, LPCSTR pBuf, int nLen)
{
	if (NULL == m_pMainServer)
	{
		return FALSE;
	}

	if (NULL == pBuf)
	{
		LOG("pBuf is NULL.");
		return FALSE;
	}

	int nSize = sizeof(REQ_CHANGE_EFFECT);
	if (nLen < nSize)
	{
		LOG("Error: REQ_CHANGE_EFFECT ���ݳ��� %d < %d\n",nLen,nSize);
		return FALSE;
	}
	REQ_CHANGE_EFFECT *pData = (REQ_CHANGE_EFFECT*)pBuf;
	CPlayerInfo *pPlayer = m_PlayerList.GetPlayerInfo(nChair);

	if ((NULL == pPlayer) || (pPlayer->m_nUIN != pData->unUin))
	{
		return FALSE;
	}
	
	GAME_CMD_DATA cmd;
	cmd.cCmdID = SID_ANSWER_CHANGE_EFFECT;
	cmd.cChair = nChair;
	cmd.nDataLen = sizeof(ANSWER_CHANGE_EFFECT);
	ANSWER_CHANGE_EFFECT *pAnswer = (ANSWER_CHANGE_EFFECT*)cmd.data;
	pAnswer->unUin = pData->unUin;
	if (pPlayer->dwRightLevel & PLAYER_IDENTTITY_PLAYER_GVIP)
	{
		// ������ң���������
		pAnswer->nResult = 0;
		pAnswer->nPanelNo = pData->nPanelNo;
		pAnswer->nEffectNo = pData->nEffectNo;
		pPlayer->unChessMoveAni = pData->nEffectNo;
	}
	else
	{
		// ��������ң�����ʧ��
		pAnswer->nResult = 1;
		pAnswer->nPanelNo = pData->nPanelNo;
		pAnswer->nEffectNo = pData->nEffectNo;
		pPlayer->unChessMoveAni = 0;
	}
	SendTheGameData((char*)&cmd, offsetof(GAME_CMD_DATA, data) + sizeof(ANSWER_CHANGE_EFFECT));
	return TRUE;
}

void CXQServer::SendEffectSetting(int nPlayerID)
{
	if (NULL == m_pMainServer)
	{
		LOG("m_pMainServer is NULL.");
		return;
	}

	GAME_CMD_DATA cmd;
	cmd.cCmdID = SID_NOTIFY_EFFECT_SETTING;
	cmd.cChair = -1;
	cmd.nDataLen = sizeof(NOTIFY_EFFECT_SETTING);
	NOTIFY_EFFECT_SETTING *pData = (NOTIFY_EFFECT_SETTING*)cmd.data;

	for (int i = 0; i < MAX_TABLE_PLAYER; i++)
	{
		pData->unUin[i] = m_PlayerList.m_player[i].m_nUIN;
		pData->nEffectNo[i] = m_PlayerList.m_player[i].unChessMoveAni;
	}
	if (0 > nPlayerID)
	{
		SendTheGameData((char*)&cmd, offsetof(GAME_CMD_DATA, data) + sizeof(NOTIFY_EFFECT_SETTING) + 1, 0);
	}
	else
	{
		SendTheGameDataTo(nPlayerID, (char*)&cmd, offsetof(GAME_CMD_DATA, data) + sizeof(NOTIFY_EFFECT_SETTING) + 1, 0);
	}
}

BOOL CXQServer::RecvPrivliegeSet(short nPlayerID, int nChair, LPCSTR pBuf, int nLen)
{
	if (NULL == pBuf)
	{
		LOG("pBuf is NULL.");
		return FALSE;
	}

	int nSize = sizeof(MSG_PRIVILEGE_SET);
	if (nLen < nSize)
	{
		LOG("Error: MSG_PRIVILEGE_SET ���ݳ��� %d < %d\n",nLen,nSize);
		return FALSE;
	}

	MSG_PRIVILEGE_SET *pData = (MSG_PRIVILEGE_SET*)pBuf;
	CPlayerInfo* pPlayerInfo = m_PlayerList.GetPlayerInfo(nChair);
	if ((NULL == pPlayerInfo) || (pPlayerInfo->nUserID != nPlayerID))
	{
		return FALSE;
	}
	if (pPlayerInfo->dwRightLevel & PLAYER_IDENTTITY_PLAYER_GVIP)
	{
		pPlayerInfo->unChessMoveAni = pData->unChessMoveAni;
	}
	else 
	{
		pPlayerInfo->unChessMoveAni = 0;
	}
}

void CXQServer::SendSetTimeSetting(int nPlayerID)
{
	GAME_CMD_DATA cmd;
	cmd.cCmdID = SID_NOTIFY_SETTIME_SETTING;
	cmd.nDataLen = sizeof(NOTIFY_SETTIME_SETTING);
	NOTIFY_SETTIME_SETTING *pData = (NOTIFY_SETTIME_SETTING*)&cmd.data;
	BOOL bEnable = m_ServerConfig.m_bEnableVipFirstSetTime;
	
	if (m_PlayerList.m_nPlayerCount < 2)
	{
		bEnable = FALSE;
	}
	else
	{
		for (int i = 0; i < 2; i++)
		{
			bEnable = (bEnable && m_PlayerList.m_player[i].m_bSupportSetTime);		
		}
	}
	pData->bEnableVipFirstSetTime = bEnable;

	if (nPlayerID > 0)
	{
		SendTheGameDataTo(nPlayerID, (char*)&cmd,
			offsetof(GAME_CMD_DATA, data) + sizeof(NOTIFY_SETTIME_SETTING));
	}
	else
	{
		SendTheGameData((char*)&cmd, offsetof(GAME_CMD_DATA, data) + sizeof(NOTIFY_SETTIME_SETTING));
	}
}

BOOL CXQServer::RecvSupportVipSetTimeFirst(short nPlayerID, int nChair, LPCSTR pBuf, int nLen)
{
	if (NULL == pBuf)
	{
		LOG("Error: RecvSupportVipSetTimeFirst: pBuf is NULL.");
		return FALSE;
	}

	int nSize = sizeof(SUPPORT_SETTIME_SETTING);
	if (nLen < nSize)
	{
		LOG("Error: SUPPORT_SETTIME_SETTING ���ݳ��� %d < %d\n", nLen, nSize);
		return FALSE;
	}

	CPlayerInfo *pPlayerInfo = m_PlayerList.GetPlayerByPlayerID(nPlayerID);
	if (pPlayerInfo != NULL)
	{
		SUPPORT_SETTIME_SETTING *pData = (SUPPORT_SETTIME_SETTING*)pBuf;
		pPlayerInfo->m_bSupportSetTime = pData->bSupport;
	}
	return TRUE;
}

MY_NAMESPACE_END

