#include "StdAfx.h"
#include "ServerConfig.h"
#include "GlobalDefine.h"

MY_NAMESPACE_BEGIN

//###################################################################################

int			CServerConfig::m_iReadCfgTime = -1;		/*��ȡ�����ļ��Ĵ�����ʼ��Ϊ��1*/
CConfigFile CServerConfig::m_CfgFile;				/*��ȡ�����ļ���ʵ��*/        

//###################################################################################

CServerConfig::CServerConfig()
{
	m_nLogFlag          = 0;
	m_nErrLogFlag       = 0;
	m_szLogPath[0]      = 0;
    memset(&RoomSetting, 0, sizeof(RoomSetting));
}

//###################################################################################

CServerConfig::~CServerConfig()
{
}

//###################################################################################
// �� ʷ : 2004-02-09 ��һ����Ϸ��������ļ�,�޸�Ϊһ����Ϸһ���ļ�,�����
//###################################################################################

void CServerConfig::ReadCfgFile(const char* pszFileName, ISoCommLogic *pSoCL)
{
	// �Ѵ���������"../Log/XQServer/Normal" תΪ "Normal"(�����ļ�����Ľ�)

	PSTR pszCfgItem;
	pszCfgItem = strrchr(pszFileName, '/');
	if(NULL == pszCfgItem) 
		pszCfgItem = (PSTR)pszFileName;
	else
		pszCfgItem++;
	
	char szCfgFileName[260];
	memset(szCfgFileName, 0, 260);
	_snprintf(szCfgFileName, sizeof(szCfgFileName), "../config/%d_chnchess_%d.cfg", GameID, SERVER_VERSION);
	int iRet = m_CfgFile.OpenFile(szCfgFileName);
	// int iRet = m_CfgFile.OpenFile("../config/chnchess.cfg");  /*���ļ�*/
	if(0 != iRet)
	{
//        printf("Read file %s failed!\n",pszFileName);
		return;
	}

	ReadLuxuryVipInfo();
	
	m_CfgFile.GetItemValue(pszCfgItem, "LogFlag",       m_nLogFlag,       0);
	m_CfgFile.GetItemValue(pszCfgItem, "ErrLogFlag",    m_nErrLogFlag,    1);
	m_CfgFile.GetItemValue(pszCfgItem, "LogPath", m_szLogPath, sizeof(m_szLogPath), "../log/XQServer");

//	printf("***********************LogFlag : %d, ErrLogFlag : %d\n", m_nLogFlag, m_nErrLogFlag);
//	printf("************************LogPath : %s\n", m_szLogPath);

	m_CfgFile.GetItemValue(pszCfgItem, "MinPlayerScore", RoomSetting.nMinPlayerScore,   0);
	m_CfgFile.GetItemValue(pszCfgItem, "WinScore",		 RoomSetting.nWinScore, 1);
	m_CfgFile.GetItemValue(pszCfgItem, "EscapeScore",	 RoomSetting.nEscapeScore, 2);

	m_CfgFile.GetItemValue(pszCfgItem, "IsGambleRoom",	 RoomSetting.nIsGambleRoom, 0);	
	m_CfgFile.GetItemValue(pszCfgItem, "MinPlayerChip",	 RoomSetting.nMinPlayerChip, 0);	
	m_CfgFile.GetItemValue(pszCfgItem, "WinChip",		 RoomSetting.nWinChip, 0);	
	m_CfgFile.GetItemValue(pszCfgItem, "EscapeChip",	 RoomSetting.nEscapeChip, 0);
	m_CfgFile.GetItemValue(pszCfgItem, "GambleTax",		 RoomSetting.nGambleTax, 0);

	m_CfgFile.GetItemValue(pszCfgItem, "Preestablish",	 RoomSetting.nPreestablish, 0);
	m_CfgFile.GetItemValue(pszCfgItem, "RoundTime",		 RoomSetting.nRoundTime, 0);
	m_CfgFile.GetItemValue(pszCfgItem, "StepTime",		 RoomSetting.nStepTime, 0);
	m_CfgFile.GetItemValue(pszCfgItem, "LastTime",		 RoomSetting.nLastTime, 0);
	m_CfgFile.GetItemValue(pszCfgItem, "IsVS",		 RoomSetting.m_bIsFriendVS, 0);
	

	m_CfgFile.GetItemValue(pszCfgItem, "TGA", RoomSetting.nTGA, 0);

	m_CfgFile.GetItemValue(pszCfgItem, "bSupportCapacityLookOn", RoomSetting.bSupportCapacityLookOn , 0 );
	m_CfgFile.GetItemValue(pszCfgItem, "nSyncGameDataInterval", RoomSetting.nSyncGameDataInterval , 1000 );
	RoomSetting.nSyncGameDataInterval /= 1000;

    int nTmp = 0;
    m_CfgFile.GetItemValue(pszCfgItem, "RoomTypeEx", nTmp, game_room_normal );
    RoomSetting.eRoomStyle = (ENM_GAME_ROOM_TYPE)nTmp;

//////////////////////////////////////////////////////////////////////////
	m_CfgFile.GetItemValue("RankGame", "SameRankScoreVary",	m_nSameRankScoreVary, 10);
	m_CfgFile.GetItemValue("RankGame", "HighRankScoreWin",	m_nHighRankScoreWin, 5);
	m_CfgFile.GetItemValue("RankGame", "HighRankScoreLose", m_nHighRankScoreLose, 15);
	m_CfgFile.GetItemValue("RankGame", "LowRankScoreWin",   m_nLowRankScoreWin, 15);
	m_CfgFile.GetItemValue("RankGame", "LowRankScoreLose",	m_nLowRankScoreLose, 5);
//////////////////////////////////////////////////////////////////////////
	m_CfgFile.GetItemValue("BlueVip", "EnableVipFirstSetTime", m_bEnableVipFirstSetTime, 0);
    if (pSoCL)
    {
        pSoCL->LoadCfg(this, pszCfgItem);
    }
	
	m_CfgFile.CloseFile(); /*�ر��ļ�*/
	m_iReadCfgTime++; /*���Ӷ�ȡ�����ļ��Ĵ���*/

#ifdef _LOGIN_MAIN_
	m_nLogFlag = 0; /*�����ӡ��mainsvrd����־�У���m_nLogFlag �� 0*/
	if (0 == m_iReadCfgTime)
	{
        printf("�����ӡ��־��mainsvrd��һ��\n");
	}
#else
	if (0 == m_iReadCfgTime)
	{
        printf("���嵥����ӡ��־����mainsvrd�ķָ�����\n");
	}
#endif	
}

//###################################################################################

int CServerConfig::GetLogFlag() const
{
	return m_nLogFlag;
}

//###################################################################################

int CServerConfig::GetErrLogFlag() const
{
	return m_nErrLogFlag;
}

//###################################################################################

char *CServerConfig::GetLogPath()
{
	char *pLogPath = &m_szLogPath[0];
	return pLogPath;
}
//###################################################################################

void CServerConfig::ReadLuxuryVipInfo()
{
	m_nLuxuryVipInfoURLsCount = 0;
	memset(m_szLuxuryVipInfoURLs, 0, sizeof(m_szLuxuryVipInfoURLs));

	m_CfgFile.GetItemValue("LuxuryVipInfo", "nURLsCount" , m_nLuxuryVipInfoURLsCount, 0);

	if(m_nLuxuryVipInfoURLsCount > MAX_LUXURYVIP_URL_COUNT)
	{
		m_nLuxuryVipInfoURLsCount = MAX_LUXURYVIP_URL_COUNT;
	}

	char szName[24] = {0};
	int i = 0;
	for (i = 0; i < m_nLuxuryVipInfoURLsCount && i < MAX_LUXURYVIP_URL_COUNT; ++i)
	{
		_snprintf(szName, sizeof(szName), "URL%d", i);
		m_CfgFile.GetItemValue("LuxuryVipInfo", szName, m_szLuxuryVipInfoURLs[i], sizeof(m_szLuxuryVipInfoURLs[i]) - 1, "");
	}

}

int CServerConfig::GetInt( const char *pszSectionName, const char *pszKeyName, int lDefaultValue )
{
    int nRet = lDefaultValue;
    m_CfgFile.GetItemValue(pszSectionName, pszKeyName, nRet, lDefaultValue);
    return nRet;
}

UINT CServerConfig::GetUint( const char *pszSectionName, const char *pszKeyName, UINT ulDefaultValue )
{
    return GetInt(pszSectionName, pszKeyName, ulDefaultValue);
}

int64_t CServerConfig::GetInt64( const char *pszSectionName, const char *pszKeyName, int64_t n64DefaultValue )
{
    return GetInt(pszSectionName, pszKeyName, n64DefaultValue);
}

int CServerConfig::GetStr( const char *pszSectionName, const char *pszKeyName, char *pszReturnedString, unsigned int nSize, const char *pszDefaultValue )
{
    return m_CfgFile.GetItemValue(pszSectionName, pszKeyName, pszReturnedString, nSize, pszDefaultValue);
}

MY_NAMESPACE_END