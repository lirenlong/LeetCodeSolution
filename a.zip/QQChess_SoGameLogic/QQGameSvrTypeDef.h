/****************************************************************
* @file		CommonBaseDefinition/QQGameSvrTypeDef.h
* @see	
* @Description     : ��QQGameServer�и��ֻ����������ͽ��ж���
* @version		2006.05.08
* @author		QQGame.Server
* @content		
****************************************************************/

#ifndef __QQGAME_SVR_TYPE_DEF_H__
#define __QQGAME_SVR_TYPE_DEF_H__

typedef unsigned char BYTE;
typedef unsigned char byte;
typedef unsigned int UINT;
typedef unsigned short USHORT;


typedef BYTE TKey[16];
typedef char TName[32];
typedef char TFName[256];
typedef char StrLine[1024];

typedef enum
{
	Wrong = 0,
	False = 0,
	Free = 0,
	Right = 1,
	True  = 1,
	InUse = 1,

	//for OldItemSoMsg
	DecodeSuccess = 0,             //����ɹ�
	DecodeFailed = 1,              //����ʧ��
}TBool;


#endif 
