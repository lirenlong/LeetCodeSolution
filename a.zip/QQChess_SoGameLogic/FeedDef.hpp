#ifndef _FEED_DEF_HPP_
#define _FEED_DEF_HPP_

#define MAX_FEED_TRANSPARNET_SIZE  32

#define MAX_FEED_NUM_IN_MSG   32

#define MAX_TLV_BUFFER_LENGTH   1024

#define MAX_FILTER_FEED_STATUS_IN_MSG   512

#define MAX_SESSION_KEY_LEN  128

#define MAX_CONFIRM_NOTICE_INFO_LEN   4096

//��������
enum ReqType
{
    ERT_RelationFeed    =   1,
    ERT_Message         =   2,
    ERT_System          =   3,
};

//��ϵ����m_ushRelationType
enum RelationType
{
    ERT_IMFriend        =   1,
    ERT_GameFriend      =   2,
};

enum TLVType
{
    ETLVT_SrcApp        =   1,
};

enum FeedType
{
    EFeedType_HappMatch       =   2,
};

typedef struct tagFeed
{
    int m_iFeedID;                              //ID
    unsigned int m_uiUin;                       //������Uin
    unsigned int m_uiFeedTime;                  //������ʱ��
    short m_shSrcApp;                           //��Դ��App
    unsigned short m_ushFeedType;               //����������
    unsigned short m_ushMsgType;                //������
    unsigned short m_ushFeedTLVLen;             //TLV����
    char m_acFeedTLV[MAX_TLV_BUFFER_LENGTH];    //TLV

} TFeed;

//����Feed����
enum FilterFeedType
{
    EFFT_Filter_By_App = 1,
    EFFT_Filter_By_Uin = 2,

};

typedef struct tagFilterStatus
{
    unsigned short m_ushFilterType;
    unsigned int m_uiFilterFeedOpValue;

} TFilterStatus;

const int MAX_SESSION_KEY_LENGTH = 16;
const int MAX_TOKEN_VALID_TIME = 3600 * 6;
const int MAX_FEED_TLV_NUM = 64;
const int MAX_URL_NUM_PER_FEED = 3;
const int MAX_IMG_URL_LENGTH = 128;
const int MAX_IMG_LNK_LENGTH = 128;
const int MAX_FEED_DESC_SIZE = 32;
const int MAX_FEED_TXT_SIZE = 128;
const short FEET_EVENT_SRC_HAPPY = 10001;
const int MAX_URL_TEXT_SIZE = 32;
const int MAX_URL_PARAM_SIZE = 128;

enum EFeedTLVType
{   
    EEIT_FEED_CONFIRM_INFO          = 11,   //֪ͨ�ɷ���Feed����ʾ����
    EEIT_FEED_INFO                  = 12,   //Feed��TLV
    EEIT_FEED_LIMIT_LIMIT_COUNT     = 13,   //����Feed������
    EEIT_FEED_LIMIT_NOW_COUNT       = 14,   //����Feed�������ô���
    EEIT_FEED_SRC_APP_ID            = 15,   //Ӧ��ID(���ڲ�����GameID)
    EEIT_FEED_SESSION_ID            = 16,   //�������ỰID
    EEIT_FEED_CHECK_SEQ             = 17,   //Ч���ֶ�
    EFIT_FEED_EVENT_SRC             = 18,   //��Դ�¼�(������Ϸ��)
    
    EFTT_SRC_APP = 1000,
    EFTT_IMGRES = 1001,    /**< begin from 1000 */
    EFTT_IMGLNK, 
    EFTT_DESC,
    EFTT_URLSET, /*(str)url����, ����(str), (char)����*/
    EFTT_TXT, 
    EFTT_ICON_ID, 
    EFTT_EVENT_SRC,
    EFTT_MAX, 
};




enum
{
    FUC_LAUNCHAPP = 1, 
    FUC_JUMPURL = 2,
};

typedef struct tagFeedURLSet
{
    char m_szURLTxt[MAX_URL_TEXT_SIZE];
    char m_szURLParam[MAX_URL_PARAM_SIZE];
    unsigned char m_ucURLCmd;
} TFeedURLSet;

//����TLV����
typedef struct tagFeedDetail
{
    unsigned short m_ushApp;
    char m_szImgURL[MAX_IMG_URL_LENGTH];
    char m_szImgLnk[MAX_IMG_LNK_LENGTH];
    char m_szDesc[MAX_FEED_DESC_SIZE];
    char m_szTxt[MAX_FEED_TXT_SIZE];
    unsigned char m_ucURLNum;
    TFeedURLSet m_astURL[MAX_URL_NUM_PER_FEED];
} TFeedDetail;


//��ϵ����m_ushRelationType
enum FeedEventID
{
    EFeedID_MatchChapion       =   50,
};

//����m_acConfirmNoticeInfo����
typedef struct tagFeedsInfo
{
    char m_cFeedsTypeForGame;
    char m_cEventID;
    char m_cIconType;
    short m_shMsgLen;
    char m_szMsg[MAX_CONFIRM_NOTICE_INFO_LEN];
    char m_cIconValue;
    short m_shIconBufLen;
    char m_szIconBuffer[MAX_CONFIRM_NOTICE_INFO_LEN];
    int m_iBakValue[4];
} TFeedsInfo;


#endif
