
#ifndef __SERVERCONFIG_H__
#define __SERVERCONFIG_H__

#include "GameCmd.h"
#include "SoCommLogic_i.h"

MY_NAMESPACE_BEGIN

typedef struct 
{
	int  nLogFlag;
	int  nErrLogFlag;
	char LogPath[256];
		
	int	 nMinPlayerScore;
	int  nWinScore;
	int  nEscapeScore;
		
	int  nIsGambleRoom;
	int  nMinPlayerChip;
	int  nWinChip;
	int  nEscapeChip;
	int  nGambleTax;				// ��Ϸ�ҵ�˰��, �ٷ���, ����10��ʾ��ˮ10%
		
	int  nPreestablish;
	int  nRoundTime;
	int  nStepTime;
	int  nLastTime;

	int  nTGA;
	BOOL bSupportCapacityLookOn;
	int  nSyncGameDataInterval;

	BOOL m_bIsFriendVS;
	
    ENM_GAME_ROOM_TYPE eRoomStyle;
}GameRoomSetting;



class CServerConfig : public ICLSoCfgLoader
{
public:
    CServerConfig();
    virtual ~CServerConfig();

	void ReadCfgFile(const char* pszFileName, ISoCommLogic *pSoCL);
    int  GetLogFlag() const;
    int  GetErrLogFlag() const;
    char *GetLogPath();	

    virtual int GetInt( const char *pszSectionName, 
        const char *pszKeyName, 
        int lDefaultValue );
    virtual UINT GetUint( const char *pszSectionName, 
        const char *pszKeyName, 
        UINT ulDefaultValue );
    virtual int64_t GetInt64( const char *pszSectionName, 
        const char *pszKeyName, 
        int64_t n64DefaultValue );
    virtual int GetStr( const char *pszSectionName, 
        const char *pszKeyName, 
        char *pszReturnedString, 
        unsigned int nSize,
        const char *pszDefaultValue);
public:
	GameRoomSetting RoomSetting;
	static CConfigFile m_CfgFile;             /*��ȡ�����ļ���ʵ��*/ 

	int m_nSameRankScoreVary;
	int m_nHighRankScoreWin;
	int m_nHighRankScoreLose;
	int m_nLowRankScoreWin;
	int m_nLowRankScoreLose;
	BOOL m_bEnableVipFirstSetTime;

private:	
	static int         m_iReadCfgTime;        /*��̬��������ʵ��ȡ�����ļ��Ĵ���*/

	int         m_nLogFlag;            /*��ͨ��־�Ĵ�ӡ��־*/ 
    int         m_nErrLogFlag;         /*Err��־�Ĵ�ӡ��־*/ 
	char        m_szLogPath[256];      /*��־��¼�����Ŀ¼*/

public:
	#define MAX_LUXURYVIP_URL_COUNT (3)
	int m_nLuxuryVipInfoURLsCount;
	char m_szLuxuryVipInfoURLs[MAX_LUXURYVIP_URL_COUNT][128];
	void ReadLuxuryVipInfo();
};

MY_NAMESPACE_END

#endif /* __SERVERCONFIG_H__ */
