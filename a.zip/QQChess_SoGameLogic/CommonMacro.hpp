/****************************************************************
 * @file		CommonBaseDefinition/PublicMacro.hpp
 * @see			
 * @version		2006.05.08
 * @author		QQGame.Server
 * @content		
 ****************************************************************/

#ifndef __COMMON_BASE_DEFINITION_HPP__
#define __COMMON_BASE_DEFINITION_HPP__



#ifndef ref
#define ref
#endif



#define MAX_FILENAME_LEN 256

#define MAX_DATE_LEN 16
#define MAX_TIME_LEN 16
#define MAX_DATETIME_LEN 32

#define MAX_PATH          260

#endif
