#if !defined(AFX_STDAFX_H__198C0139_AE41_11D4_A045_0080AD315721__INCLUDED_)
#define AFX_STDAFX_H__198C0139_AE41_11D4_A045_0080AD315721__INCLUDED_

#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <string.h>
#include <new>
#include <assert.h>
#include <stdarg.h>
#include <time.h>

#ifdef WIN32
#include <direct.h>
#include <WINSOCK2.H>
#define int64_t  INT64
#else
#include <sys/stat.h>
#define _snprintf snprintf
#endif

#include "itablegame.hpp"

#ifdef WIN32
//#define _LOGIN_MAIN_
#endif


#define MY_NAMESPACE       NewXiangqiNameSpace

#define USING_MY_NAMESPACE using namespace MY_NAMESPACE;
#define MY_NAMESPACE_BEGIN namespace MY_NAMESPACE { USING_MY_NAMESPACE
#define MY_NAMESPACE_END };

#ifdef _LOGIN_MAIN_
#define LOG               if(m_pMainServer) m_pMainServer->WriteLog
#else
#define LOG               if(m_pstLogFile) m_pstLogFile->Log
#endif

#define ERRLOG            m_pstLogFile->ErrLog
#define FATALLOG          m_pstLogFile->FatalLog
#define LOGFILE           m_pstLogFile->LogFile

#ifndef TRUE
#define TRUE                 1
#endif

#ifndef FALSE
#define FALSE                0
#endif

//#define __SMILE__

#ifndef __SMILE__
#define __AUSTIN__
#endif

typedef unsigned long       DWORD;
typedef int                 BOOL;
typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef void                *LPVOID;
#ifndef WIN32
typedef char				*LPCSTR, *PCSTR;
typedef char                *LPSTR, *PSTR;
typedef struct tagPOINT
{
    int x;
    int y;
} POINT;


#endif


#include "LogFile.h"
#include "Config.h"

#define TRUE				1
#define FALSE				0



#endif // !defined(AFX_STDAFX_H__198C0139_AE41_11D4_A045_0080AD315721__INCLUDED_)