#if !defined CCHESS_SMALLCLASS_HEADER
#define CCHESS_SMALLCLASS_HEADER

#include "StdAfx.h"
#include "GlobalDefine.h"
#include "GameCmd.h"

MY_NAMESPACE_BEGIN

class CPlayerScore
{
public:
	CPlayerScore();

	void InitData();
	BOOL IsValidUser();
	BOOL IsNotSet();
	void SetScoreIsSet(BOOL bSet = TRUE);
	void SetNotSubScore(BOOL bNotSub = TRUE);
	void SetEscape(long lScore, long lMoney);
	void SetFail(long lScore, long lMoney);
	void SetWin(long lScore, long lMoney);
	void SetPeace(long lScore, long lMoney);
		

	short			nUserID;
	GAME_OVER_TYPE  overType;

	BOOL			bIsScoreSet;	// ���˳ɼ��Ƿ��Ѿ����ù�
	BOOL			bNotSubScore;	// ϵͳ����ͶԼ�������������£����۷�
	USER_SCORE		Score;
};


class CPlayerInfo
{
public:
	CPlayerInfo();

	void SetLogPtr(ITable* pMainServer, CLogFile* pLogFile);
	void InitData();
	BOOL IsValidUser();
	BOOL SetGameBegin();
	void SetGameEnd();
	int	 GetRegretTimes();
	void AddRegretTimes();
	void CleanRegretTimes();
    void FillTableUserInfo(TABLE_USER_INFO &kTableUserInfo);

	short		nUserID;					// ��ұ�ʶ
	short		nFaceID;					// ���ͷ��
	int			nChair;						// ������ڵ����Ӻţ���ΧΪ0��3��Ч
	DWORD		dwRightLevel;				// �û�Ȩ��
	char		szUserName[MAX_NAME_LEN];	// �����
	BOOL		bEnableLookOn;				// �Ƿ������Թ�

	GAME_STAGE	stage;						// ��Ϸ״̬���뿪����ʼ����Ϸ����������������
	long		lScore;						// ���ֵ÷�
	BOOL		bIsOffline;					// �Ƿ��ڶ�����
	BOOL		bAgreePeace;				// ������Ƿ��Ѿ�ͬ�����
	int			nTimeOutCount;
	int			nState;						// ��ҡ��Թ�
	int			unChessMoveAni;
	BOOL		m_bSupportSetTime;			// �ͻ����Ƿ�֧��������������ʱ��
	
	unsigned int m_nUIN;	
	
	CLogFile		*m_pstLogFile;
	ITable*         m_pMainServer;
	
protected:
	int			m_nRegretTimes;				// ��������Ĵ���
};


class CPlayerList  
{
public:

	CPlayerList();

	void SetLogPtr(ITable* pMainServer, CLogFile* pLogFile);
	void InitData();
	BOOL GameBegin();
	void GameEnd();
	BOOL AddPlayer(TABLE_USER_INFO *pUser);
	BOOL DeletePlayer(short nPlayerID);
	BOOL DeletePlayer(int nChair);
	int FindPlayer(short nPlayerID);
	BOOL IsValidUser(int nChair);
	char *GetUserName(int nChair);
	DWORD GetUserFaceID(int nChair);
	BOOL SetEnableLookOn(int nChair, int bEnableLookOn);
	BOOL SetPlayerStage(short nPlayerID, GAME_STAGE stage);
	DWORD GetPlayerID(int nChair);
	BOOL SetAgreePeace(int nChair);
	BOOL SetWaitPeace(BOOL bWait);
	BOOL GetCanSetPeace();
	CPlayerInfo* GetPlayerInfo(int nChair);
	CPlayerInfo* GetPlayerByPlayerID(short sPlayerID);

	CPlayerInfo		m_player[MAX_TABLE_PLAYER];		// �����Ϣ
	int				m_nPlayerCount;
	int				m_nAnswerPeaceCount;
	BOOL			m_bWaitForAnswerPeace;

	CLogFile		*m_pstLogFile;
	ITable*         m_pMainServer;
};


class CGameBoard
{
	int				m_index;
	GAME_BOARD_DATA	m_data[2];

public:

	GAME_BOARD_DATA GetUndoData()
	{
		memcpy(&m_data[1],&m_data[0],sizeof(GAME_BOARD_DATA));
	    return m_data[1];
	}

	void InitData(GAME_BOARD_DATA* board)
	{
		m_index = 0;

		memcpy(&m_data[0],board,sizeof(GAME_BOARD_DATA));
		memcpy(&m_data[1],board,sizeof(GAME_BOARD_DATA));
	}

	void Add(GAME_BOARD_DATA* board)
	{
		memcpy(&m_data[0],&m_data[1],sizeof(GAME_BOARD_DATA));
		memcpy(&m_data[1],board,sizeof(GAME_BOARD_DATA));
	}

};

class CStepList
{
public:
	int  GetSize();
	void RemoveAll();
	void Add(MOVE_RESULT_EX* step);
	void Regret();
	MOVE_RESULT_EX GetData(int nIndex);

protected:
	int			   m_size;
	MOVE_RESULT_EX m_data[MAX_GAME_STEPS];
};

MY_NAMESPACE_END

#endif